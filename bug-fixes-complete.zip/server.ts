import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { Type } from "@google/genai";
import { generateText } from "ai";
import crypto from "crypto";
import {
  processSearchResults,
  parseNumberList,
  parseStringList,
} from "./src/lib/searchEngine";
import {
  CITY_TO_COUNTRY,
  lookupCity,
  synchronizeCityCountry,
  validateAndNormalizeLocation,
} from "./src/lib/locationResolver";
import {
  validateAndNormalizeDateRange,
  extractDatesFromPromptText,
} from "./src/lib/dateResolver";
dotenv.config();

/** Alias to shared map so existing CITY_NAME_MAP[key] call sites keep working. */
const CITY_NAME_MAP: Record<string, { cityName: string; countryCode: string }> =
  CITY_TO_COUNTRY as Record<string, { cityName: string; countryCode: string }>;

const API_KEY=process.env.NUITEE_API_KEY||"";

function toGatewayMessages(contents: any): Array<{ role: "user" | "assistant"; content: string }> {
  const entries = Array.isArray(contents) ? contents : [{ role: "user", parts: [{ text: String(contents || "") }] }];
  return entries
    .map((entry: any) => ({
      role: entry?.role === "model" || entry?.role === "assistant" ? "assistant" as const : "user" as const,
      content: Array.isArray(entry?.parts)
        ? entry.parts.map((part: any) => String(part?.text || "")).join("\n")
        : String(entry?.content || entry?.text || ""),
    }))
    .filter((entry) => entry.content.trim().length > 0);
}

const sleep = (milliseconds: number) =>
  new Promise((resolve) => setTimeout(resolve, milliseconds));

function getGeminiErrorStatus(error: any): number | undefined {
  const possibleStatuses = [
    error?.status,
    error?.code,
    error?.response?.status,
    error?.error?.code,
    error?.cause?.status,
    error?.cause?.code,
  ];

  for (const status of possibleStatuses) {
    const parsedStatus = Number(status);
    if (Number.isFinite(parsedStatus)) {
      return parsedStatus;
    }
  }

  return undefined;
}

function getGeminiErrorMessage(error: any): string {
  return String(
    error?.error?.message ||
      error?.response?.data?.error?.message ||
      error?.cause?.message ||
      error?.message ||
      ""
  );
}

function isQuotaExceededError(error: any): boolean {
  const status = getGeminiErrorStatus(error);
  const msg = getGeminiErrorMessage(error).toLowerCase();
  return status === 429 || msg.includes("quota") || msg.includes("resource_exhausted") || msg.includes("rate limit");
}

function isRetryableGeminiError(error: any): boolean {
  const status = getGeminiErrorStatus(error);
  const message = getGeminiErrorMessage(error).toLowerCase();

  return (
    status === 404 ||
    status === 429 ||
    status === 500 ||
    status === 502 ||
    status === 503 ||
    status === 504 ||
    message.includes("high demand") ||
    message.includes("temporarily unavailable") ||
    message.includes("service unavailable") ||
    message.includes("unavailable") ||
    message.includes("overloaded") ||
    message.includes("resource exhausted") ||
    message.includes("deadline exceeded") ||
    message.includes("no longer available") ||
    message.includes("not found")
  );
}

const FALLBACK_MODELS = [
  "google/gemini-3.7-flash",
  "google/gemini-3.5-flash-lite",
  "google/gemini-3.1-flash-lite",
];

function toGatewayModelId(model: string): string {
  return model.includes("/") ? model : `google/${model}`;
}

function getGeminiRetryDelayMs(error: any): number | null {
  const retryAfter = error?.retryAfter ?? error?.retry_after ?? error?.response?.headers?.["retry-after"];
  if (retryAfter != null) {
    const seconds = Number(retryAfter);
    if (Number.isFinite(seconds)) return Math.min(Math.max(seconds * 1000, 0), 300000);
  }
  const raw = [
    error?.error?.details,
    error?.response?.data?.error?.details,
    error?.details,
  ];
  for (const details of raw) {
    if (!Array.isArray(details)) continue;
    for (const detail of details) {
      const text = String(detail?.retryDelay || detail?.retry_delay || "");
      const match = text.match(/(\d+(?:\.\d+)?)s/);
      if (match) return Math.min(Math.max(Number(match[1]) * 1000, 0), 5000);
    }
  }
  return null;
}

async function generateGeminiContentWithRetry(
  request: any,
  maximumAttempts = 2
) {
  let lastError: any;
  const primaryModel = toGatewayModelId(request.model || "google/gemini-3.7-flash");
  const modelsToTry = [primaryModel, ...FALLBACK_MODELS.filter((model) => model !== primaryModel)];
  const boundedAttempts = Math.max(1, Math.min(maximumAttempts, 2));

  for (const currentModel of modelsToTry) {
    for (let attempt = 1; attempt <= boundedAttempts; attempt++) {
      try {
        console.info(`[AI Gateway] attempt model=${currentModel} attempt=${attempt}/${boundedAttempts}`);
        const result = await generateText({
          model: currentModel,
          messages: toGatewayMessages(request.contents),
          system: String(request.config?.systemInstruction || "") || undefined,
          temperature: request.config?.temperature,
          maxRetries: 0,
        });
        return { text: result.text };
      } catch (error: any) {
        lastError = error;
        const status = getGeminiErrorStatus(error);
        const message = getGeminiErrorMessage(error);
        const quota = isQuotaExceededError(error);
        console.warn(`[AI Gateway] model=${currentModel} attempt=${attempt}/${boundedAttempts} status=${status ?? "unknown"} quota=${quota} message=${message}`);

        // Quota exhaustion is a provider/account condition, not a transient
        // model failure. Never fan out the same request to more models.
        if (quota) throw error;
        if (!isRetryableGeminiError(error)) throw error;

        const retryDelay = getGeminiRetryDelayMs(error);
        if (attempt < boundedAttempts) {
          const delay = retryDelay ?? Math.min(1000 * 2 ** (attempt - 1), 2000);
          await sleep(delay + Math.floor(Math.random() * 250));
        }
      }
    }
  }

  throw lastError;
}
/** Format client-sent travel profile for AI system prompts. */
function formatUserProfileContext(profile: any): string {
  if (!profile || typeof profile !== "object") return "";
  const lines: string[] = [];
  const push = (label: string, value: any) => {
    const v =
      typeof value === "string"
        ? value.trim()
        : value != null
          ? String(value).trim()
          : "";
    if (v) lines.push(`${label}: ${v}`);
  };
  push("Name", profile.displayName);
  const place = [profile.homeCity, profile.homeCountry].filter(Boolean).join(", ");
  push("Wohnort", place);
  push("Staatsangehörigkeit", profile.nationality);
  push("Bevorzugte Währung", profile.preferredCurrency);
  push("Sprachen", profile.languages);
  push("Mitreisende", profile.travelCompanions);
  push("Budget", profile.budgetLevel);
  push("Bevorzugte Sterne", profile.preferredHotelStars);
  push("Interessen", profile.interests);
  push("Ernährung/Allergien", profile.dietaryRestrictions);
  push("Barrierefreiheit", profile.accessibilityNeeds);
  push("Notizen", profile.notes);
  if (lines.length === 0) return "";
  return (
    "\n\nPERSÖNLICHES NUTZERPROFIL (vom Nutzer freigegeben – bei allen Empfehlungen berücksichtigen, aber nicht erfinden):\n" +
    lines.join("\n")
  );
}

function fallbackExtractParams(messages: any[], oldState: any) {
  const lastMsg = messages.slice(-1)[0]?.content || "";
  const state = { ...oldState };
  const userProvidedSet = new Set<string>(state.userProvidedFields || []);

  const dotDateMatch = lastMsg.match(/(\d{1,2})\.(\d{1,2})\.(\d{4}).*?(\d{1,2})\.(\d{1,2})\.(\d{4})/);
  if (dotDateMatch) {
    const [, d1, m1, y1, d2, m2, y2] = dotDateMatch;
    state.checkin = `${y1}-${m1.padStart(2, "0")}-${d1.padStart(2, "0")}`;
    state.checkout = `${y2}-${m2.padStart(2, "0")}-${d2.padStart(2, "0")}`;
    userProvidedSet.add("checkin");
    userProvidedSet.add("checkout");
  }

  const isoDateMatch = lastMsg.match(/(\d{4}-\d{2}-\d{2}).*?(\d{4}-\d{2}-\d{2})/);
  if (isoDateMatch) {
    state.checkin = isoDateMatch[1];
    state.checkout = isoDateMatch[2];
    userProvidedSet.add("checkin");
    userProvidedSet.add("checkout");
  }

  const singleIsoDate = lastMsg.match(/\b(\d{4}-\d{2}-\d{2})\b/);
  const singleGermanDate = lastMsg.match(/\b(\d{1,2})\.(\d{1,2})\.(\d{4})\b/);
  const durationMatch = lastMsg.match(/\b(\d+)\s*(nächte?|nights?|tage?|days?|wochen?|weeks?)\b/i);
  const durationWordMatch = lastMsg.match(/\b(eine|one|1)\s+(woche|week)\b/i);
  const durationNumber = durationMatch
    ? Number(durationMatch[1])
    : durationWordMatch
      ? 1
      : 0;
  const durationUnit = durationMatch?.[2]?.toLowerCase() || durationWordMatch?.[2]?.toLowerCase() || "";
  const durationNights = /woche|week/.test(durationUnit)
    ? durationNumber * 7
    : durationNumber;
  const durationStart = state.checkin ||
    (singleIsoDate ? singleIsoDate[1] : singleGermanDate ? `${singleGermanDate[3]}-${singleGermanDate[2].padStart(2, "0")}-${singleGermanDate[1].padStart(2, "0")}` : "");
  if (!state.checkin && durationStart) {
    state.checkin = durationStart;
    userProvidedSet.add("checkin");
  }
  if (durationNights > 0 && durationStart && !state.checkout) {
    const start = new Date(`${durationStart}T00:00:00Z`);
    start.setUTCDate(start.getUTCDate() + durationNights);
    state.checkout = start.toISOString().slice(0, 10);
    userProvidedSet.add("checkout");
  }

  const adultMatch = lastMsg.match(/(\d+)\s*(Erwachsene|Personen|Gäste|Adults|people|guests)\b/i);
  if (adultMatch) {
    state.adults = parseInt(adultMatch[1], 10);
    userProvidedSet.add("adults");
  }

  const cityMatch = lastMsg.match(/(?:in|nach|für)\s+([A-ZÄÖÜ][a-zäöüß]+(?:\s+[A-ZÄÖÜ][a-zäöüß]+)?)/);
  if (cityMatch && !["September", "Oktober", "November", "Dezember", "Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "Erwachsene"].includes(cityMatch[1])) {
    state.cityName = cityMatch[1];
    userProvidedSet.add("cityName");
  }
  const countryCodeMatch = lastMsg.match(/(?:\b(?:in|nach|für)\b[^,\n]{1,60}[,\s]+|[,\s])\b([A-Z]{2})\b/);
  if (countryCodeMatch) {
    state.countryCode = countryCodeMatch[1];
    userProvidedSet.add("countryCode");
  }

  // Extract non-standard wishes to aiSearch in fallback as well
  const nonFilterVibes: string[] = [];
  if (/romantisch|romantik/i.test(lastMsg)) nonFilterVibes.push("Romantisch");
  if (/dachterrasse|rooftop/i.test(lastMsg)) nonFilterVibes.push("Dachterrasse");
  if (/meerblick|seeblick|panoramablick|aussicht/i.test(lastMsg)) nonFilterVibes.push("Schöne Aussicht / Meerblick");
  if (/boutique/i.test(lastMsg)) nonFilterVibes.push("Boutique");
  if (/ruhig|ruhelage|im grünen/i.test(lastMsg)) nonFilterVibes.push("Ruhige Lage");
  if (/zentrum|zentral|altstadt/i.test(lastMsg)) nonFilterVibes.push("Zentrale Lage");
  if (/luxus|luxuriös/i.test(lastMsg)) nonFilterVibes.push("Luxus");
  if (/kinderfreundlich|familie|rutsche/i.test(lastMsg)) nonFilterVibes.push("Familienfreundlich");

  if (nonFilterVibes.length > 0) {
    state.aiSearch = nonFilterVibes.join(", ");
    userProvidedSet.add("aiSearch");
  }

  state.userProvidedFields = Array.from(userProvidedSet);
  return state;
}
const TTL = 10 * 60 * 1000;
const STATIC_TTL = 60 * 60 * 1000;
type Timed<T> = { data: T; timestamp: number };

const detailsCache = new Map<string, Timed<any>>();
const ratesCache = new Map<string, Timed<any>>();
const ratesSearchCache = new Map<string, Timed<any>>();
const placesCache = new Map<string, Timed<any>>();
const staticCache = new Map<string, Timed<any>>();
const advisorSessions = new Map<string, { state: any; rawHotels: any[]; recommended: any[]; signature?: string; updatedAt: number }>();

const headers = () => ({ "X-API-Key": API_KEY, accept: "application/json", "content-type": "application/json" });
const fresh = <T>(x?: Timed<T>, maxAge = TTL) => x && Date.now() - x.timestamp < maxAge ? x.data : undefined;
const clean = (v: any) => typeof v === "string" ? v.trim() : v;
const normList = (v: any) => Array.isArray(v) ? [...new Set(v.map(x => String(x).trim().toLowerCase()).filter(Boolean))] : [];
const signature = (s: any) => crypto.createHash("sha256").update(JSON.stringify({ cityName: s.cityName?.toLowerCase(), countryCode: s.countryCode?.toUpperCase(), checkin: s.checkin, checkout: s.checkout, adults: s.adults, currency: s.currency || "EUR", starRating: s.starRating, boardType: s.boardType, facilityIds: s.facilityIds, aiSearch: s.aiSearch, maxPricePerNight: s.maxPricePerNight, refundableOnly: s.refundableOnly })).digest("hex");
const nights = (a: string, b: string) => Math.max(1, Math.round((Date.parse(b) - Date.parse(a)) / 86400000));
// CITY_NAME_MAP is the shared alias defined near the top (from locationResolver.CITY_TO_COUNTRY).

/**
 * Resolve a free-text city name to { cityName, countryCode }.
 * Uses the shared CITY_TO_COUNTRY map by default.
 * Country is always taken from the city entity when known (integrity).
 * The paid Places endpoint is called ONLY when allowPlaces === true.
 */
async function resolvePlace(
  cityName: string,
  countryCode?: string,
  allowPlaces = false
): Promise<{ cityName: string; countryCode: string; placeId?: string }> {
  if (!cityName) return { cityName: "", countryCode: countryCode || "" };
  const mapped = lookupCity(cityName);
  if (mapped) {
    // Country always derived from the resolved city entity — never overridden by a conflicting guess.
    return {
      cityName: mapped.cityName,
      countryCode: mapped.countryCode,
    };
  }
  const synced = synchronizeCityCountry(cityName, countryCode);
  if (synced.cityName && synced.countryCode) {
    return { cityName: synced.cityName, countryCode: synced.countryCode };
  }

  // Paid Places endpoint – explicit opt-in only (never unbemerkt)
  if (allowPlaces) {
    try {
      const res = await lite(
        `https://api.liteapi.travel/v3.0/data/places?textQuery=${encodeURIComponent(
          cityName
        )}&language=en`,
        { headers: headers() }
      );
      if (res?.data && res.data.length > 0) {
        const match = res.data[0];
        return {
          cityName: match.cityName || match.name || cityName,
          countryCode: match.countryCode || countryCode || "",
          placeId: match.placeId,
        };
      }
    } catch (e) {
      console.warn("Places lookup failed for:", cityName, e);
    }
  }

  return { cityName, countryCode: countryCode || "" };
}

function validState(s: any) {
  return Boolean(
    s.cityName &&
      s.countryCode &&
      /^\d{4}-\d{2}-\d{2}$/.test(s.checkin || "") &&
      /^\d{4}-\d{2}-\d{2}$/.test(s.checkout || "") &&
      Date.parse(s.checkout) > Date.parse(s.checkin) &&
      Number(s.adults) > 0
  );
}

function firstRate(x: any) {
  return x?.roomTypes
    ?.flatMap((r: any) => r.rates || [])
    .sort(
      (a: any, b: any) =>
        (a?.retailRate?.total?.[0]?.amount ?? Infinity) -
        (b?.retailRate?.total?.[0]?.amount ?? Infinity)
    )[0];
}


/** Generate one short distinguishing highlight sentence for the top hotels (max 3). */
async function generateHotelHighlights(hotels: any[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  const top = (hotels || []).slice(0, 3).filter((h) => h && (h.hotelId || h.id) && (h.name));
  if (top.length === 0) return map;
  try {
    const payload = top.map((h, i) => ({
      idx: i + 1,
      id: String(h.hotelId || h.id),
      name: h.name,
      stars: h.starRating,
      rating: h.rating,
      address: h.address,
      facilities: (h.facilities || h.hotelFacilities || []).slice(0, 8),
      description: String(h.description || h.hotelDescription || "").slice(0, 280),
      board: h.boardName,
      refundable: h.refundable,
      price: h.minPrice,
    }));
    const prompt = `Du bist Reisebüro-Experte. Schreibe für jedes Hotel GENAU EINEN kurzen deutschen Satz (max. 18 Wörter), der die besondere Stärke dieses Hotels nennt und es von typischen Alternativen abhebt. Keine Floskeln, kein Preis, kein "empfehlenswert". Fokus auf Lage, Stil, Ausstattung oder Atmosphäre.

Hotels (JSON):
${JSON.stringify(payload)}

Antworte NUR als JSON-Array: [{"id":"...","highlight":"..."}]`;
    const res = await generateGeminiContentWithRetry({
      model: "gemini-3.1-flash-lite",
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: { temperature: 0.35 },
    });
    const raw = (res.text || "").trim();
    const jsonMatch = raw.match(/\[[\s\S]*\]/);
    if (!jsonMatch) return map;
    const arr = JSON.parse(jsonMatch[0]);
    for (const item of arr) {
      if (item?.id && item?.highlight) map.set(String(item.id), String(item.highlight).trim());
    }
  } catch (e) {
    console.warn("[highlights] generation failed:", e);
  }
  return map;
}

/** Pros/cons insight for a single hotel detail page. */
async function generateHotelProsCons(hotel: any): Promise<{ pros: string[]; cons: string[]; summary: string }> {
  const empty = { pros: [] as string[], cons: [] as string[], summary: "" };
  try {
    const prompt = `Du bist Reisebüro-Experte. Bewerte dieses Hotel knapp und ehrlich auf Deutsch.

Hotel: ${hotel?.name || "Unbekannt"}
Sterne: ${hotel?.starRating || "–"}
Ort: ${hotel?.city || ""}, ${hotel?.country || ""}
Adresse: ${hotel?.address || ""}
Bewertung: ${hotel?.rating || "–"}/10 (${hotel?.reviewsCount || 0} Reviews)
Ausstattung: ${(hotel?.hotelFacilities || hotel?.facilities || []).slice(0, 12).join(", ")}
Beschreibung: ${String(hotel?.hotelDescription || hotel?.description || "").slice(0, 500)}

FORMAT (streng):
Antworte NUR als JSON:
{
  "summary": "Ein kompakter Satz zur Gesamteinschätzung",
  "pros": ["Vorteil 1", "Vorteil 2", "Vorteil 3"],
  "cons": ["Nachteil 1", "Nachteil 2"]
}
Max. 3 Vorteile, max. 2 Nachteile. Stichworte, keine Floskeln.`;
    const res = await generateGeminiContentWithRetry({
      model: "gemini-3.1-flash-lite",
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      config: { temperature: 0.25 },
    });
    const raw = (res.text || "").trim();
    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return empty;
    const parsed = JSON.parse(jsonMatch[0]);
    return {
      summary: String(parsed.summary || "").trim(),
      pros: Array.isArray(parsed.pros) ? parsed.pros.map(String).slice(0, 3) : [],
      cons: Array.isArray(parsed.cons) ? parsed.cons.map(String).slice(0, 2) : [],
    };
  } catch (e) {
    console.warn("[proscons] generation failed:", e);
    return empty;
  }
}

function mapHotels(raw: any, state: any) {
  const rateById = new Map((raw.data || []).map((x: any) => [String(x.hotelId), x]));
  return (raw.hotels || [])
    .map((h: any) => {
      const r: any = firstRate(rateById.get(String(h.id)));
      const total = r?.retailRate?.total?.[0]?.amount;
      const facilities = h.hotelFacilities || h.facilities || [];
      const photos: string[] = Array.from(
        new Set(
          [
            h.main_photo,
            ...(h.hotelImages || []).map((img: any) => (typeof img === "string" ? img : img?.url)),
            ...(h.photos || []),
          ].filter(Boolean)
        )
      );
      return {
        hotelId: String(h.id),
        name: h.name,
        cityName: h.city || state.cityName,
        countryCode: h.country || state.countryCode,
        photo: photos[0] || h.main_photo || h.hotelImages?.[0]?.url,
        photos,
        rating: h.rating,
        reviewsCount: h.reviewsCount,
        starRating: h.starRating,
        address: h.address,
        facilities,
        minPrice: typeof total === "number" ? total : undefined,
        currency: r?.retailRate?.total?.[0]?.currency || state.currency,
        refundable: r?.cancellationPolicies?.refundableTag === "RFN",
        boardName: r?.boardName,
        description: h.hotelDescription,
      };
    })
    .filter((h: any) => h.hotelId && h.name);
}

function filterHotels(list: any[], s: any) {
  const words = normList(s.mustHaves);
  const aiSearchWords = s.aiSearch
    ? String(s.aiSearch)
        .toLowerCase()
        .replace(/[,;.]/g, " ")
        .split(/\s+/)
        .filter((w: string) => w.length > 2 && !["und", "oder", "mit", "für", "ein", "eine", "einer", "hotel", "hotels"].includes(w))
    : [];

  const applyFilters = (strictMode: boolean) => {
    return list.filter((h) => {
      if (strictMode) {
        if (s.starRating) {
          const allowed = String(s.starRating)
            .split(",")
            .map((x) => Number(x.trim()))
            .filter(Boolean);
          if (allowed.length > 0 && !allowed.includes(Number(h.starRating || 0))) return false;
        } else if (s.minStars && Number(h.starRating || 0) < s.minStars) {
          return false;
        }
        if (s.minRating && Number(h.rating || 0) < s.minRating) return false;
        if (s.minReviewsCount && Number(h.reviewsCount || 0) < s.minReviewsCount) return false;
        if (s.hotelName && !h.name?.toLowerCase().includes(String(s.hotelName).toLowerCase())) return false;
        if (s.refundableOnly && !h.refundable) return false;
        if (
          s.maxPricePerNight &&
          h.minPrice / nights(s.checkin, s.checkout) > s.maxPricePerNight
        )
          return false;
        if (
          s.boardType &&
          !(h.boardName || "")
            .toLowerCase()
            .includes(String(s.boardType).toLowerCase())
        )
          return false;
      }
      const hay = [h.name, h.description, ...(h.facilities || [])]
        .join(" ")
        .toLowerCase();
      return words.every((w: string) => hay.includes(w));
    });
  };

  let filtered = applyFilters(true);

  // If strict filtering yields no results, fallback to relaxed filters
  if (filtered.length === 0 && list.length > 0) {
    filtered = applyFilters(false);
  }

  // If still empty, return top available list
  if (filtered.length === 0 && list.length > 0) {
    filtered = list;
  }

  return filtered
    .sort((a, b) => {
      const nice = [...normList(s.niceToHaves), ...aiSearchWords];
      const score = (h: any) =>
        nice.reduce(
          (n: number, w: string) =>
            n +
            ([h.name, h.description, ...(h.facilities || [])]
              .join(" ")
              .toLowerCase()
              .includes(w)
              ? 2
              : 0),
          0
        ) +
        (h.rating || 0) / 10;
      return score(b) - score(a);
    })
    .slice(0, 8)
    .map((h) => ({
      ...h,
      reasons: [
        ...(h.refundable ? ["Erstattbarer Tarif verfügbar"] : []),
        ...(h.boardName ? [h.boardName] : []),
        ...(h.rating ? [`Bewertung ${h.rating}`] : []),
      ].slice(0, 3),
    }));
}
async function lite(url:string,init?:RequestInit){const r=await fetch(url,init);const j=await r.json();if(!r.ok)throw new Error(j?.error?.message||j?.error||`LiteAPI ${r.status}`);return j}
async function startServer(){const app=express();app.use(express.json({limit:"1mb"}));
app.get("/api/places", async (req, res) => {
  try {
    const q = String(req.query.textQuery || "").trim();
    if (q.length < 2) return res.json({ data: [] });

    const cacheKey = q.toLowerCase();
    const cached = fresh(placesCache.get(cacheKey), TTL);
    if (cached) return res.json(cached);

    const result = await lite(
      `https://api.liteapi.travel/v3.0/data/places?textQuery=${encodeURIComponent(q)}&language=de`,
      { headers: headers() }
    );
    if (result) placesCache.set(cacheKey, { data: result, timestamp: Date.now() });
    res.json(result);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** Proxy for OpenStreetMap Nominatim – avoids browser CORS and sets a proper User-Agent.
 *  Used by useNextTrip / placeholders to resolve hotel name + address → country/city/coords.
 */
const geocodeCache = new Map<string, { data: any; timestamp: number }>();
const GEOCODE_TTL = 1000 * 60 * 60 * 6; // 6h
app.get("/api/geocode", async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();
    if (q.length < 2) return res.json({ results: [] });

    const hotelMode = String(req.query.hotel || "") === "1" || String(req.query.hotel || "").toLowerCase() === "true";
    const cacheKey = `${q.toLowerCase()}|h:${hotelMode ? 1 : 0}`;
    const cached = geocodeCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < GEOCODE_TTL) {
      return res.json(cached.data);
    }

    const params = new URLSearchParams({
      format: "json",
      q,
      limit: "8",
      addressdetails: "1",
      extratags: "1",
      namedetails: "1",
    });
    if (hotelMode) {
      // Bias toward lodging when we know we are looking for a hotel
      params.set("featuretype", "settlement");
    }

    const nomRes = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
      headers: {
        Accept: "application/json",
        "Accept-Language": "de,en",
        "User-Agent": "NuiteeStays/1.0 (hotel-booking; contact@nuitee.local)",
      },
    });
    if (!nomRes.ok) {
      return res.status(nomRes.status).json({ results: [], error: `Nominatim ${nomRes.status}` });
    }
    const raw = await nomRes.json();
    const results = Array.isArray(raw) ? raw : [];
    const payload = { results };
    geocodeCache.set(cacheKey, { data: payload, timestamp: Date.now() });
    res.json(payload);
  } catch (e: any) {
    res.status(500).json({ results: [], error: e?.message || "Geocode failed" });
  }
});

/** Reverse geocode lat/lng → city + country via Nominatim (authoritative when coords known). */
app.get("/api/reverse-geocode", async (req, res) => {
  try {
    const lat = Number(req.query.lat);
    const lng = Number(req.query.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return res.status(400).json({ error: "lat and lng required" });
    }
    const cacheKey = `rev:${lat.toFixed(5)},${lng.toFixed(5)}`;
    const cached = geocodeCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < GEOCODE_TTL) {
      return res.json(cached.data);
    }
    const params = new URLSearchParams({
      format: "json",
      lat: String(lat),
      lon: String(lng),
      zoom: "10",
      addressdetails: "1",
    });
    const nomRes = await fetch(`https://nominatim.openstreetmap.org/reverse?${params}`, {
      headers: {
        Accept: "application/json",
        "Accept-Language": "de,en",
        "User-Agent": "NuiteeStays/1.0 (hotel-booking; contact@nuitee.local)",
      },
    });
    if (!nomRes.ok) {
      return res.status(nomRes.status).json({ error: `Nominatim ${nomRes.status}` });
    }
    const raw = await nomRes.json();
    const addr = raw?.address || {};
    const payload = {
      city: addr.city || addr.town || addr.village || addr.municipality || addr.county || undefined,
      country: addr.country || undefined,
      countryCode: addr.country_code ? String(addr.country_code).toUpperCase() : undefined,
      lat,
      lng,
      display_name: raw?.display_name,
    };
    geocodeCache.set(cacheKey, { data: payload, timestamp: Date.now() });
    res.json(payload);
  } catch (e: any) {
    res.status(500).json({ error: e?.message || "Reverse geocode failed" });
  }
});


app.post("/api/hotels/rates", async (req, res) => {
  try {
    const rawReq = { ...req.body };

    // 1. Search dates are caller-owned; never substitute a different stay.
    const checkin = typeof rawReq.checkin === "string" ? rawReq.checkin.trim() : "";
    const checkout = typeof rawReq.checkout === "string" ? rawReq.checkout.trim() : "";
    const isoDate = /^(\d{4})-(\d{2})-(\d{2})$/;
    const parseDate = (value: string) => {
      const match = value.match(isoDate);
      if (!match) return null;
      const year = Number(match[1]);
      const month = Number(match[2]);
      const day = Number(match[3]);
      const date = new Date(Date.UTC(year, month - 1, day));
      return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day ? date : null;
    };
    const checkinDate = parseDate(checkin);
    const checkoutDate = parseDate(checkout);
    const todayDate = parseDate(new Date().toISOString().slice(0, 10));
    if (!checkinDate || !checkoutDate || !todayDate || checkinDate < todayDate || checkoutDate <= checkinDate) {
      return res.status(400).json({
        error: "INVALID_DATE",
        message: "checkin und checkout müssen gültige zukünftige ISO-Daten sein; checkout muss nach checkin liegen.",
        requestId: crypto.randomBytes(8).toString("hex"),
      });
    }

    // 2. Resolve location – NEVER default to London, Places only with explicit allowPlaces
    const allowPlaces = Boolean(rawReq.allowPlaces);
    let cityName = clean(rawReq.cityName) || undefined;
    let countryCode = clean(rawReq.countryCode)?.toUpperCase() || undefined;
    let placeId = clean(rawReq.placeId) || undefined;
    let hotelIds: string[] | undefined =
      Array.isArray(rawReq.hotelIds) && rawReq.hotelIds.length > 0
        ? rawReq.hotelIds.map(String)
        : undefined;
    const hasLatLng =
      typeof rawReq.latitude === "number" &&
      typeof rawReq.longitude === "number" &&
      Number.isFinite(rawReq.latitude) &&
      Number.isFinite(rawReq.longitude);
    const iataCode = clean(rawReq.iataCode)?.toUpperCase() || undefined;
    const aiSearch =
      typeof rawReq.aiSearch === "string" && rawReq.aiSearch.trim()
        ? rawReq.aiSearch.trim()
        : undefined;
    const semanticQuery =
      typeof rawReq.semanticQuery === "string" && rawReq.semanticQuery.trim()
        ? rawReq.semanticQuery.trim()
        : undefined;
    const visualQuery =
      typeof rawReq.visualQuery === "string" && rawReq.visualQuery.trim()
        ? rawReq.visualQuery.trim()
        : undefined;

    // WP7: Semantic mode → hotel IDs via beta semantic-search (free), then rates by IDs
    let semanticHotelsMeta: any[] = [];
    if (semanticQuery && !hotelIds) {
      try {
        const semLimit = Math.min(
          Math.max(Number(rawReq.semanticLimit) || 30, 1),
          50
        );
        const semParams = new URLSearchParams({
          query: semanticQuery,
          limit: String(semLimit),
        });
        if (rawReq.minRating != null && Number.isFinite(Number(rawReq.minRating))) {
          // semantic endpoint uses 0–5 style in docs; normalize if > 5
          const mr = Number(rawReq.minRating);
          semParams.set("minRating", String(mr > 5 ? mr / 2 : mr));
        }
        const semRes = await lite(
          `https://api.liteapi.travel/v3.0/data/hotels/semantic-search?${semParams.toString()}`,
          { headers: headers() }
        );
        const list = Array.isArray(semRes?.data)
          ? semRes.data
          : Array.isArray(semRes)
            ? semRes
            : [];
        semanticHotelsMeta = list;
        hotelIds = list
          .map((h: any) => String(h.id || h.hotelId || ""))
          .filter(Boolean);
        if (hotelIds.length === 0) {
          return res.json({
            data: [],
            hotels: [],
            totalReturned: 0,
            hasMore: false,
            offset: Number(rawReq.offset) || 0,
            limit: Number(rawReq.limit) || 50,
            mode: "semantic",
            message: "Semantische Suche lieferte keine Hotels.",
          });
        }
      } catch (semErr: any) {
        console.warn("[rates] semantic-search failed:", semErr?.message);
        return res.status(502).json({
          error: "semantic_search_failed",
          message: semErr?.message || "Semantische Suche fehlgeschlagen",
        });
      }
    }

    // WP7: Visual room-search → hotel IDs, then rates by IDs
    let visualHotelsMeta: any[] = [];
    if (visualQuery && !hotelIds) {
      try {
        const visLimit = Math.min(
          Math.max(Number(rawReq.visualLimit) || 30, 1),
          50
        );
        const visParams = new URLSearchParams({
          query: visualQuery,
          limit: String(visLimit),
        });
        if (cityName) visParams.set("city", cityName);
        if (countryCode) visParams.set("country", countryCode);
        if (hasLatLng) {
          visParams.set("latitude", String(rawReq.latitude));
          visParams.set("longitude", String(rawReq.longitude));
          if (rawReq.radius != null) {
            // API expects km for room-search radius
            const km = Number(rawReq.radius) >= 1000
              ? Number(rawReq.radius) / 1000
              : Number(rawReq.radius);
            visParams.set("radius", String(km));
          }
        }
        if (placeId) visParams.set("placeId", placeId);
        const visRes = await lite(
          `https://api.liteapi.travel/v3.0/data/hotels/room-search?${visParams.toString()}`,
          { headers: headers() }
        );
        const list = Array.isArray(visRes?.data)
          ? visRes.data
          : Array.isArray(visRes)
            ? visRes
            : [];
        visualHotelsMeta = list;
        hotelIds = Array.from(
          new Set<string>(
            list
              .map((h: any) => String(h.id || h.hotelId || ""))
              .filter((id: string) => Boolean(id))
          )
        );
        if (hotelIds.length === 0) {
          return res.json({
            data: [],
            hotels: [],
            totalReturned: 0,
            hasMore: false,
            offset: Number(rawReq.offset) || 0,
            limit: Number(rawReq.limit) || 50,
            mode: "visual",
            message: "Visuelle Zimmersuche lieferte keine Hotels.",
          });
        }
      } catch (visErr: any) {
        console.warn("[rates] room-search failed:", visErr?.message);
        return res.status(502).json({
          error: "visual_search_failed",
          message: visErr?.message || "Visuelle Suche fehlgeschlagen",
        });
      }
    }

    // Resolve placeName / free-text via local map (or Places only if allowPlaces)
    if (
      !hotelIds &&
      !cityName &&
      !placeId &&
      !hasLatLng &&
      !iataCode &&
      !aiSearch
    ) {
      const queryName = clean(rawReq.placeName);
      if (queryName) {
        const resolved = await resolvePlace(queryName, countryCode, allowPlaces);
        if (resolved.cityName) {
          cityName = resolved.cityName;
          countryCode = resolved.countryCode || countryCode;
          if (resolved.placeId && !placeId) placeId = resolved.placeId;
        }
      }
    }

    // If cityName without countryCode, try local map only (Places only if allowPlaces)
    if (cityName && !countryCode && !placeId && !hotelIds) {
      const resolved = await resolvePlace(cityName, undefined, allowPlaces);
      if (resolved.countryCode) countryCode = resolved.countryCode;
      if (resolved.placeId && !placeId) placeId = resolved.placeId;
      if (resolved.cityName) cityName = resolved.cityName;
    }

    const hasLocation = Boolean(
      hotelIds ||
        placeId ||
        (cityName && countryCode) ||
        hasLatLng ||
        iataCode ||
        aiSearch
    );

    if (!hasLocation) {
      return res.status(400).json({
        error: "location required",
        message:
          "Please provide a location: cityName+countryCode, placeId, hotelIds, latitude+longitude, iataCode, aiSearch, semanticQuery, or visualQuery.",
      });
    }

    // 3. Build LiteAPI body – required fields + exactly one location method
    // Occupancies: full multi-room with children ages
    let occupancies: Array<{ adults: number; children?: number[] }>;
    if (Array.isArray(rawReq.occupancies) && rawReq.occupancies.length > 0) {
      occupancies = rawReq.occupancies.map((o: any) => {
        const adults = Math.max(1, Number(o?.adults) || 1);
        const ages = Array.isArray(o?.children)
          ? o.children
          : Array.isArray(o?.childrenAges)
            ? o.childrenAges
            : [];
        const children = ages
          .map((a: any) => Number(a))
          .filter((a: number) => Number.isFinite(a) && a >= 0 && a <= 17);
        const entry: { adults: number; children?: number[] } = { adults };
        if (children.length > 0) entry.children = children;
        return entry;
      });
    } else {
      occupancies = [{ adults: Math.max(1, Number(rawReq.adults) || 2) }];
    }

    const requestedLimit = Number(rawReq.limit);
    const limit = Math.min(
      Math.max(1, Number.isFinite(requestedLimit) ? requestedLimit : 50),
      5000
    );
    const offset = Math.max(0, Number(rawReq.offset) || 0);

    const liteBody: any = {
      occupancies,
      currency: rawReq.currency || "EUR",
      guestNationality: rawReq.guestNationality || "DE",
      checkin,
      checkout,
      roomMapping: true,
      maxRatesPerHotel:
        rawReq.maxRatesPerHotel != null
          ? Math.max(1, Number(rawReq.maxRatesPerHotel) || 1)
          : 1,
      includeHotelData: true,
      limit,
      offset,
    };

    // Location: prefer hotelIds > placeId > city+country > lat/lng > iata > aiSearch
    if (hotelIds) {
      liteBody.hotelIds = hotelIds;
    } else if (placeId) {
      liteBody.placeId = placeId;
    } else if (cityName && countryCode) {
      liteBody.cityName = cityName;
      liteBody.countryCode = countryCode;
    } else if (hasLatLng) {
      liteBody.latitude = rawReq.latitude;
      liteBody.longitude = rawReq.longitude;
      if (rawReq.radius != null) liteBody.radius = Number(rawReq.radius);
    } else if (iataCode) {
      liteBody.iataCode = iataCode;
    } else if (aiSearch) {
      // aiSearch is a valid main query method per LiteAPI docs
      liteBody.aiSearch = aiSearch;
    }

    // 4. Map filters 1:1 from UI → LiteAPI
    if (rawReq.aiSearch && typeof rawReq.aiSearch === "string" && rawReq.aiSearch.trim()) {
      liteBody.aiSearch = rawReq.aiSearch.trim();
    }
    if (rawReq.starRating) {
      const stars = Array.isArray(rawReq.starRating)
        ? rawReq.starRating.map(Number).filter((n: number) => !isNaN(n))
        : String(rawReq.starRating)
            .split(",")
            .map((s) => Number(s.trim()))
            .filter((n: number) => !isNaN(n));
      if (stars.length) liteBody.starRating = stars;
    }
    if (rawReq.facilityIds || rawReq.facilities) {
      const facs = Array.isArray(rawReq.facilityIds || rawReq.facilities)
        ? (rawReq.facilityIds || rawReq.facilities)
            .map(Number)
            .filter((n: number) => !isNaN(n))
        : String(rawReq.facilityIds || rawReq.facilities)
            .split(",")
            .map((s) => Number(s.trim()))
            .filter((n: number) => !isNaN(n));
      if (facs.length) {
        liteBody.facilities = facs;
        if (
          rawReq.strictFacilitiesFiltering !== undefined ||
          rawReq.strictFacilityFiltering !== undefined
        ) {
          liteBody.strictFacilityFiltering = Boolean(
            rawReq.strictFacilitiesFiltering ?? rawReq.strictFacilityFiltering
          );
        }
      }
    }
    if (rawReq.hotelTypeIds) {
      const types = Array.isArray(rawReq.hotelTypeIds)
        ? rawReq.hotelTypeIds.map(Number).filter((n: number) => !isNaN(n))
        : String(rawReq.hotelTypeIds)
            .split(",")
            .map((s) => Number(s.trim()))
            .filter((n: number) => !isNaN(n));
      if (types.length) liteBody.hotelTypeIds = types;
    }
    if (rawReq.chainIds) {
      const chains = Array.isArray(rawReq.chainIds)
        ? rawReq.chainIds.map(Number).filter((n: number) => !isNaN(n))
        : String(rawReq.chainIds)
            .split(",")
            .map((s) => Number(s.trim()))
            .filter((n: number) => !isNaN(n));
      if (chains.length) liteBody.chainIds = chains;
    }
    if (rawReq.minRating != null && rawReq.minRating !== "") {
      const mr = Number(rawReq.minRating);
      if (!isNaN(mr)) liteBody.minRating = mr;
    }
    if (rawReq.minReviewsCount != null && rawReq.minReviewsCount !== "") {
      const mrc = Number(rawReq.minReviewsCount);
      if (!isNaN(mrc)) liteBody.minReviewsCount = mrc;
    }
    if (rawReq.boardType) liteBody.boardType = String(rawReq.boardType);
    if (rawReq.refundableOnly || rawReq.refundableRatesOnly) {
      liteBody.refundableRatesOnly = true;
    }
    if (rawReq.hotelName && String(rawReq.hotelName).trim()) {
      liteBody.hotelName = String(rawReq.hotelName).trim();
    }
    if (rawReq.zip && String(rawReq.zip).trim()) {
      liteBody.zip = String(rawReq.zip).trim();
    }
    if (rawReq.advancedAccessibilityOnly) {
      liteBody.advancedAccessibilityOnly = true;
    }
    if (rawReq.bedTypes) {
      const beds = Array.isArray(rawReq.bedTypes)
        ? rawReq.bedTypes.map(String).map((s) => s.trim()).filter(Boolean)
        : String(rawReq.bedTypes)
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean);
      if (beds.length) liteBody.bedTypes = beds;
    }
    // Sort: [{ field: "price"|"top_picks"|"revenue", direction: "ascending"|"descending" }]
    if (rawReq.sort && Array.isArray(rawReq.sort) && rawReq.sort.length > 0) {
      liteBody.sort = rawReq.sort;
    } else if (rawReq.sortField) {
      liteBody.sort = [
        {
          field: String(rawReq.sortField),
          direction:
            String(rawReq.sortDirection || "ascending").toLowerCase() ===
            "descending"
              ? "descending"
              : "ascending",
        },
      ];
    }

    // Optional sessionId only when client explicitly sends it (price consistency within session)
    if (rawReq.sessionId && typeof rawReq.sessionId === "string") {
      liteBody.sessionId = rawReq.sessionId;
    }

    // Debug log only when explicitly enabled (no API key)
    if (process.env.DEBUG_RATES === "1") {
      console.log(
        "[rates] LiteAPI request body:",
        JSON.stringify({
          ...liteBody,
          occupancies: liteBody.occupancies,
        })
      );
    }

    // 5. Cache key must include ALL request-relevant fields (full liteBody)
    const searchSig = crypto
      .createHash("sha256")
      .update(JSON.stringify(liteBody))
      .digest("hex");
    const cachedRates = fresh(ratesSearchCache.get(searchSig), 5 * 60 * 1000);
    if (cachedRates) {
      return res.json(cachedRates);
    }

    let result: any = null;

    const requestId = crypto.randomBytes(8).toString("hex");

    try {
      result = await lite("https://api.liteapi.travel/v3.0/hotels/rates", {
        method: "POST",
        headers: headers(),
        body: JSON.stringify(liteBody),
      });
    } catch (err: any) {
      console.warn(`[rates ${requestId}] Primary rates search error:`, err?.message);
      return res.status(502).json({
        error: "SEARCH_PROVIDER_FAILED",
        message: err?.message || "Der Hotelanbieter konnte die Suche nicht ausführen.",
        requestId,
      });
    }

    // Empty data is a valid result; an upstream error is not.
    if (!result || result.error) {
      return res.status(502).json({
        error: "SEARCH_PROVIDER_FAILED",
        message: result?.error?.message || result?.error || "Der Hotelanbieter hat keine gültige Suchantwort geliefert.",
        requestId,
      });
    }

    // ── WP3: Dedup by hotelId within this page ──
    const rawData: any[] = Array.isArray(result.data) ? result.data : [];
    const rawHotels: any[] = Array.isArray(result.hotels) ? result.hotels : [];
    const dedupSeen = new Set<string>();
    const dedupData: any[] = [];
    for (const rd of rawData) {
      const id = String(rd.hotelId || rd.id || "");
      if (!id || dedupSeen.has(id)) continue;
      dedupSeen.add(id);
      dedupData.push(rd);
    }

    // Merge semantic / visual metadata into hotel list for ranking & UI
    const enrichMap = new Map<string, any>();
    for (const h of [...semanticHotelsMeta, ...visualHotelsMeta]) {
      const id = String(h.id || h.hotelId || "");
      if (id) enrichMap.set(id, h);
    }
    let hotelsForProcess = rawHotels;
    if (enrichMap.size > 0) {
      const byId = new Map<string, any>();
      for (const h of rawHotels) {
        byId.set(String(h.id || h.hotelId || ""), h);
      }
      for (const [id, meta] of enrichMap) {
        const existing = byId.get(id) || { id };
        byId.set(id, {
          ...existing,
          id,
          name: existing.name || meta.name,
          main_photo: existing.main_photo || meta.main_photo,
          address: existing.address || meta.address,
          city: existing.city || meta.city,
          country: existing.country || meta.country,
          rating: existing.rating ?? meta.rating,
          tags: meta.tags || existing.tags,
          persona: meta.persona || existing.persona,
          style: meta.style || existing.style,
          location_type: meta.location_type || existing.location_type,
          story: meta.story || existing.story,
          semanticScore: meta.score ?? meta.relevance,
          visualSimilarity:
            meta.similarity ??
            meta.rooms?.[0]?.similarity ??
            meta.roomSimilarity,
        });
      }
      hotelsForProcess = Array.from(byId.values());
    }

    // ── WP4: Post-filter + criterion status + deterministic ranking ──
    const starList = parseNumberList(rawReq.starRating);
    const boardList = parseStringList(rawReq.boardType);
    const facList = parseNumberList(rawReq.facilityIds || rawReq.facilities);
    const processed = processSearchResults({
      data: dedupData,
      hotels: hotelsForProcess,
      params: {
        minRating:
          rawReq.minRating != null ? Number(rawReq.minRating) : undefined,
        minReviewsCount:
          rawReq.minReviewsCount != null
            ? Number(rawReq.minReviewsCount)
            : undefined,
        starRating: starList.length ? starList : undefined,
        refundableOnly: Boolean(
          rawReq.refundableOnly || rawReq.refundableRatesOnly
        ),
        boardType: boardList.length ? boardList : undefined,
        maxPricePerNight:
          rawReq.maxPricePerNight != null
            ? Number(rawReq.maxPricePerNight)
            : undefined,
        facilityIds: facList.length ? facList : undefined,
        checkin,
        checkout,
        // Hard-exclude only when the criterion was already applied at API level
        // OR when it is a pure post-filter (price). Unknown data never excludes.
        hardExclude: true,
      },
    });

    result.data = processed.data;
    result.hotels = processed.hotels;
    result.rankedMeta = processed.rankedMeta;
    result.excludedCount = processed.excludedCount;

    const returnedCount = processed.data.length;
    // hasMore: LiteAPI returned a full page before our post-filter, so more may exist
    const liteReturnedFullPage = dedupData.length >= limit;
    result.totalReturned = returnedCount;
    result.hasMore = liteReturnedFullPage;
    result.offset = offset;
    result.limit = limit;
    result.requestId = requestId;
    if (semanticQuery) result.mode = "semantic";
    else if (visualQuery) result.mode = "visual";
    else if (aiSearch) result.mode = "ai";
    else result.mode = rawReq.mode || "destination";

    // Optional AI highlights for top-3 after ranking (non-blocking for correctness)
    try {
      const top = processed.hotels.slice(0, 3);
      if (top.length > 0) {
        const highlightMap = await generateHotelHighlights(
          top.map((h: any) => ({
            hotelId: String(h.id || h.hotelId),
            name: h.name,
            starRating: h.starRating,
            rating: h.rating,
            address: h.address,
            facilities: h.hotelFacilities || h.facilities,
            description: h.hotelDescription,
          }))
        );
        if (highlightMap.size > 0) {
          result.hotels = result.hotels.map((h: any) => {
            const id = String(h.id || h.hotelId);
            const aiHighlight = highlightMap.get(id);
            return aiHighlight ? { ...h, aiHighlight } : h;
          });
        }
      }
    } catch (hlErr) {
      console.warn(`[rates ${requestId}] highlight enrichment failed:`, hlErr);
    }

    ratesSearchCache.set(searchSig, { data: result, timestamp: Date.now() });
    res.json(result);
  } catch (e: any) {
    const requestId = crypto.randomBytes(8).toString("hex");
    console.error(`[rates ${requestId}] Rates route error:`, e);
    res.status(502).json({
      error: "SEARCH_FAILED",
      message: e?.message || "Hotelsuche fehlgeschlagen.",
      requestId,
    });
  }
});


app.post("/api/hotels/ai-insight", async (req, res) => {
  try {
    const hotel = req.body?.hotel || req.body;
    if (!hotel || !hotel.name) {
      return res.status(400).json({ error: "hotel required" });
    }
    const insight = await generateHotelProsCons(hotel);
    res.json(insight);
  } catch (e: any) {
    res.status(500).json({ error: e.message || "insight failed", pros: [], cons: [], summary: "" });
  }
});

app.get("/api/hotel-details", async (req, res) => {
  try {
    const id = String(req.query.hotelId || "");
    if (!id) return res.status(400).json({ error: "hotelId is required" });
    const c = fresh(detailsCache.get(id));
    if (c) return res.json({ data: c });
    const j = await lite(
      `https://api.liteapi.travel/v3.0/data/hotel?hotelId=${encodeURIComponent(id)}&language=${encodeURIComponent(
        String(req.query.language || "de")
      )}&timeout=4`,
      { headers: headers() }
    );
    if (j.data) detailsCache.set(id, { data: j.data, timestamp: Date.now() });
    res.json(j);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/hotel-reviews", async (req, res) => {
  try {
    const id = String(req.query.hotelId || "");
    if (!id) return res.status(400).json({ error: "hotelId is required" });

    let rawReviews: any = null;
    try {
      rawReviews = await lite(
        `https://api.liteapi.travel/v3.0/data/reviews?hotelId=${encodeURIComponent(id)}&limit=200`,
        { headers: headers() }
      );
    } catch (err: any) {
      console.warn("LiteAPI reviews fetch warning:", err?.message);
    }

    res.json(rawReviews || { data: [] });
  } catch (e: any) {
    res.status(500).json({ error: e.message, data: [] });
  }
});

app.post("/api/rates/prebook", async (req, res) => {
  try {
    res.json(
      await lite("https://book.liteapi.travel/v3.0/rates/prebook", {
        method: "POST",
        headers: headers(),
        body: JSON.stringify(req.body),
      })
    );
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/rates/book", async (req, res) => {
  try {
    res.json(
      await lite("https://book.liteapi.travel/v3.0/rates/book", {
        method: "POST",
        headers: headers(),
        body: JSON.stringify(req.body),
      })
    );
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/data/facilities", async (req, res) => {
  try {
    const lang = String(req.query.language || "de");
    const cacheKey = `fac_${lang}`;
    const cached = fresh(staticCache.get(cacheKey), STATIC_TTL);
    if (cached) return res.json(cached);

    const data = await lite(`https://api.liteapi.travel/v3.0/data/facilities?language=${encodeURIComponent(lang)}`, {
      headers: headers(),
    });
    staticCache.set(cacheKey, { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/data/hotelTypes", async (req, res) => {
  try {
    const cached = fresh(staticCache.get("hotelTypes"), STATIC_TTL);
    if (cached) return res.json(cached);

    const data = await lite("https://api.liteapi.travel/v3.0/data/hotelTypes", { headers: headers() });
    staticCache.set("hotelTypes", { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.get("/api/data/chains", async (req, res) => {
  try {
    const cached = fresh(staticCache.get("chains"), STATIC_TTL);
    if (cached) return res.json(cached);

    const data = await lite("https://api.liteapi.travel/v3.0/data/chains", { headers: headers() });
    staticCache.set("chains", { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI: currencies */
app.get("/api/data/currencies", async (req, res) => {
  try {
    const cached = fresh(staticCache.get("currencies"), STATIC_TTL);
    if (cached) return res.json(cached);
    const data = await lite("https://api.liteapi.travel/v3.0/data/currencies", { headers: headers() });
    staticCache.set("currencies", { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI: countries */
app.get("/api/data/countries", async (req, res) => {
  try {
    const cached = fresh(staticCache.get("countries"), STATIC_TTL);
    if (cached) return res.json(cached);
    const data = await lite("https://api.liteapi.travel/v3.0/data/countries", { headers: headers() });
    staticCache.set("countries", { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI: cities by countryCode */
app.get("/api/data/cities", async (req, res) => {
  try {
    const countryCode = String(req.query.countryCode || "").trim().toUpperCase();
    if (!countryCode || countryCode.length !== 2) {
      return res.status(400).json({ error: "countryCode (ISO-2) required" });
    }
    const cacheKey = `cities_${countryCode}`;
    const cached = fresh(staticCache.get(cacheKey), STATIC_TTL);
    if (cached) return res.json(cached);
    const data = await lite(
      `https://api.liteapi.travel/v3.0/data/cities?countryCode=${encodeURIComponent(countryCode)}`,
      { headers: headers() }
    );
    staticCache.set(cacheKey, { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI: IATA codes */
app.get("/api/data/iataCodes", async (req, res) => {
  try {
    const cached = fresh(staticCache.get("iataCodes"), STATIC_TTL);
    if (cached) return res.json(cached);
    const data = await lite("https://api.liteapi.travel/v3.0/data/iataCodes", { headers: headers() });
    staticCache.set("iataCodes", { data, timestamp: Date.now() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI beta: semantic hotel search */
app.get("/api/data/hotels/semantic-search", async (req, res) => {
  try {
    const query = String(req.query.query || "").trim();
    if (!query) return res.status(400).json({ error: "query required" });
    const limit = Math.min(Math.max(Number(req.query.limit) || 8, 1), 30);
    const minRating = req.query.minRating != null ? Number(req.query.minRating) : undefined;
    const params = new URLSearchParams({ query, limit: String(limit) });
    if (minRating != null && !Number.isNaN(minRating)) params.set("minRating", String(minRating));
    const data = await lite(
      `https://api.liteapi.travel/v3.0/data/hotels/semantic-search?${params.toString()}`,
      { headers: headers() }
    );
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI beta: visual room search */
app.get("/api/data/hotels/room-search", async (req, res) => {
  try {
    const query = String(req.query.query || "").trim();
    if (!query) return res.status(400).json({ error: "query required" });
    const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 50);
    const params = new URLSearchParams({ query, limit: String(limit) });
    if (req.query.city) params.set("city", String(req.query.city));
    if (req.query.country) params.set("country", String(req.query.country));
    if (req.query.placeId) params.set("placeId", String(req.query.placeId));
    if (req.query.latitude != null && req.query.longitude != null) {
      params.set("latitude", String(req.query.latitude));
      params.set("longitude", String(req.query.longitude));
    }
    if (req.query.radius != null) params.set("radius", String(req.query.radius));
    const data = await lite(
      `https://api.liteapi.travel/v3.0/data/hotels/room-search?${params.toString()}`,
      { headers: headers() }
    );
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI beta: ask a question about a hotel */
app.get("/api/data/hotel/ask", async (req, res) => {
  try {
    const hotelId = String(req.query.hotelId || "").trim();
    const question = String(req.query.question || "").trim();
    if (!hotelId || !question) {
      return res.status(400).json({ error: "hotelId and question required" });
    }
    const allowWebSearch = String(req.query.allowWebSearch || "false") === "true";
    const params = new URLSearchParams({
      hotelId,
      question,
      allowWebSearch: String(allowWebSearch),
    });
    const data = await lite(
      `https://api.liteapi.travel/v3.0/data/hotel/ask?${params.toString()}`,
      { headers: headers() }
    );
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI weather */
app.get("/api/data/weather", async (req, res) => {
  try {
    const latitude = Number(req.query.latitude);
    const longitude = Number(req.query.longitude);
    const startDate = String(req.query.startDate || "").trim();
    const endDate = String(req.query.endDate || "").trim();
    const units = String(req.query.units || "metric").trim() === "imperial" ? "imperial" : "metric";
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || !startDate || !endDate) {
      return res.status(400).json({ error: "latitude, longitude, startDate, endDate required" });
    }
    const params = new URLSearchParams({
      latitude: String(latitude),
      longitude: String(longitude),
      startDate,
      endDate,
      units,
    });
    const data = await lite(
      `https://api.liteapi.travel/v3.0/data/weather?${params.toString()}`,
      { headers: headers() }
    );
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI bookings list */
app.get("/api/bookings", async (req, res) => {
  try {
    const data = await lite("https://book.liteapi.travel/v3.0/bookings", { headers: headers() });
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI booking by id */
app.get("/api/bookings/:bookingId", async (req, res) => {
  try {
    const bookingId = String(req.params.bookingId || "").trim();
    if (!bookingId) return res.status(400).json({ error: "bookingId required" });
    const data = await lite(
      `https://book.liteapi.travel/v3.0/bookings/${encodeURIComponent(bookingId)}`,
      { headers: headers() }
    );
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

/** LiteAPI cancel booking */
app.put("/api/bookings/:bookingId", async (req, res) => {
  try {
    const bookingId = String(req.params.bookingId || "").trim();
    if (!bookingId) return res.status(400).json({ error: "bookingId required" });
    const data = await lite(
      `https://book.liteapi.travel/v3.0/bookings/${encodeURIComponent(bookingId)}`,
      {
        method: "PUT",
        headers: headers(),
        body: JSON.stringify(req.body || {}),
      }
    );
    res.json(data);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/ai-advisor/chat", async (req, res) => {
    try {
      const { messages, searchContext = {}, sessionId, openedHotel, forceRefresh = false, userProfile } = req.body;
      if (!Array.isArray(messages) || !messages.length) return res.status(400).json({ error: "messages required" });
      if (!sessionId) return res.status(400).json({ error: "sessionId required" });
      const profileContext = formatUserProfileContext(userProfile);

      const old = advisorSessions.get(sessionId) || { state: { currency: "EUR" }, rawHotels: [], recommended: [], updatedAt: Date.now() };
      const transcript = messages.slice(-14).map((m: any) => `${m.role}: ${m.content}`).join("\n");

      let parsed: any = {};
      let state: any = { ...old.state, ...searchContext };
      const userProvidedSet = new Set<string>(state.userProvidedFields || []);

      try {
        const extraction = await generateGeminiContentWithRetry({
          model: "gemini-3.1-flash-lite",
          contents: [
            {
              role: "user",
              parts: [
                {
                  text: `Heutiges Datum: ${new Date().toISOString().slice(0, 10)}.
Du bist der "LiteAPI KI Berater" – ein hochkompetenter, herzlicher und erfahrener Reisebüro-Berater.
Extrahiere alle Suchparameter, Wünsche, Absichten und Filter aus der Unterhaltung.

FACILITIES REFERENZ-LISTE (facilityIds CSV):
1: Pool / Außenpool / Hallenbad / Schwimmbad / Infinity Pool
2: WLAN / Highspeed Wifi / Internet
3: Parkplatz / Tiefgarage / Garage / Valet Parking
4: Spa / Wellness / Sauna / Dampfbad / Massage / Whirlpool / Jacuzzi
5: Fitnessstudio / Gym / Fitnessbereich
6: Restaurant / Gourmet / Gastronomie
7: Bar / Lounge / Cocktailbar / Rooftop Bar
8: Klimaanlage / AC / Air Conditioning
9: Zimmerservice / Room Service
10: Haustiere erlaubt / Hundefreundlich / Pet friendly
11: Frühstück / Breakfast
12: E-Ladestation / Wallbox / Elektroauto
13: Strandnähe / Beachfront / Strandlage / Meerzugang
14: Barrierefrei / Rollstuhlgerecht / Accessible
16: Nichtraucherzimmer
28: Familienzimmer / Mehrbettzimmer
48: Aufzug / Lift

HOTEL TYPES (hotelTypeIds CSV):
201: Hotel
204: Resort / Strandresort / Wellnessresort
208: Apartment / Ferienwohnung
210: Boutique Hotel / Designhotel

BOARD TYPES (boardType):
RO: Room Only (Ohne Verpflegung / Nur Übernachtung)
BI: Breakfast Included (Frühstück inklusive / mit Frühstück)
HB: Half Board (Halbpension)
FB: Full Board (Vollpension)
AI: All Inclusive (Alles inklusive)

BED TYPES (bedTypes CSV):
double, twin, king, queen, single

EXTRAKTIONS- & REISEBÜRO-REGELN:
1. BRAINSTORMING ('isBrainstorming'):
   - Setze isBrainstorming = true, wenn der Nutzer noch kein klares Ziel hat, nach Empfehlungen/Ideen fragt ("Wohin soll ich reisen?", "Lass uns brainstormen", "Hast du Ideen für den Sommer?").
2. HOTEL-EINSCHÄTZUNG ('wantsHotelAssessment'):
   - Setze wantsHotelAssessment = true, wenn der Nutzer nach einem bestimmten Hotel fragt, ein Hotel geöffnet hat oder eine Detailberatung zu einem Hotel wünscht.
3. FREITEXT / KI-SUCH-VIBE ('aiSearch'):
   - Alle qualitativen Wünsche, Stimmungen, architektonischen Stile, Lagen, Aussichten oder Besonderheiten (z.B. "Dachterrasse", "Panoramablick", "Romantisch", "Historische Altstadt", "Boutique-Flair", "Adults Only", "Ruheoase im Grünen", "Zentrumsnah", "Nahe Sehenswürdigkeiten", "Luxus", "Moderne Zimmer"), MÜSSEN prägnant in 'aiSearch' eingetragen werden!
4. STERNE: "ab 4 Sterne" -> starRating = "4.0,4.5,5.0", "5 Sterne" -> starRating = "5.0".
5. BEWERTUNG: "sehr gut bewertet" -> minRating = 8.0, "hervorragend" -> minRating = 9.0.
6. VERPFLEGUNG: "mit Frühstück" -> boardType = "BI", facilityIds inkl. 11.
7. STORNIERUNG: "kostenlos stornierbar" / "flexibel" -> refundableOnly = true.
8. BUDGET: "maximal 200€ pro Nacht" -> maxPricePerNight = 200.
9. ESSENZIELLE ANGABEN ERKENNEN:
   - Prüfe genau, ob der Nutzer bereits ein konkretes Reiseziel ('cityName' / 'zip'), Reisedaten ('checkin', 'checkout') und Personenanzahl ('adults') genannt hat.
   - Füge jedes Feld, das der Nutzer ausdrücklich genannt hat, in 'userProvidedFields' ein.

Bestehender Zustand: ${JSON.stringify({ ...old.state, ...searchContext })}
Gesamter Gesprächsverlauf:
${transcript}`,
                },
              ],
            },
          ],
          config: {
            temperature: 0,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                cityName: { type: Type.STRING, nullable: true },
                countryCode: { type: Type.STRING, nullable: true },
                hotelName: { type: Type.STRING, nullable: true },
                hotelIds: { type: Type.STRING, nullable: true },
                latitude: { type: Type.NUMBER, nullable: true },
                longitude: { type: Type.NUMBER, nullable: true },
                radius: { type: Type.NUMBER, nullable: true },
                zip: { type: Type.STRING, nullable: true },
                minRating: { type: Type.NUMBER, nullable: true },
                minReviewsCount: { type: Type.NUMBER, nullable: true },
                starRating: { type: Type.STRING, nullable: true },
                maxPricePerNight: { type: Type.NUMBER, nullable: true },
                facilityIds: { type: Type.STRING, nullable: true },
                strictFacilitiesFiltering: { type: Type.BOOLEAN, nullable: true },
                hotelTypeIds: { type: Type.STRING, nullable: true },
                chainIds: { type: Type.STRING, nullable: true },
                boardType: { type: Type.STRING, nullable: true },
                refundableOnly: { type: Type.BOOLEAN, nullable: true },
                bedTypes: { type: Type.STRING, nullable: true },
                aiSearch: { type: Type.STRING, nullable: true },
                advancedAccessibilityOnly: { type: Type.BOOLEAN, nullable: true },
                checkin: { type: Type.STRING, nullable: true },
                checkout: { type: Type.STRING, nullable: true },
                currency: { type: Type.STRING, nullable: true },
                adults: { type: Type.NUMBER, nullable: true },
                isBrainstorming: { type: Type.BOOLEAN, nullable: true },
                wantsHotelAssessment: { type: Type.BOOLEAN, nullable: true },
                mustHaves: { type: Type.ARRAY, items: { type: Type.STRING } },
                niceToHaves: { type: Type.ARRAY, items: { type: Type.STRING } },
                userProvidedFields: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ["mustHaves", "niceToHaves"],
            },
          },
        });

        try { parsed = JSON.parse(extraction.text || "{}"); } catch {}

        if (Array.isArray(parsed.userProvidedFields)) {
          parsed.userProvidedFields.forEach((f: string) => userProvidedSet.add(f));
        }

        for (const [k, v] of Object.entries(parsed)) {
          if (k === "userProvidedFields") continue;
          if (v === null) {
            if (k !== "cityName" && k !== "checkin" && k !== "checkout" && k !== "adults") {
              delete state[k];
              userProvidedSet.delete(k);
            }
          } else if (v !== undefined) {
            state[k] = v;
          }
        }
        state.userProvidedFields = Array.from(userProvidedSet);
      } catch (extErr) {
        console.warn("[AI Advisor] Gemini extraction fallback engaged:", extErr);
        state = fallbackExtractParams(messages, state);
      }

      state.cityName = clean(state.cityName);
      state.countryCode = state.countryCode?.toUpperCase();
      state.currency = (state.currency || "EUR").toUpperCase();
      state.adults = Number(state.adults) || undefined;
      state.mustHaves = normList(state.mustHaves);
      state.niceToHaves = normList(state.niceToHaves);
      state.userProvidedFields = Array.from(new Set([...(state.userProvidedFields || []), ...Array.from(userProvidedSet)]));

      // Resolve German city name to LiteAPI standard English city name & country
      if (state.cityName) {
        const resolved = await resolvePlace(state.cityName, state.countryCode);
        if (resolved.cityName) state.cityName = resolved.cityName;
        if (resolved.countryCode) state.countryCode = resolved.countryCode;
      }

      // Check if essential parameters are provided or missing
      const hasDestination = Boolean(state.cityName || state.zip || (state.latitude && state.longitude));
      const hasDates = Boolean(
        state.checkin &&
        state.checkout &&
        /^\d{4}-\d{2}-\d{2}$/.test(state.checkin) &&
        /^\d{4}-\d{2}-\d{2}$/.test(state.checkout) &&
        Date.parse(state.checkout) > Date.parse(state.checkin)
      );
      const hasAdults = Boolean(state.adults && Number(state.adults) > 0);

      // Check if user specifically requested a hotel detail evaluation for an opened hotel
      const isEvaluatingOpenedHotel = Boolean(openedHotel && (parsed.wantsHotelAssessment || openedHotel.id === state.hotelIds));

      // If user is in brainstorming mode or essential parameters are missing (and not evaluating a single opened hotel):
      if (!isEvaluatingOpenedHotel && (parsed.isBrainstorming || !hasDestination || !hasDates || !hasAdults)) {
        advisorSessions.set(sessionId, { ...old, state, updatedAt: Date.now() });

        let consultationMessage = "";
        try {
          const brainstormPrompt = `Du bist der "LiteAPI KI Berater" – kompetent, klar und sparsam mit Worten.
Du berätst wie ein erfahrenes Reisebüro: maximal übersichtlich, fast nur Stichpunkte.

Status des Gesprächs:
- Reiseziel: ${state.cityName || "Noch offen"}
- Reisedaten: ${hasDates ? `${state.checkin} bis ${state.checkout}` : "Noch offen"}
- Personen: ${hasAdults ? `${state.adults} Personen` : "Noch offen"}
- Wünsche/Vibe: ${[
  state.aiSearch ? `Vibe: "${state.aiSearch}"` : "",
  state.facilityIds ? `Ausstattung: ${state.facilityIds}` : "",
  state.starRating ? `Sterne: ${state.starRating}` : "",
  state.boardType ? `Verpflegung: ${state.boardType}` : "",
  state.refundableOnly ? "Kostenlos stornierbar" : "",
  state.maxPricePerNight ? `Budget: max. ${state.maxPricePerNight}€/Nacht` : "",
].filter(Boolean).join(", ") || "Noch offen"}

Nutzer-Nachricht:
"${messages[messages.length - 1]?.content || ""}"

STRENGSTE FORMATIERUNGS-REGELN (immer einhalten):
1. KEINE Begrüßungsfloskeln, kein "Hallo", kein "Schön, dass Sie da sind", kein "ich freue mich riesig", keine Wiederholung von Willkommenssätzen. Solche Sätze sind VERBOTEN.
2. Genau EIN kurzer, freundlicher Einleitungssatz – nur wenn Infos fehlen: erkläre knapp, wofür die Angaben gebraucht werden. Bei Tipps/Erklärungen: ein kompakter Sachsatz, keine Ausschmückung.
3. Alle echten Fragen an den Nutzer NUR als Stichpunkte mit genau EINEM fetten Schlagwort:
   - **Personen**: …
   - **Reiseziel**: …
   - **Reisedaten**: …
   - **Wünsche**: …
4. Brainstorming von Zielen: 2–3 Vorschläge als Stichpunkte, **Stadtname** fett + ein kompakter Satz warum passend. Danach eine Frage: - **Favorit**: …
5. Insider-Tipps und Erklärungen: kurze, kompakte Sätze oder Stichpunkte – nie lange Absätze.
6. Keine technischen Such-/API-Zeilen, keine Parameter-Listen, kein "Gefiltert/Suche", keine [user]/[assumed]-Tags im Antworttext.
7. Maximal übersichtlich, knackig, fast nur Stichpunkte.`;

          const clarify = await generateGeminiContentWithRetry({
            model: "gemini-3.1-flash-lite",
            contents: [{ role: "user", parts: [{ text: brainstormPrompt }] }],
            config: { temperature: 0.2 },
          });
          consultationMessage = clarify.text || "";
        } catch {
          consultationMessage = `Damit ich passende Hotels live finden und vergleichen kann, brauche ich noch diese Angaben:\n\n- **Personen**: Wie viele Gäste reisen mit?\n- **Reiseziel**: Wohin soll es gehen – oder gemeinsam brainstormen?\n- **Reisedaten**: Welcher Zeitraum ist geplant?`;
        }

        return res.json({
          message: consultationMessage,
          recommendedHotels: old.recommended,
          extractedParams: state,
          searchPerformed: false,
        });
      }

      const sig = signature(state);
      let raw = fresh(ratesCache.get(sig));
      let searched = false;

      if (!raw || forceRefresh) {
        const body: any = {
          checkin: state.checkin,
          checkout: state.checkout,
          currency: state.currency || "EUR",
          guestNationality: "DE",
          occupancies: [{ adults: state.adults || 2 }],
          roomMapping: true,
          maxRatesPerHotel: 1,
          includeHotelData: true,
          limit: 200,
          timeout: 10,
          sessionId,
        };

        if (state.cityName && state.countryCode) {
          body.cityName = state.cityName;
          body.countryCode = state.countryCode;
        } else if (state.latitude && state.longitude) {
          body.latitude = Number(state.latitude);
          body.longitude = Number(state.longitude);
          if (state.radius) body.radius = Number(state.radius);
        } else if (state.zip) {
          body.zip = String(state.zip);
        }

        if (state.hotelName) body.hotelName = String(state.hotelName);
        if (state.hotelIds) body.hotelIds = String(state.hotelIds).split(",").map((x: string) => x.trim()).filter(Boolean);

        if (state.starRating) {
          const stars = String(state.starRating).split(",").map((x: string) => Number(x.trim())).filter((x: number) => !isNaN(x));
          if (stars.length) body.starRating = stars;
        }

        if (state.facilityIds) {
          const facs = String(state.facilityIds).split(",").map((x: string) => Number(x.trim())).filter((x: number) => !isNaN(x));
          if (facs.length) {
            body.facilities = facs;
            if (state.strictFacilitiesFiltering !== undefined) {
              body.strictFacilityFiltering = Boolean(state.strictFacilitiesFiltering);
            }
          }
        }

        if (state.hotelTypeIds) {
          const types = String(state.hotelTypeIds).split(",").map((x: string) => Number(x.trim())).filter((x: number) => !isNaN(x));
          if (types.length) body.hotelTypeIds = types;
        }

        if (state.chainIds) {
          const chains = String(state.chainIds).split(",").map((x: string) => Number(x.trim())).filter((x: number) => !isNaN(x));
          if (chains.length) body.chainIds = chains;
        }

        if (state.minRating) body.minRating = Number(state.minRating);
        if (state.minReviewsCount) body.minReviewsCount = Number(state.minReviewsCount);

        if (state.boardType) body.boardType = String(state.boardType);
        if (state.refundableOnly) body.refundableRatesOnly = true;

        if (state.bedTypes) {
          const beds = String(state.bedTypes).split(",").map((x: string) => x.trim()).filter(Boolean);
          if (beds.length) body.bedTypes = beds;
        }

        if (state.advancedAccessibilityOnly) body.advancedAccessibilityOnly = true;
        if (state.aiSearch) body.aiSearch = String(state.aiSearch);

        raw = await lite("https://api.liteapi.travel/v3.0/hotels/rates", {
          method: "POST",
          headers: headers(),
          body: JSON.stringify(body),
        });

        // Fallback search if strict filtering yielded 0 hotels:
        // No soft-retry: zero results with filters means no matching hotels.

        ratesCache.set(sig, { data: raw, timestamp: Date.now() });
        searched = true;
      }

      const base = mapHotels(raw, state);
      let recommended = filterHotels(base, state);
      try {
        const highlightMap = await generateHotelHighlights(recommended.slice(0, 3));
        if (highlightMap.size > 0) {
          recommended = recommended.map((h: any) => {
            const aiHighlight = highlightMap.get(String(h.hotelId));
            return aiHighlight ? { ...h, aiHighlight } : h;
          });
        }
      } catch (hlErr) {
        console.warn("[advisor] highlight enrichment failed:", hlErr);
      }
      advisorSessions.set(sessionId, { state, rawHotels: base, recommended, signature: sig, updatedAt: Date.now() });

      // Construct Transparenz-Zeile
      const providedSet = new Set(state.userProvidedFields || []);
      const tag = (key: string) => (providedSet.has(key) ? "[user]" : "[assumed]");

      const filterParts = [];
      if (state.countryCode) filterParts.push(`countryCode=${state.countryCode} ${tag("countryCode")}`);
      if (state.cityName) filterParts.push(`cityName=${state.cityName} ${tag("cityName")}`);
      if (state.hotelName) filterParts.push(`hotelName=${state.hotelName} ${tag("hotelName")}`);
      if (state.hotelIds) filterParts.push(`hotelIds=${state.hotelIds} ${tag("hotelIds")}`);
      if (state.zip) filterParts.push(`zip=${state.zip} ${tag("zip")}`);
      if (state.latitude && state.longitude) {
        filterParts.push(`latitude=${state.latitude} ${tag("latitude")}`);
        filterParts.push(`longitude=${state.longitude} ${tag("longitude")}`);
        filterParts.push(`radius=${state.radius || 5000} ${tag("radius")}`);
      }
      if (state.minRating) filterParts.push(`minRating=${state.minRating} ${tag("minRating")}`);
      if (state.minReviewsCount) filterParts.push(`minReviewsCount=${state.minReviewsCount} ${tag("minReviewsCount")}`);
      if (state.starRating) filterParts.push(`starRating=${state.starRating} ${tag("starRating")}`);
      if (state.facilityIds) filterParts.push(`facilityIds=${state.facilityIds} ${tag("facilityIds")}`);
      filterParts.push(`strictFacilitiesFiltering=${Boolean(state.strictFacilitiesFiltering)} ${tag("strictFacilitiesFiltering")}`);
      if (state.hotelTypeIds) filterParts.push(`hotelTypeIds=${state.hotelTypeIds} ${tag("hotelTypeIds")}`);
      if (state.chainIds) filterParts.push(`chainIds=${state.chainIds} ${tag("chainIds")}`);
      if (state.boardType) filterParts.push(`boardType=${state.boardType} ${tag("boardType")}`);
      if (state.refundableOnly) filterParts.push(`refundableOnly=true ${tag("refundableOnly")}`);
      if (state.bedTypes) filterParts.push(`bedTypes=${state.bedTypes} ${tag("bedTypes")}`);
      if (state.aiSearch) filterParts.push(`aiSearch=${state.aiSearch} ${tag("aiSearch")}`);
      if (state.advancedAccessibilityOnly) filterParts.push(`advancedAccessibilityOnly=true ${tag("advancedAccessibilityOnly")}`);
      filterParts.push(`limit=50 [assumed]`);
      filterParts.push(`offset=0 [assumed]`);
      filterParts.push(`language=de [assumed]`);

      const transparencyLine = `Gefiltert/Suche (GET /data/hotels): ${filterParts.join(", ")}`;

      const factual = { state, hotels: recommended, openedHotel: openedHotel || null, transparencyLine };

      let answerText = "";
      try {
        const isHotelDetailMode = Boolean(openedHotel);

        const promptText = isHotelDetailMode
          ? `DU BIST: Der "LiteAPI KI Berater" – klar, kompetent, stichpunktstark.
Der Gast hat ein Hotel ausgewählt:
HOTEL-DETAILS:
Name: ${openedHotel?.name}
Sterne: ${openedHotel?.starRating || "Hotel"}
Ort: ${openedHotel?.city || state.cityName}, ${openedHotel?.country || state.countryCode}
Adresse: ${openedHotel?.address || "Zentrale Lage"}
Gästebewertung: ${openedHotel?.rating ? openedHotel.rating + "/10" : "Beliebt"} (${openedHotel?.reviewsCount || 0} Bewertungen)
Ausstattung: ${(openedHotel?.hotelFacilities || openedHotel?.facilities || []).slice(0, 10).join(", ")}
Beschreibung: ${openedHotel?.hotelDescription ? openedHotel.hotelDescription.slice(0, 400) : "Keine Detailbeschreibung"}

REISE-KONTEXT:
Zielort: ${state.cityName}, Zeitraum: ${state.checkin} bis ${state.checkout}, ${state.adults || 2} Erwachsene, Wünsche: ${state.aiSearch || "Standard"}

FORMATIERUNGS-REGELN (streng):
1) KEINE Begrüßungsfloskeln (kein Hallo, kein "Schön dass Sie…", kein "ich freue mich").
2) Genau EIN kurzer Einleitungssatz, dann nur Stichpunkte.
3) Einschätzung zu **${openedHotel?.name}** so:
   - **Reisetyp**: Für wen passt es?
   - **Lage**: Anbindung, Umgebung, Ausflüge.
   - **Ausstattung**: Das Highlight (Frühstück, Wellness, Dachterrasse…).
   - **Vorteile**: 2–3 kurze Pluspunkte, die dieses Hotel auszeichnen.
   - **Nachteile**: 1–2 ehrliche Einschränkungen (Lage, Preis, Größe, Lärm…).
   - **Fazit**: Ein kompakter Abwägungssatz (für wen lohnt es sich / wann eher nicht).
4) Tipps als kurze Sätze, keine langen Absätze.
5) Niemals technische Suchzeilen, API-Parameter oder [user]/[assumed]-Tags im Text.`
          : `DU BIST: Der "LiteAPI KI Berater" – klar, kompetent, stichpunktstark.
Live-Suche ist durch. Die Hotels stehen bereits in Liste und Karte – NIEMALS als Liste vorlesen.

FORMATIERUNGS-REGELN (streng):
1) KEINE Begrüßungsfloskeln (kein Hallo, kein "Schön dass Sie…", kein "ich freue mich riesig").
2) Genau EIN kurzer Einleitungssatz, z. B.: "Für **${state.cityName || "Ihre Zielregion"}** (${state.checkin}–${state.checkout}, ${state.adults || 2} Gäste) sind passende Hotels in Liste und Karte geladen."
3) Dann nur Stichpunkte mit fettem 1-Wort-Schlagwort:
   - **Lage**: Worauf bei der Viertel-Wahl achten?
   - **Ausstattung**: Welcher Komfort lohnt sich hier?
   - **Buchungstipp**: Stornierung, City-Tax oder Bestpreis – ein knapper Tipp.
4) Optional ein knapper Schlusssatz: "Klicken Sie ein Hotel in der Liste für meine Einschätzung."
5) Keine Hotel-Aufzählung, keine technischen Such-/Filter-Zeilen, kein "Gefiltert/Suche", keine [user]/[assumed]-Tags.
6) Maximal übersichtlich – fast nur Stichpunkte.`;

        const answer = await generateGeminiContentWithRetry({
          model: "gemini-3.1-flash-lite",
          contents: [{ role: "user", parts: [{ text: promptText + profileContext }] }],
          config: { temperature: 0.2 },
        });
        answerText = (answer.text || "")
          .split("\n")
          .filter((line: string) => !/Gefiltert\/Suche\s*\(GET/i.test(line))
          .join("\n")
          .trim();
      } catch (ansErr) {
        console.warn("[AI Advisor] Gemini answer generation fallback engaged:", ansErr);
        answerText =
          `Für **${state.cityName || "Ihre Zielregion"}** (${state.checkin}–${state.checkout}, ${state.adults || 2} Gäste) sind die aktuellen Angebote in Liste und Karte geladen.\n\n` +
          `- **Lage**: Gute Anbindung oder fußläufige Altstadt-Nähe bevorzugen.\n` +
          `- **Komfort**: Frühstück inklusive und flexible Stornierung lohnen sich oft.\n` +
          `- **Tipp**: Hotel in der Liste anklicken für eine kurze Einschätzung.`;
      }

      return res.json({
        message: answerText,
        recommendedHotels: recommended,
        extractedParams: state,
        searchPerformed: searched,
        searchSignature: sig,
      });
    } catch (err: any) {
      console.error("AI Advisor Chat Error:", err);
      return res.status(500).json({
        error: "Fehler beim Ausführen der KI-Beratung.",
        retryable: false,
      });
    }
  });

  app.post("/api/excursion-advisor/chat", async (req, res) => {
    try {
      const { address, messages, userProfile } = req.body;
      const profileContext = formatUserProfileContext(userProfile);

      if (!address || typeof address !== "string" || !address.trim()) {
        return res.status(400).json({
          error: "Bitte gib eine gültige Adresse oder einen Standort an.",
        });
      }

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({
          error: "Mindestens eine Nachricht ist erforderlich.",
        });
      }

      const formattedContents = messages
        .filter((m: any) => m && typeof m.content === "string" && m.content.trim())
        .map((m: any) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content.trim() }],
        }));

      if (formattedContents.length === 0) {
        return res.status(400).json({
          error: "Keine gültigen Textnachrichten übermittelt.",
        });
      }

      // Ensure the first message is from 'user'
      if (formattedContents[0].role !== "user") {
        formattedContents.unshift({
          role: "user",
          parts: [{ text: `Ich starte meine Ausflugsplanung für den Standort: ${address.trim()}` }],
        });
      }

      const systemInstruction = `Du bist der persönliche KI-Ausflugsberater.
Der Nutzer befindet sich aktuell an folgendem Standort/Adresse:
📍 "${address.trim()}"

Deine Aufgabe ist es, fundierte, maßgeschneiderte und praxisnahe Ausflugstipps, Sehenswürdigkeiten, Aktivitäten, Naturerlebnisse, Kultur-Highlights oder gastronomische Empfehlungen rund um diesen Ort zu geben.

REGELN FÜR DEINE ANTWORTEN:
1. Gehe präzise und direkt auf die Fragen, Wünsche und Interessen des Nutzers ein (z. B. Natur, Familie, Regenwetter/Indoor, Kultur, Action, Romantik, Essen).
2. Nenne zu jeder Empfehlung:
   - Den konkreten Namen des Ziels / der Sehenswürdigkeit
   - Die ungefähre Entfernung / Fahrzeit bzw. Erreichbarkeit von "${address.trim()}" (z.B. "ca. 10 Min. zu Fuß", "ca. 20 Min. mit der S-Bahn", "ca. 15 km mit dem Auto")
   - Warum es sich lohnt / Was man dort erleben kann
   - Praktische Tipps (z. B. beste Tageszeit, Kosten/Eintritt, Öffnungszeiten-Hinweis, passende Ausrüstung)
3. Formatiere deine Antwort übersichtlich mit klaren Absätzen, Aufzählungszeichen und fetten Überschriften.
4. Halte den Tonfall inspirierend, freundlich, kompetent und direkt auf den Punkt (keine ausschweifenden Füllsätze).
5. Bei Nachfragen oder Folgefragen beziehe dich nahtlos auf den bisherigen Gesprächskontext.${profileContext}`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.7-flash",
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.4,
        },
      });

      const text = response.text || "";

      if (!text.trim()) {
        return res.status(500).json({
          error: "Die KI hat keine Antwort generiert. Bitte versuche es erneut.",
        });
      }

      return res.json({
        message: text.trim(),
      });
    } catch (err: any) {
      console.error("Excursion Advisor Chat Error:", err);
      const isQuota = isQuotaExceededError(err);
      return res.status(500).json({
        error: isQuota
          ? "Das Anfrage-Limit für die KI wurde kurzzeitig erreicht. Bitte warte einen kurzen Moment und versuche es erneut."
          : "Beim Laden der Ausflugstipps ist ein Fehler aufgetreten. Bitte versuche es erneut.",
      });
    }
  });

  // ─── Weather & Climate Resolver for Packing Advisor & Trips ───
  async function resolveDestinationWeather(
    tripOrQuery: any,
    checkinArg?: string,
    checkoutArg?: string,
    latArg?: number,
    lngArg?: number,
    hotelNameArg?: string,
    hotelAddressArg?: string,
    hotelIdArg?: string
  ): Promise<{
    destination: string;
    hotelName?: string;
    hotelAddress?: string;
    city?: string;
    country?: string;
    latitude: number;
    longitude: number;
    locationDetails: string;
    periodText: string;
    isLiveForecast: boolean;
    temperatureText: string;
    precipitationText: string;
    uvIndexText?: string;
    windText?: string;
    conditionsText: string;
    dailySummary?: string;
    packingAdviceHint: string;
  } | null> {
    try {
      let destinationQuery = "";
      let checkin = checkinArg;
      let checkout = checkoutArg;
      let lat = latArg;
      let lng = lngArg;
      let hotelName = hotelNameArg || "";
      let hotelAddress = hotelAddressArg || "";
      let hotelId = hotelIdArg || "";
      let city = "";
      let country = "";

      if (typeof tripOrQuery === "string") {
        destinationQuery = tripOrQuery.trim();
      } else if (tripOrQuery && typeof tripOrQuery === "object") {
        hotelName = tripOrQuery.hotelName || hotelName || "";
        hotelAddress = tripOrQuery.hotelAddress || hotelAddress || "";
        hotelId = tripOrQuery.hotelId || hotelId || "";
        city = tripOrQuery.destinationCity || tripOrQuery.city || "";
        country = tripOrQuery.destinationCountry || tripOrQuery.country || "";
        checkin = tripOrQuery.checkin || checkin || "";
        checkout = tripOrQuery.checkout || checkout || "";
        if (typeof tripOrQuery.destinationLat === "number" && Number.isFinite(tripOrQuery.destinationLat)) {
          lat = tripOrQuery.destinationLat;
        } else if (typeof tripOrQuery.lat === "number" && Number.isFinite(tripOrQuery.lat)) {
          lat = tripOrQuery.lat;
        }
        if (typeof tripOrQuery.destinationLng === "number" && Number.isFinite(tripOrQuery.destinationLng)) {
          lng = tripOrQuery.destinationLng;
        } else if (typeof tripOrQuery.lng === "number" && Number.isFinite(tripOrQuery.lng)) {
          lng = tripOrQuery.lng;
        }
        destinationQuery = [city, country, hotelName, hotelAddress].filter(Boolean).join(", ") || hotelName || city || "";
      }

      let resolvedLat = lat;
      let resolvedLng = lng;
      let resolvedName = hotelName || city || destinationQuery;
      let countryName = country;
      let exactAddress = hotelAddress;

      // 1) If hotelId is provided but lat/lng missing, try LiteAPI hotel details
      if ((resolvedLat == null || resolvedLng == null) && hotelId) {
        try {
          const cached = detailsCache.get(hotelId);
          let hData = cached?.data;
          if (!hData) {
            const hRes = await fetch(
              `https://api.liteapi.travel/v3.0/data/hotel?hotelId=${encodeURIComponent(hotelId)}`,
              { headers: headers() }
            );
            if (hRes.ok) {
              const parsed = (await hRes.json()) as any;
              hData = parsed?.data;
            }
          }
          if (hData) {
            if (typeof hData.location?.latitude === "number" && typeof hData.location?.longitude === "number") {
              resolvedLat = hData.location.latitude;
              resolvedLng = hData.location.longitude;
            }
            if (hData.name && !hotelName) hotelName = hData.name;
            if (hData.address && !exactAddress) exactAddress = hData.address;
            if (hData.city && !city) city = hData.city;
            if (hData.country && !countryName) countryName = hData.country;
          }
        } catch {
          // ignore LiteAPI error and continue
        }
      }

      // 2) If still missing coordinates, geocode via OpenStreetMap Nominatim with hotel-level queries
      if (resolvedLat == null || resolvedLng == null) {
        const queriesToTry: string[] = [];
        if (hotelName && exactAddress) queriesToTry.push(`${hotelName}, ${exactAddress}`);
        if (hotelName && city) queriesToTry.push(`${hotelName}, ${city}`);
        if (exactAddress) queriesToTry.push(exactAddress);
        if (hotelName) queriesToTry.push(hotelName);
        if (city && countryName) queriesToTry.push(`${city}, ${countryName}`);
        if (destinationQuery && !queriesToTry.includes(destinationQuery)) queriesToTry.push(destinationQuery);

        for (const q of queriesToTry) {
          if (!q.trim()) continue;
          try {
            const nomParams = new URLSearchParams({
              format: "json",
              q: q.trim(),
              limit: "1",
              addressdetails: "1",
            });
            const nomRes = await fetch(`https://nominatim.openstreetmap.org/search?${nomParams}`, {
              headers: {
                Accept: "application/json",
                "Accept-Language": "de,en",
                "User-Agent": "NuiteeStays/1.0 (hotel-booking; contact@nuitee.local)",
              },
            });
            if (nomRes.ok) {
              const nomList = (await nomRes.json()) as any[];
              if (Array.isArray(nomList) && nomList.length > 0) {
                const first = nomList[0];
                const parsedLat = Number(first.lat);
                const parsedLng = Number(first.lon);
                if (Number.isFinite(parsedLat) && Number.isFinite(parsedLng)) {
                  resolvedLat = parsedLat;
                  resolvedLng = parsedLng;
                  if (!resolvedName) resolvedName = first.name || hotelName || city;
                  if (!countryName && first.address?.country) countryName = first.address.country;
                  if (!city && (first.address?.city || first.address?.town || first.address?.village)) {
                    city = first.address.city || first.address.town || first.address.village;
                  }
                  if (!exactAddress && first.display_name) {
                    exactAddress = first.display_name;
                  }
                  break;
                }
              }
            }
          } catch {
            // continue next query
          }
        }
      }

      // 3) Final fallback: Open-Meteo search
      if (resolvedLat == null || resolvedLng == null) {
        if (destinationQuery || city) {
          const cleanQ = (city || destinationQuery).split(",")[0].trim();
          try {
            const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
              cleanQ
            )}&count=1&language=de&format=json`;
            const geoRes = await fetch(geoUrl);
            if (geoRes.ok) {
              const geoData = (await geoRes.json()) as any;
              if (geoData.results && geoData.results.length > 0) {
                const first = geoData.results[0];
                resolvedLat = first.latitude;
                resolvedLng = first.longitude;
                if (!resolvedName) resolvedName = first.name;
                if (!countryName) countryName = first.country || "";
              }
            }
          } catch {
            // ignore
          }
        }
      }

      if (resolvedLat == null || resolvedLng == null) return null;

      const now = new Date();
      now.setHours(0, 0, 0, 0);

      let checkinDate: Date | null = null;
      let checkoutDate: Date | null = null;

      if (checkin) {
        const parsed = new Date(checkin);
        if (!Number.isNaN(parsed.getTime())) checkinDate = parsed;
      }
      if (checkout) {
        const parsed = new Date(checkout);
        if (!Number.isNaN(parsed.getTime())) checkoutDate = parsed;
      }

      const travelMonth = checkinDate ? checkinDate.getMonth() : now.getMonth();
      const monthNames = [
        "Januar", "Februar", "März", "April", "Mai", "Juni",
        "Juli", "August", "September", "Oktober", "November", "Dezember"
      ];
      const travelMonthName = monthNames[travelMonth];

      let daysUntilCheckin = 0;
      if (checkinDate) {
        daysUntilCheckin = Math.ceil((checkinDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      }

      const isWithinForecastRange = daysUntilCheckin >= -2 && daysUntilCheckin <= 14;

      const locationDetails = [
        hotelName ? `Hotel "${hotelName}"` : "",
        exactAddress ? `Adresse: ${exactAddress}` : "",
        city ? `Ort: ${city}` : "",
        countryName ? `Land: ${countryName}` : "",
        `Exakte GPS-Koordinaten: ${resolvedLat.toFixed(4)}°N, ${resolvedLng.toFixed(4)}°E`,
      ].filter(Boolean).join(" | ");

      if (isWithinForecastRange) {
        const fcUrl = `https://api.open-meteo.com/v1/forecast?latitude=${resolvedLat}&longitude=${resolvedLng}&daily=weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,uv_index_max&timezone=auto&forecast_days=16&current=temperature_2m,apparent_temperature,weather_code,relative_humidity_2m,wind_speed_10m,wind_gusts_10m,precipitation,uv_index`;
        const fcRes = await fetch(fcUrl);
        if (fcRes.ok) {
          const fcData = (await fcRes.json()) as any;
          const daily = fcData.daily;
          if (daily && Array.isArray(daily.time) && daily.time.length > 0) {
            let indices: number[] = daily.time.map((_: any, i: number) => i);
            if (checkinDate && checkoutDate) {
              const cinStr = checkinDate.toISOString().split("T")[0];
              const coutStr = checkoutDate.toISOString().split("T")[0];
              const tripIndices = daily.time
                .map((t: string, idx: number) => (t >= cinStr && t <= coutStr ? idx : -1))
                .filter((idx: number) => idx !== -1);
              if (tripIndices.length > 0) {
                indices = tripIndices;
              }
            } else {
              indices = indices.slice(0, 7);
            }

            const maxTemps = indices.map((i: number) => daily.temperature_2m_max[i]).filter((v: any) => typeof v === "number");
            const minTemps = indices.map((i: number) => daily.temperature_2m_min[i]).filter((v: any) => typeof v === "number");
            const rainProbs = indices.map((i: number) => daily.precipitation_probability_max?.[i] ?? 0);
            const rainSums = indices.map((i: number) => daily.precipitation_sum?.[i] ?? 0);
            const uvIndexes = indices.map((i: number) => daily.uv_index_max?.[i] ?? 0);
            const windSpeeds = indices.map((i: number) => daily.wind_speed_10m_max?.[i] ?? 0);

            const highestMax = maxTemps.length > 0 ? Math.max(...maxTemps) : 22;
            const lowestMin = minTemps.length > 0 ? Math.min(...minTemps) : 14;
            const maxRainProb = rainProbs.length > 0 ? Math.max(...rainProbs) : 0;
            const totalRainMm = rainSums.reduce((a: number, b: number) => a + b, 0);
            const maxUv = uvIndexes.length > 0 ? Math.max(...uvIndexes) : 5;
            const maxWind = windSpeeds.length > 0 ? Math.max(...windSpeeds) : 15;

            const isRainy = maxRainProb >= 40 || totalRainMm >= 5;
            const isCold = highestMax < 15;
            const isHot = highestMax >= 26;

            const desc = isHot
              ? "Sonnig, warm bis sommerlich"
              : isCold
              ? "Kühl / herbstlich-frisch"
              : "Angenehm mild & heiter";

            const currentTemp = fcData.current?.temperature_2m != null ? `${Math.round(fcData.current.temperature_2m)}°C` : "";

            const periodText = checkinDate && checkoutDate
              ? `${checkinDate.toLocaleDateString("de-DE")} – ${checkoutDate.toLocaleDateString("de-DE")}`
              : "Nächste Tage";

            // Daily breakdown summary during the trip
            const dailyLines = indices.slice(0, 7).map((i: number) => {
              const dayStr = daily.time[i];
              const maxT = Math.round(daily.temperature_2m_max[i] ?? 20);
              const minT = Math.round(daily.temperature_2m_min[i] ?? 15);
              const rProb = daily.precipitation_probability_max?.[i] ?? 0;
              const rMm = (daily.precipitation_sum?.[i] ?? 0).toFixed(1);
              const uv = daily.uv_index_max?.[i] ?? 5;
              return `    * ${dayStr}: ${maxT}°C / ${minT}°C (Regenrisiko: ${rProb}%, ${rMm} mm, UV-Index: ${uv})`;
            });

            return {
              destination: resolvedName + (countryName ? `, ${countryName}` : ""),
              hotelName: hotelName || undefined,
              hotelAddress: exactAddress || undefined,
              city: city || undefined,
              country: countryName || undefined,
              latitude: resolvedLat,
              longitude: resolvedLng,
              locationDetails,
              periodText,
              isLiveForecast: true,
              temperatureText: `${Math.round(lowestMin)}°C bis ${Math.round(highestMax)}°C ${currentTemp ? `(aktuell am Hotel: ${currentTemp})` : ""}`,
              precipitationText: isRainy ? `Regenrisiko bis zu ${maxRainProb}% (ca. ${Math.round(totalRainMm)} mm am Hotel)` : `Sehr geringes Regenrisiko (max. ${maxRainProb}%)`,
              uvIndexText: `Max. UV-Index ${Math.round(maxUv)} (${maxUv >= 8 ? "sehr hoch – LSF 50+ & Sonnenhut dringend empfohlen" : maxUv >= 6 ? "hoch – guter Sonnenschutz & Sonnenbrille nötig" : "moderat"})`,
              windText: `Wind bis ca. ${Math.round(maxWind)} km/h`,
              conditionsText: desc,
              dailySummary: dailyLines.join("\n"),
              packingAdviceHint: isHot
                ? `Sonnenschutz (Creme LSF ${maxUv >= 8 ? "50+" : "30-50"}, UV-Sonnenbrille, Kopfbedeckung), leichte Sommermode, Badesachen, atmungsaktive Stoffe, 1 leichte Strickjacke/Hemd für klimatisierte Hotelbereiche oder laue Abende.`
                : isCold
                ? `Wärmende Schichten (Pullover, Fleece), wind-/wetterfeste Jacke, feste bequeme Schuhe, Regenschutz.`
                : `Zwiebellook (T-Shirts + dünne Pullover/leichte Jacke), bequeme Gehschuhe für Stadterkundungen, kleiner Schirm.`,
            };
          }
        }
      }

      // Climate Archive fallback (10-year monthly historical average at exact hotel coordinates)
      const endYear = new Date().getFullYear() - 1;
      const startYear = endYear - 9;
      const clUrl = `https://archive-api.open-meteo.com/v1/archive?latitude=${resolvedLat}&longitude=${resolvedLng}&start_date=${startYear}-01-01&end_date=${endYear}-12-31&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto`;
      const clRes = await fetch(clUrl);
      if (clRes.ok) {
        const clData = (await clRes.json()) as any;
        if (clData.daily && Array.isArray(clData.daily.time)) {
          const monthMaxs: number[] = [];
          const monthMins: number[] = [];
          let monthRainSum = 0;
          let monthRainDays = 0;

          clData.daily.time.forEach((tStr: string, idx: number) => {
            const d = new Date(`${tStr}T12:00:00`);
            if (d.getMonth() === travelMonth) {
              const max = clData.daily.temperature_2m_max[idx];
              const min = clData.daily.temperature_2m_min[idx];
              const p = clData.daily.precipitation_sum[idx] || 0;
              if (typeof max === "number") monthMaxs.push(max);
              if (typeof min === "number") monthMins.push(min);
              monthRainSum += p;
              if (p >= 1) monthRainDays++;
            }
          });

          const avgMax = monthMaxs.length > 0 ? monthMaxs.reduce((a, b) => a + b, 0) / monthMaxs.length : 22;
          const avgMin = monthMins.length > 0 ? monthMins.reduce((a, b) => a + b, 0) / monthMins.length : 14;
          const avgRainDays = Math.round(monthRainDays / 10);
          const avgRainMm = Math.round(monthRainSum / 10);

          const isHot = avgMax >= 26;
          const isCold = avgMax < 14;

          const periodText = checkinDate && checkoutDate
            ? `${checkinDate.toLocaleDateString("de-DE")} – ${checkoutDate.toLocaleDateString("de-DE")} (${travelMonthName})`
            : `Reisemonat ${travelMonthName}`;

          return {
            destination: resolvedName + (countryName ? `, ${countryName}` : ""),
            hotelName: hotelName || undefined,
            hotelAddress: exactAddress || undefined,
            city: city || undefined,
            country: countryName || undefined,
            latitude: resolvedLat,
            longitude: resolvedLng,
            locationDetails,
            periodText,
            isLiveForecast: false,
            temperatureText: `Ø ${Math.round(avgMax)}°C tagsüber / Ø ${Math.round(avgMin)}°C nachts (10-Jahres-Klimaschnitt am Hotelstandort für ${travelMonthName})`,
            precipitationText: `ca. ${avgRainDays} Regentage im Monat (${avgRainMm} mm Gesamtniederschlag)`,
            uvIndexText: isHot ? "Hohe bis sehr hohe Sonneneinstrahlung im Reisemonat" : "Moderate Sonneneinstrahlung",
            conditionsText: isHot ? `Typisches warmes/heißes Klima im ${travelMonthName}` : isCold ? `Kühles / herbstlich-winterliches Klima im ${travelMonthName}` : `Mildes Übergangsklima im ${travelMonthName}`,
            packingAdviceHint: isHot
              ? `Leichte Sommerbekleidung, UV- und Sonnenschutz (LSF 30-50), Badesachen, leichte Abendkleidung.`
              : isCold
              ? `Warme Jacke, wetterfeste Schuhe, wärmende Schichten, Regenschutz.`
              : `Vielseitige Übergangskleidung, Schichtenprinzip, bequeme Schuhe, leichter Regenschutz.`,
          };
        }
      }

      return null;
    } catch (err) {
      console.warn("[WeatherResolver] Error resolving weather:", err);
      return null;
    }
  }

  app.post("/api/packing-advisor/chat", async (req, res) => {
    try {
      const { messages, packingLists, userProfile, nextTrip, upcomingTrips, allTrips } = req.body || {};
      const profileContext = formatUserProfileContext(userProfile);

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({
          error: "Mindestens eine Nachricht ist erforderlich.",
        });
      }

      const formattedContents = messages
        .filter((m: any) => m && typeof m.content === "string" && m.content.trim())
        .map((m: any) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content.trim() }],
        }));

      if (formattedContents.length === 0) {
        return res.status(400).json({
          error: "Keine gültigen Textnachrichten übermittelt.",
        });
      }

      if (formattedContents[0].role !== "user") {
        formattedContents.unshift({
          role: "user",
          parts: [{ text: "Ich starte die Packlisten-Beratung." }],
        });
      }

      // Collect user bookings & fetch high-precision weather reports for each exact hotel location
      const upcomingList: any[] = Array.isArray(upcomingTrips) ? upcomingTrips : [];
      const primaryTrip: any = nextTrip || (upcomingList.length > 0 ? upcomingList[0] : null);

      const weatherReportLines: string[] = [];

      if (primaryTrip) {
        const tripWeather = await resolveDestinationWeather(primaryTrip);

        weatherReportLines.push(
          `### 🏖️ AKTUELLE / NÄCHSTE REISE (Punktgenauer Hotelstandort):
- Hotel & Ort: ${primaryTrip.hotelName ? `Hotel "${primaryTrip.hotelName}"` : "Hotel"} in ${primaryTrip.destinationCity || ""}${primaryTrip.destinationCountry ? `, ${primaryTrip.destinationCountry}` : ""}
- Exakte Hoteladresse: ${primaryTrip.hotelAddress || tripWeather?.hotelAddress || "–"}
- GPS-Koordinaten des Hotels: ${tripWeather ? `${tripWeather.latitude.toFixed(4)}°N, ${tripWeather.longitude.toFixed(4)}°E (Punktwetter direkt am Hotel)` : "–"}
- Reisezeitraum: ${primaryTrip.checkin || "?"} bis ${primaryTrip.checkout || "?"} (${primaryTrip.nightsCount ?? primaryTrip.nights ?? "?"} Nächte, ${primaryTrip.adults || 2} Personen)
- ☀️ HYPERLOKALE WETTERDATEN AM HOTEL:
  * Status: ${tripWeather?.isLiveForecast ? "Live 16-Tage Punkt-Wettervorhersage am Hotel" : "10-Jahres historischer Klimaschnitt am Hotelstandort"}
  * Temperaturen: ${tripWeather?.temperatureText || "ca. 20°C bis 25°C"}
  * Niederschlag: ${tripWeather?.precipitationText || "Geringes Regenrisiko"}
  * UV-Belastung: ${tripWeather?.uvIndexText || "Normal"}
  * Wind / Böen: ${tripWeather?.windText || "Normal"}
  * Wetterlage: ${tripWeather?.conditionsText || "Angenehm"}
  ${tripWeather?.dailySummary ? `* Täglicher Reise-Wetterverlauf am Hotel:\n${tripWeather.dailySummary}` : ""}
  * Wichtige Einpack-Empfehlung für den Hotelstandort: ${tripWeather?.packingAdviceHint || "Dem Wetter entsprechende Kleidung"}`
        );
      }

      // Other upcoming trips with exact hotel location resolution
      if (upcomingList.length > 0) {
        const otherTrips = upcomingList.filter(
          (t: any) => !primaryTrip || t.bookingId !== primaryTrip.bookingId
        ).slice(0, 4);

        for (let i = 0; i < otherTrips.length; i++) {
          const ot = otherTrips[i];
          const otWeather = await resolveDestinationWeather(ot);
          weatherReportLines.push(
            `### ✈️ WEITERE KOMMENDE REISE ${i + 1}:
- Hotel & Ort: ${ot.hotelName ? `Hotel "${ot.hotelName}"` : "Hotel"} in ${ot.destinationCity || ""}${ot.destinationCountry ? `, ${ot.destinationCountry}` : ""}
- Exakte Adresse: ${ot.hotelAddress || otWeather?.hotelAddress || "–"} (GPS: ${otWeather ? `${otWeather.latitude.toFixed(4)}°N, ${otWeather.longitude.toFixed(4)}°E` : "–"})
- Zeitraum: ${ot.checkin || "?"} bis ${ot.checkout || "?"} (${ot.nightsCount ?? ot.nights ?? "?"} Nächte)
- ☀️ Wetter am Hotel: ${otWeather?.temperatureText || "Klimadaten verfügbar"} | ${otWeather?.conditionsText || "Angenehm"}`
          );
        }
      }

      // Also check if the user's latest query mentions a custom hotel or destination and resolve live weather for it
      const latestUserMessage = [...messages].reverse().find((m: any) => m.role === "user")?.content || "";
      let customDestWeatherReport = "";

      if (latestUserMessage) {
        // Extract hotel or city mentions
        const potentialPlaces = [
          "mallorca", "berlin", "wien", "rom", "rome", "paris", "london",
          "barcelona", "tokio", "tokyo", "new york", "dubai", "bangkok",
          "lissabon", "lisbon", "amsterdam", "madrid", "teneriffa", "gran canaria",
          "münchen", "hamburg", "zürich", "kapstadt", "sydney", "bali",
          "khao lak", "phuket", "antalya", "kreta", "rhodos", "split", "dubrovnik",
          "hotel"
        ];
        const lowerMsg = latestUserMessage.toLowerCase();
        const found = potentialPlaces.find((p) => lowerMsg.includes(p));
        if (found) {
          // Clean destination from user query
          let customQuery = latestUserMessage;
          const hotelMatch = latestUserMessage.match(/hotel\s+([A-Za-z0-9äöüß\s-]+)/i);
          if (hotelMatch) {
            customQuery = hotelMatch[0];
          }
          const customW = await resolveDestinationWeather(customQuery);
          if (customW) {
            customDestWeatherReport = `\n### 🌍 LIVE WETTERABFRAGE FÜR ERWÄHNTEN ORT / HOTEL (${customW.destination}):
- Exakter Standort: ${customW.locationDetails}
- Temperaturen: ${customW.temperatureText}
- Niederschlag: ${customW.precipitationText}
- UV-Index: ${customW.uvIndexText || "Normal"}
- Wetterlage: ${customW.conditionsText}
- Empfehlung: ${customW.packingAdviceHint}`;
          }
        }
      }

      const tripsAndWeatherContext = weatherReportLines.length > 0
        ? weatherReportLines.join("\n\n")
        : "Der Nutzer hat aktuell keine gebuchten Reisen in seiner Datenbank hinterlegt.";

      const lists = Array.isArray(packingLists) ? packingLists : [];
      const listsContext =
        lists.length === 0
          ? "Der Nutzer hat noch keine gespeicherten Packlisten."
          : lists
              .slice(0, 20)
              .map((l: any, i: number) => {
                const items = Array.isArray(l.items)
                  ? l.items.join(", ")
                  : "";
                return `${i + 1}. listId=${l.listId || "?"} | „${l.title || "Ohne Titel"}“
   Mitglied: ${l.memberName || "?"} | Ziel: ${l.destination || "?"} | Nächte: ${l.nights ?? "?"} | Personen: ${l.peopleCount ?? "?"} (${l.peopleDescription || "–"})
   Quelle: ${l.source || "?"} | Items: ${items || "–"}
   (In der Datenbank/Listen-Übersicht gespeichert – per Chat änderbar, ersetzbar oder löschbar.)`;
              })
              .join("\n\n");

      const systemInstruction = `Du bist der hochpräzise persönliche KI-Packlisten-Berater für Reisende mit vollautomatischer, punktgenauer Live-Wetter- und Klimaintegration direkt am exakten Hotelstandort.
Du weißt genau, in welchem Hotel der Nutzer übernachtet, die genaue Hoteladresse, die GPS-Koordinaten und das tagesaktuelle Wetter für jeden einzelnen Urlaubstag.

==================================================
GEBUCHTE REISEN & EXAKTE HOTEL-STANDORT- & WETTERDATEN:
==================================================
${tripsAndWeatherContext}
${customDestWeatherReport}

==================================================
GESPEICHERTE PACKLISTEN DES NUTZERS (Datenbank):
==================================================
${listsContext}

==================================================
STRENGE INTERAKTIONS- & STRUKTURREGELN:
==================================================
1. IMMER GENAU EINE EINZEL-PACKLISTE PRO FAMILIENMITGLIED (ALTER & GESCHLECHT ABFRAGEN):
   - Erstelle **IMMER NUR EINE Packliste für EIN einziges konkretes Familienmitglied** zur Zeit (z. B. "Packliste für Papa Markus (40 J.)", "Packliste für Tochter Mia (7 J.)", "Packliste für Baby Leo (8 Monate)").
   - Wenn der Nutzer eine allgemeine Familienpackliste oder eine Liste ohne Personenangaben anfordert:
     -> Frage freundlich und präzise nach den Familienmitgliedern: **Name / Rolle, Alter und Geschlecht** (z. B. "Für wen möchtest du starten? Nenne mir bitte Name, Alter und Geschlecht des ersten Familienmitglieds.").
     -> Erkläre, dass für jedes Familienmitglied eine eigene, perfekt berechnete Liste mit exakten Stückzahlen, Puffer und Alters-/Geschlechts-Bedarf erstellt wird.
   - Wenn Name, Alter und Geschlecht bekannt sind (oder genannt wurden): Erstelle SOFORT die maßgeschneiderte Einzel-Packliste!

2. WETTER PRO URLAUBSTAG & EXAKTE STÜCKZAHLEN INKLUSIVE PUFFER:
   - Analysiere das Wetter für die einzelnen Urlaubstage am Hotel (Temperatur tagsüber/nachts, UV-Index, Regen/Wind).
   - Berechne für **JEDEN EINZELNEN Gegenstand eine exakte Stückzahl inklusive sinnvollem Puffer**:
     * Unterwäsche: Reisetage + 2 Puffer (z. B. bei 7 Tagen -> 9x)
     * Socken: Reisetage + 1 Puffer (z. B. bei 7 Tagen -> 8x)
     * Oberteile/T-Shirts: Reisetage + 1-2 Puffer, angepasst an Hitze (atmungsaktiv) oder Kühle
     * Kurze Hosen / Kleider / Röcke vs. Lange Hosen (für kühlere Abende & Anreise)
     * Regenkleidung / Regenschirm (falls Regentage im Wetterbericht)
     * Bademode / UV-Schutz-Bekleidung (z. B. 2x Badesachen zum Wechseln, UV-Shirt bei UV-Index >= 6)
     * Sonnenschutz & Pflege (z. B. 1x Sonnencreme LSF 50+ 200ml, After-Sun, Sonnenhut mit Nackenschutz bei Kindern)
     * Spezifischer Altersbedarf:
       - Baby / Kleinkind (0-3 J.): Windeln (Tage * 5 + Puffer), Feuchttücher, Schwimmwindeln, Schnuller, UV-Mütze, Reisebett/Buggy-Moskitonetz.
       - Kinder (4-12 J.): Schwimmflügel, Sandspielzeug, Hörspiel-Kopfhörer, Caps, Pflaster.
       - Erwachsene / Teens: Pflegeartikel, Rasierzeug, Ladekabel, Powerbank, Abendgarderobe.

3. AMAZON-EMPFEHLUNGSLINKS FÜR JEDES ITEM:
   - Gib für **jeden Gegenstand** im Text und im maschinenlesbaren JSON einen direkten, passenden Amazon-Suchlink an:
     Format: \`https://www.amazon.de/s?k=\${encodeURIComponent(Suchbegriff_mit_Alter_oder_Details)}\`
     Beispiele:
     - \`https://www.amazon.de/s?k=UV+Schutz+Badeshirt+Kinder+Maedchen+7+Jahre\`
     - \`https://www.amazon.de/s?k=Sonnencreme+LSF+50+Plus+wasserfest+Kinder\`
     - \`https://www.amazon.de/s?k=Kompakter+Reiseschirm+sturmfest\`
     - \`https://www.amazon.de/s?k=Powerbank+10000mah+Flugzeug\`

4. MASCHINENLESBARER SPEICHER-BLOCK:
   - Wenn du eine Packliste für ein Familienmitglied vorschlägst, beende deine Antwort IMMER mit einem maschinenlesbaren Block genau in diesem Format:

\`\`\`packing-list
{
  "title": "Packliste für [Name] ([Alter] Jahre, [Geschlecht]) – [Ziel]",
  "destination": "Hotelname / Ort",
  "nights": 7,
  "memberName": "Name",
  "memberAge": 7,
  "memberGender": "weiblich",
  "peopleCount": 1,
  "peopleDescription": "1x Person (Tochter, 7 Jahre)",
  "detailedItems": [
    {
      "name": "Unterhosen",
      "quantity": 9,
      "unit": "Stück",
      "category": "Kleidung",
      "notes": "7 Urlaubstage + 2 Puffer",
      "amazonSearchUrl": "https://www.amazon.de/s?k=Unterwaesche+Maedchen+7+Jahre"
    },
    {
      "name": "T-Shirts & Tops",
      "quantity": 8,
      "unit": "Stück",
      "category": "Kleidung",
      "notes": "Leicht für 27°C Sonne",
      "amazonSearchUrl": "https://www.amazon.de/s?k=Sommer+T+Shirt+Maedchen+7+Jahre"
    },
    {
      "name": "UV-Schutz Badeshirt LSF 50+",
      "quantity": 2,
      "unit": "Stück",
      "category": "Strand & Bademode",
      "notes": "Hoher UV-Index am Hotelstrand",
      "amazonSearchUrl": "https://www.amazon.de/s?k=UV+Badeshirt+Maedchen+7+Jahre"
    }
  ],
  "items": [
    "9x Unterhosen (7 Tage + 2 Puffer)",
    "8x T-Shirts & Tops (Leicht für 27°C)",
    "2x UV-Schutz Badeshirt LSF 50+",
    "1x Sonnencreme LSF 50+ wasserfest"
  ],
  "notes": "Tageswetter am Hotel berücksichtigt: 25-28°C sonnig, UV 8, Tag 4 leichter Schauer."
}
\`\`\`

5. STRUKTUR & ANTWORT-LAYOUT:
   - Stelle in deiner Nachricht zunächst kurz das Familienmitglied (Name, Alter, Geschlecht), das Hotel und den täglichen Wetterverlauf vor.
   - Liste alle Kategorien mit Stichpunkt, exakter Stückzahl, Pufferbegründung und direkt klickbarem Amazon-Link auf:
     z. B. \`- **9x Unterwäsche** *(7 Tage + 2 Puffer)* – [🛒 Bei Amazon ansehen](https://www.amazon.de/s?k=...)\`
   - Frage am Ende, für welches nächste Familienmitglied du als Nächstes die Packliste erstellen sollst!

6. DATENBANK BEARBEITEN / ERSETZEN / LÖSCHEN:
   - Gespeicherte Packlisten in der Listen-Übersicht dürfen und sollen auf Nutzerwunsch direkt geändert, ersetzt oder gelöscht werden.
   - Bei Ändern/Ersetzen: vollständige aktualisierte Liste im packing-list-Block (gleiche memberName).
   - Bei Löschen: kurze Bestätigung im Text und im JSON \`{"listAction":"delete","targetMemberName":"Name","suggestedList":null}\`.
   - Nutze die listId aus dem Kontext, wenn bekannt.${profileContext}`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.3,
        },
      });

      const text = (response.text || "").trim();
      if (!text) {
        return res.status(500).json({
          error: "Die KI hat keine Antwort generiert. Bitte versuche es erneut.",
        });
      }

      const buildSuggestedListFromParsed = (rawParsed: any) => {
        if (!rawParsed || typeof rawParsed !== "object") return null;
        // AI sometimes wraps as { "suggestedList": { ... } } or returns the list object directly
        const parsed =
          rawParsed.suggestedList && typeof rawParsed.suggestedList === "object"
            ? rawParsed.suggestedList
            : rawParsed;

        const hasListShape =
          Array.isArray(parsed.items) ||
          Array.isArray(parsed.detailedItems) ||
          (typeof parsed.title === "string" &&
            (parsed.destination !== undefined || parsed.memberName !== undefined));
        if (!hasListShape) return null;

        const rawItems = Array.isArray(parsed.items) ? parsed.items : [];
        const rawDetailed = Array.isArray(parsed.detailedItems)
          ? parsed.detailedItems
          : [];

        const detailedItems = rawDetailed.map((item: any) => {
          const name = String(item.name || item.title || "").trim();
          const query = encodeURIComponent(
            `${name} ${parsed.memberName ? parsed.memberName : ""} ${parsed.memberAge ? `${parsed.memberAge} Jahre` : ""}`.trim(),
          );
          const defaultAmazonUrl = `https://www.amazon.de/s?k=${query}`;
          return {
            name: name || "Gegenstand",
            quantity: Math.max(1, Number(item.quantity) || 1),
            unit: item.unit ? String(item.unit) : "Stück",
            category: item.category ? String(item.category) : "Allgemein",
            notes: item.notes ? String(item.notes) : "",
            amazonSearchUrl:
              typeof item.amazonSearchUrl === "string" &&
              item.amazonSearchUrl.startsWith("http")
                ? item.amazonSearchUrl
                : defaultAmazonUrl,
            packed: false,
          };
        });

        const finalDetailedItems =
          detailedItems.length > 0
            ? detailedItems
            : rawItems.map((str: any) => {
                const s = String(str).trim();
                const match = s.match(/^(\d+)x?\s+(.*)/i);
                const qty = match ? parseInt(match[1], 10) : 1;
                const rest = match ? match[2] : s;
                const query = encodeURIComponent(
                  rest.replace(/\(.*?\)/g, "").trim(),
                );
                return {
                  name: rest,
                  quantity: qty,
                  unit: "Stück",
                  category: "Allgemein",
                  notes: "",
                  amazonSearchUrl: `https://www.amazon.de/s?k=${query}`,
                  packed: false,
                };
              });

        if (rawItems.length === 0 && finalDetailedItems.length === 0) {
          return null;
        }

        const finalItemsStrings =
          rawItems.length > 0
            ? rawItems
                .map((x: any) => String(x).trim())
                .filter(Boolean)
                .slice(0, 200)
            : finalDetailedItems.map(
                (d: any) =>
                  `${d.quantity}x ${d.name}${d.notes ? ` (${d.notes})` : ""}`,
              );

        return {
          title: String(parsed.title || "Packliste").slice(0, 120),
          destination: String(parsed.destination || "").slice(0, 120),
          nights: Math.max(1, Number(parsed.nights) || 1),
          memberName: parsed.memberName
            ? String(parsed.memberName).slice(0, 60)
            : "",
          memberAge:
            parsed.memberAge !== undefined ? parsed.memberAge : "",
          memberGender: parsed.memberGender
            ? String(parsed.memberGender).slice(0, 30)
            : "",
          peopleCount: Math.max(1, Number(parsed.peopleCount) || 1),
          peopleDescription: String(
            parsed.peopleDescription ||
              (parsed.memberName
                ? `1x Person (${parsed.memberName})`
                : ""),
          ).slice(0, 200),
          items: finalItemsStrings,
          detailedItems: finalDetailedItems,
          notes: parsed.notes ? String(parsed.notes).slice(0, 500) : "",
        };
      };

      let suggestedList: any = null;

      // 1) Explicit ```packing-list ... ``` block
      const packingBlockMatch = text.match(
        /```packing-list\s*([\s\S]*?)```/i,
      );
      if (packingBlockMatch) {
        try {
          suggestedList = buildSuggestedListFromParsed(
            JSON.parse(packingBlockMatch[1].trim()),
          );
        } catch {
          /* ignore */
        }
      }

      // 2) Generic markdown code fences (```json / ```)
      if (!suggestedList) {
        const codeFenceRegex = /```(?:json|javascript|js)?\s*([\s\S]*?)```/gi;
        let fenceMatch: RegExpExecArray | null;
        while ((fenceMatch = codeFenceRegex.exec(text)) !== null) {
          try {
            const candidate = buildSuggestedListFromParsed(
              JSON.parse(fenceMatch[1].trim()),
            );
            if (candidate) {
              suggestedList = candidate;
              break;
            }
          } catch {
            /* try next fence */
          }
        }
      }

      // 3) Raw JSON object anywhere in the text (suggestedList wrapper or list shape)
      if (!suggestedList) {
        const firstBrace = text.indexOf("{");
        const lastBrace = text.lastIndexOf("}");
        if (firstBrace >= 0 && lastBrace > firstBrace) {
          try {
            suggestedList = buildSuggestedListFromParsed(
              JSON.parse(text.slice(firstBrace, lastBrace + 1)),
            );
          } catch {
            /* ignore */
          }
        }
      }

      const cleanMessage = text
        .replace(/```packing-list\s*[\s\S]*?```/gi, "")
        .replace(/```(?:json|javascript|js)?\s*[\s\S]*?```/gi, "")
        .replace(/\{\s*"suggestedList"\s*:\s*\{[\s\S]*\}\s*\}/g, "")
        .replace(/\n{3,}/g, "\n\n")
        .trim();

      return res.json({
        message: cleanMessage || (suggestedList ? "Deine Packliste ist fertig." : text),
        suggestedList,
      });
    } catch (err: any) {
      console.error("Packing Advisor Chat Error:", err);
      const isQuota = isQuotaExceededError(err);
      return res.status(500).json({
        error: isQuota
          ? "Das Anfrage-Limit für die KI wurde kurzzeitig erreicht. Bitte warte einen kurzen Moment und versuche es erneut."
          : "Beim Laden der Packlisten-Beratung ist ein Fehler aufgetreten. Bitte versuche es erneut.",
      });
    }
  });



  /**
   * Browser Agent step planner for BookedAIChatView.
   * Modes: plan | next | verify
   */
  
  app.post("/api/booked-travel/agent-step", async (_req, res) => {
    return res.status(410).json({
      error: "Website-Navigation durch den Booked AI Chat ist deaktiviert.",
      done: true,
      success: false,
      message: "Navigation und UI-Steuerung sind nicht mehr verfügbar.",
    });
  });

  /** Navigations-/Ziel-Extraktion deaktiviert – Booked AI Chat steuert die Website nicht mehr. */
  function serverExtractGoalsFromText(_text) {
    return [];
  }

  function serverCollectGoals(_userText, _assistantText) {
    return [];
  }



  app.post("/api/booked-travel/chat", async (req, res) => {
    try {
      const {
        messages,
        nextTrip,
        upcomingTrips,
        pastTrips,
        allTrips,
        userProfile,
        packingLists,
        diaryEntries,
        favorites,
        excursionsEnabled,
        amazonEnabled,
      } = req.body || {};

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({
          error: "Mindestens eine Nachricht ist erforderlich.",
        });
      }

      const formattedContents = messages
        .filter((m: any) => m && typeof m.content === "string" && m.content.trim())
        .map((m: any) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content.trim() }],
        }));

      if (formattedContents.length === 0) {
        return res.status(400).json({
          error: "Keine gültigen Textnachrichten übermittelt.",
        });
      }

      if (formattedContents[0].role !== "user") {
        formattedContents.unshift({
          role: "user",
          parts: [{ text: "Ich habe eine Frage zu meiner gebuchten Reise." }],
        });
      }

      // Collect primary booked trip & resolve pinpoint hotel location + live weather / climate forecast
      const upcomingList: any[] = Array.isArray(upcomingTrips) ? upcomingTrips : [];
      const primaryTrip: any = nextTrip || (upcomingList.length > 0 ? upcomingList[0] : null);

      let primaryTripWeather: any = null;
      const weatherReportLines: string[] = [];

      if (primaryTrip) {
        primaryTripWeather = await resolveDestinationWeather(primaryTrip);

        const hotelNameStr = primaryTrip.hotelName ? `Hotel "${primaryTrip.hotelName}"` : "Gebuchtes Hotel";
        const cityStr = primaryTrip.destinationCity || primaryTripWeather?.city || "";
        const countryStr = primaryTrip.destinationCountry || primaryTripWeather?.country || "";
        const fullPlace = [cityStr, countryStr].filter(Boolean).join(", ");
        const exactAddr = primaryTrip.hotelAddress || primaryTripWeather?.hotelAddress || "Vor Ort bekannt";
        const gpsStr = primaryTripWeather
          ? `${primaryTripWeather.latitude.toFixed(4)}°N, ${primaryTripWeather.longitude.toFixed(4)}°E`
          : "Wird ermittelt";

        weatherReportLines.push(
          `### 🏨 HAUPTREISE / NÄCHSTES ZIEL (Exakter Standort & Hotel):
- Hotelname: ${hotelNameStr}
- Reiseziel: ${fullPlace || "Reiseziel"}
- Exakte Hoteladresse: ${exactAddr}
- GPS-Koordinaten des Hotels: ${gpsStr}
- Reisezeitraum: ${primaryTrip.checkin || "?"} bis ${primaryTrip.checkout || "?"} (${primaryTrip.nightsCount ?? primaryTrip.nights ?? "?"} Nächte, ${primaryTrip.daysUntilCheckin != null ? `in ${primaryTrip.daysUntilCheckin} Tagen` : "bald"})
- Gäste / Zimmer: ${primaryTrip.adults || 2} Erwachsene${primaryTrip.roomsCount ? `, ${primaryTrip.roomsCount} Zimmer` : ""}${primaryTrip.bookingId ? ` (Buchungs-Nr. ${primaryTrip.bookingId})` : ""}
- ☀️ LIVE-WETTER & KLIMADATEN AM HOTELSTANDORT:
  * Wetter-Status: ${primaryTripWeather?.isLiveForecast ? "Live 16-Tage Punkt-Vorhersage direkt am Hotel" : "10-Jahres historischer Klimaschnitt am Hotelstandort"}
  * Temperaturen: ${primaryTripWeather?.temperatureText || "Angenehme Reisetemperaturen"}
  * Niederschlag & Regenrisiko: ${primaryTripWeather?.precipitationText || "Geringes Regenrisiko"}
  * Sonneneinstrahlung & UV-Index: ${primaryTripWeather?.uvIndexText || "Normaler Sonnenschutz empfohlen"}
  * Wind / Brise: ${primaryTripWeather?.windText || "Leichte Brise"}
  * Gesamtlage: ${primaryTripWeather?.conditionsText || "Gutes Reisewetter"}
  ${primaryTripWeather?.dailySummary ? `* 📅 TÄGLICHER WETTERVERLAUF AM HOTEL:\n${primaryTripWeather.dailySummary}` : ""}
  * 🧳 Einpack- & Bekleidungsempfehlung für dieses Wetter: ${primaryTripWeather?.packingAdviceHint || "Dem Wetter entsprechende Kleidung"}`
        );
      }

      // Other upcoming trips
      if (upcomingList.length > 1) {
        const otherTrips = upcomingList.filter(
          (t: any) => !primaryTrip || t.bookingId !== primaryTrip.bookingId
        ).slice(0, 3);

        for (let i = 0; i < otherTrips.length; i++) {
          const ot = otherTrips[i];
          const otWeather = await resolveDestinationWeather(ot);
          weatherReportLines.push(
            `### ✈️ WEITERE KOMMENDE REISE (${i + 2}):
- Hotel: ${ot.hotelName ? `Hotel "${ot.hotelName}"` : "Hotel"} in ${ot.destinationCity || ""}${ot.destinationCountry ? `, ${ot.destinationCountry}` : ""} (${ot.checkin || "?"} – ${ot.checkout || "?"})
- Adresse & Koordinaten: ${ot.hotelAddress || otWeather?.hotelAddress || "–"} (${otWeather ? `${otWeather.latitude.toFixed(4)}°N, ${otWeather.longitude.toFixed(4)}°E` : "–"})
- Wetter am Hotel: ${otWeather?.temperatureText || "Klimadaten"} | ${otWeather?.conditionsText || "Angenehm"}`
          );
        }
      }

      // Check if user specifically asks about another city or place in the latest message
      const latestUserMessage = [...messages].reverse().find((m: any) => m.role === "user")?.content || "";
      let customDestWeatherReport = "";
      if (latestUserMessage) {
        const potentialPlaces = [
          "mallorca", "berlin", "wien", "rom", "rome", "paris", "london",
          "barcelona", "tokio", "tokyo", "new york", "dubai", "bangkok",
          "lissabon", "lisbon", "amsterdam", "madrid", "teneriffa", "gran canaria",
          "münchen", "hamburg", "zürich", "kapstadt", "sydney", "bali",
          "khao lak", "phuket", "antalya", "kreta", "rhodos", "split", "dubrovnik"
        ];
        const lowerMsg = latestUserMessage.toLowerCase();
        const foundPlace = potentialPlaces.find((p) => lowerMsg.includes(p));
        if (foundPlace && (!primaryTrip || !primaryTrip.destinationCity?.toLowerCase().includes(foundPlace))) {
          const customW = await resolveDestinationWeather(foundPlace);
          if (customW) {
            customDestWeatherReport = `\n### 🌍 WEITERE LIVE-WETTERABFRAGE FÜR ERWÄHNTEN ORT (${customW.destination}):
- Standort: ${customW.locationDetails}
- Temperaturen: ${customW.temperatureText}
- Niederschlag: ${customW.precipitationText}
- UV-Index: ${customW.uvIndexText || "Normal"}
- Wetterlage: ${customW.conditionsText}`;
          }
        }
      }

      const tripAndWeatherContext = weatherReportLines.length > 0
        ? weatherReportLines.join("\n\n")
        : "Derzeit ist noch keine gebuchte Reise in der Datenbank hinterlegt. Wenn der Nutzer nach einer Reise fragt, gib hilfreiche allgemeine Ratschläge oder frage nach dem Ziel.";

      const profileContext = formatUserProfileContext(userProfile);

      const isAmazon = Boolean(amazonEnabled);
      const isExcursions = Boolean(excursionsEnabled);

      const associateTag =
        process.env.AMAZON_ASSOCIATE_TAG ||
        process.env.AMAZON_TAG ||
        "";

      let systemInstruction = `Du bist der hochkompetente, persönliche Reisebegleiter und KI-Assistent für bereits gebuchte Reisen.

Du hast direkten Zugriff auf die exakten Buchungsdaten des Nutzers, das genaue Hotel, die Hoteladresse, GPS-Koordinaten sowie das tagesaktuelle Live-Wetter und die Vorhersage für jeden einzelnen Tag der Reise.

==================================================
GEBUCHTE REISE, EXAKTER HOTELSTANDORT & LIVE-WETTER:
==================================================
${tripAndWeatherContext}
${customDestWeatherReport}

==================================================
NUTZERPROFIL & PRÄFERENZEN:
==================================================
${profileContext || "Kein erweitertes Profil hinterlegt."}

==================================================
DEINE KERNKOMPETENZEN & RICHTLINIEN:
==================================================
1. PERFEKTE & PUNKTGENAUE WETTER-ANTWORTEN:
   - Wenn der Nutzer nach dem Wetter, Klima, Temperaturen, Regenrisiko, Sonnenstunden, Wassertemperatur oder Kleidungsempfehlungen fragt:
     * Beziehe dich IMMER konkret auf die tatsächliche Vorhersage am Hotelstandort für die exakten Reisedaten (${primaryTrip?.checkin || "Reisezeitraum"} bis ${primaryTrip?.checkout || ""}).
     * Nenne konkrete Tagestemperaturen (z. B. 26-28°C tagsüber, 20-22°C abends), Regenwahrscheinlichkeiten und UV-Werte.
     * Gib maßgeschneiderte Tipps: Welcher Tag eignet sich am besten für Ausflüge, Sonnenbad oder Strand? Wann sollte man eine Jacke für den Abend oder Regenschutz dabeihaben?

2. PUNKTGENAUE LAGE & UMGEBUNG DES HOTELS:
   - Du kennst das Hotel (${primaryTrip?.hotelName || "Gebuchtes Hotel"}) und die genaue Lage/Adresse (${primaryTrip?.hotelAddress || primaryTrip?.destinationCity || ""}).
   - Wenn nach Aktivitäten, Sehenswürdigkeiten, Stränden, Restaurants oder Nahverkehr gefragt wird:
     * Gib präzise Empfehlungen in Reichweite des Hotels (Gehdistanz, Taxi, Bus/Mietwagen).
     * Berücksichtige die örtliche Topografie (z. B. Strandlage, Altstadtnähe, Hanglage, Fußgängerzone).

3. BUCHUNGSDETAILS & REISEKOMFORT:
   - Beantworte Fragen zu Check-in, Check-out, Gepäckaufbewahrung, Zimmerwünschen, Buchungsnummern und Hotelkontaktaufnahme freundlich und lösungsorientiert.

4. AUSFLÜGE & AKTIVITÄTEN (${isExcursions ? "AUSFLUGSMODUS AKTIV" : "STANDARDMODUS"}):
   - Passe Ausflugsvorschläge immer direkt an das Wetter und den Hotelstandort an (z. B. Outdoor & Bootstouren an sonnigen Tagen; Museen, Altstadt, Märkte oder Wellness an bewölkten Tagen).

5. SPRACHE & TON:
   - Antworte stets auf Deutsch, freundlich, zuvorkommend, präzise und übersichtlich strukturiert (nutze Absätze, Aufzählungspunkte und Fettungen für gute Lesbarkeit).
   - Vermeide unnötige Worthülsen oder API-Jargon. Antworte wie ein erstklassiger 5-Sterne-Concierge.

6. 🗺️ AUTONOME ROUTENERSTELLUNG (PLATZHALTER 8):
   - Wenn der Nutzer nach einer Route, einem Ausflug, einer Rundreise, einer Autofahrt, Fahrradtour, Wanderung, Städtetour oder einem Transfer fragt, ODER wenn du konkrete Ausflugsziele/Stopps empfiehlst:
   - Hänge IMMER am Ende deiner Nachricht einen maschinenlesbaren Block an (wird im Hintergrund vollautomatisch in Platzhalter 8 geladen & berechnet):
\`\`\`route-plan
{
  "title": "Titel der Route",
  "description": "Kurzbeschreibung",
  "waypoints": [
    {
      "name": "Start (Hotel/Ort)",
      "lat": 48.1371,
      "lng": 11.5754,
      "kind": "hotel",
      "address": "Adresse oder Ort"
    },
    {
      "name": "Zwischenstopp / Sehenswürdigkeit",
      "lat": 47.7994,
      "lng": 13.0456,
      "kind": "place",
      "address": "Ort"
    },
    {
      "name": "Ziel",
      "lat": 47.2602,
      "lng": 11.3439,
      "kind": "place",
      "address": "Ort"
    }
  ],
  "legModes": ["driving", "driving"],
  "autoAirports": true
}
\`\`\`
   - legModes kann pro Abschnitt sein: "driving" (Auto), "walking" (zu Fuß), "cycling" (Fahrrad), "flight" (Flug).
   - Gib immer reale, präzise Koordinaten (lat/lng) an.

==================================================
7. ZIELORT- & DATUMS-ERKENNUNG (DESTINATION & DATE DETECTION):
==================================================
Analysiere JEDE Nachricht des Nutzers sorgfältig auf genannte Reiseziele, Städte, Urlaubsregionen, Inseln, Sehenswürdigkeiten, IATA-Flughafencodes, Länder und Reisezeiträume/Daten.

A. ZIELORT-ERKENNUNG:
- Falls der Nutzer ein konkretes Reiseziel oder eine Stadt nennt oder danach fragt (z.B. "Ich will nach Paris", "Hotels in Rom", "Flug nach JFK", "Urlaub auf Mallorca", "Was kann man in Tokio machen?"):
  * Extrahiere den genauen Stadtnamen (cityName, z.B. "Paris", "Rome", "Palma", "Tokyo", "Berlin", "New York")
  * Bestimme den offiziellen ISO-3166-1 alpha-2 Ländercode (countryCode, 2 Großbuchstaben, z.B. "FR", "IT", "ES", "JP", "DE", "US", "AT", "CH", "GB")
  * Setze detectedLocation = { "cityName": "...", "countryCode": "..." }
- Falls KEIN Zielort erwähnt wird:
  * Setze detectedLocation = null (oder lasse cityName und countryCode leer).

B. DATUMS- & ZEITRAUM-ERKENNUNG:
Heutiges Referenzdatum: ${new Date().toISOString().split("T")[0]} (${new Date().toLocaleDateString("de-DE", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}).
Analysiere alle Datumsangaben, Zeiträume, relativen Angaben (z.B. "nächste Woche Freitag bis Sonntag", "vom 12. bis 18. Oktober", "im August für 5 Tage", "über Silvester", "vom 15.09. bis 20.09."):
- Berechne das genaue Check-in-Datum (checkin) ausschließlich im Format YYYY-MM-DD.
- Berechne das genaue Check-out-Datum (checkout) ausschließlich im Format YYYY-MM-DD.
- Gib Daten nur zurück, wenn ein vollständiger, eindeutiger Zeitraum genannt oder durch eine ausdrücklich genannte Dauer ableitbar ist. Erfinde niemals ein fehlendes Datum.
- Bei einem einzelnen Datum, ungültigen Daten, gleicher An-/Abreise oder umgekehrter Reihenfolge setze detectedDates = null.
- Falls KEINE Reisedaten im Prompt vorkommen:
  * Setze detectedDates = null (oder lasse checkin und checkout leer).

Du führst KEINE Suchen durch und klickst keine Buttons. Die strukturierte Orts- und Datumsangabe wird serverseitig validiert und synchronisiert.
`;

      if (isAmazon) {
        systemInstruction += `
==================================================
AMAZON-EMPFEHLUNGS-MODUS (AKTIV):
==================================================
- Schlage zusätzlich 2–4 konkrete, für das Wetter und Reiseziel perfekt passende Reiseprodukte vor (z. B. passende Sonnencreme mit passendem LSF für den UV-Index, Reiseadapter, Packwürfel, wasserfeste Handytasche, leichte Strandtücher usw.).
- Gib deine Antwort AUSSCHLIESSLICH als valides JSON-Objekt zurück mit dem folgenden Schema:
{
  "message": "Vollständige, ausführliche Antwort auf Deutsch mit Wetter- und Lagebezug (Markdown erlaubt)",
  "detectedLocation": {
    "cityName": "Stadtname oder leer",
    "countryCode": "ISO-2 Ländercode oder leer"
  },
  "detectedDates": {
    "checkin": "Check-in Datum (z.B. 2026-10-12) oder leer",
    "checkout": "Check-out Datum (z.B. 2026-10-18) oder leer"
  },
  "recommendations": [
    {
      "key": "eindeutige-id",
      "name": "Produktname",
      "reason": "Warum passend für dieses Hotel & Wetter",
      "priority": "essential | recommended | optional",
      "searchQuery": "Amazon Suchbegriff auf Deutsch"
    }
  ]
}`;

        const response = await generateGeminiContentWithRetry({
          model: "gemini-3.1-flash-lite",
          contents: formattedContents,
          config: {
            systemInstruction,
            temperature: 0.35,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                message: { type: Type.STRING },
                detectedLocation: {
                  type: Type.OBJECT,
                  properties: {
                    cityName: { type: Type.STRING },
                    countryCode: { type: Type.STRING },
                  },
                },
                detectedDates: {
                  type: Type.OBJECT,
                  properties: {
                    checkin: { type: Type.STRING },
                    checkout: { type: Type.STRING },
                  },
                },
                recommendations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      key: { type: Type.STRING },
                      name: { type: Type.STRING },
                      reason: { type: Type.STRING },
                      priority: { type: Type.STRING },
                      searchQuery: { type: Type.STRING },
                    },
                    required: [
                      "key",
                      "name",
                      "reason",
                      "priority",
                      "searchQuery",
                    ],
                  },
                },
              },
              required: ["message", "recommendations"],
            },
          },
        });

        let parsed: any;
        try {
          parsed = JSON.parse((response.text || "").trim() || "{}");
        } catch {
          const correlationId = crypto.randomBytes(8).toString("hex");
          return res.status(502).json({
            error: "GEMINI_MALFORMED_OUTPUT",
            message: "Die KI hat kein gültiges strukturiertes Ergebnis geliefert.",
            correlationId,
          });
        }

        const message =
          typeof parsed.message === "string" && parsed.message.trim()
            ? parsed.message.trim()
            : "Hier sind die passenden Informationen zu deiner Reise.";

        const rawRecs = Array.isArray(parsed.recommendations) ? parsed.recommendations : [];
        const recommendations = rawRecs
          .slice(0, 8)
          .map((r: any, i: number) => {
            const searchQuery = String(r.searchQuery || r.name || "Reise Zubehör").trim();
            const params = new URLSearchParams({ k: searchQuery });
            if (associateTag) params.set("tag", associateTag);
            const affiliateUrl = `https://www.amazon.de/s?${params.toString()}`;
            const priorityRaw = String(r.priority || "recommended").toLowerCase();
            const priority =
              priorityRaw === "essential" || priorityRaw === "optional"
                ? priorityRaw
                : "recommended";
            return {
              key: String(r.key || `rec-${i}-${Date.now()}`),
              name: String(r.name || searchQuery).slice(0, 120),
              reason: String(r.reason || "").slice(0, 400),
              priority,
              affiliateUrl,
            };
          })
          .filter((r: any) => r.name && r.affiliateUrl);

        // Deterministic validation of AI detectedLocation and detectedDates
        const validatedLocation = validateAndNormalizeLocation(
          parsed?.detectedLocation?.cityName,
          parsed?.detectedLocation?.countryCode
        );
        let validatedDates = validateAndNormalizeDateRange(
          parsed?.detectedDates?.checkin,
          parsed?.detectedDates?.checkout
        );
        if (!validatedDates && latestUserMessage) {
          validatedDates = extractDatesFromPromptText(latestUserMessage, new Date());
        }

        return res.json({
          message,
          recommendations,
          detectedLocation: validatedLocation,
          detectedDates: validatedDates,
          weatherSnapshot: primaryTripWeather ? {
            temperature: primaryTripWeather.temperatureText,
            conditions: primaryTripWeather.conditionsText,
            precipitation: primaryTripWeather.precipitationText,
            uvIndex: primaryTripWeather.uvIndexText,
            isLiveForecast: primaryTripWeather.isLiveForecast,
            hotelName: primaryTrip?.hotelName,
            destination: primaryTripWeather.destination,
            periodText: primaryTripWeather.periodText,
          } : null,
        });
      }

      // Normal or Excursions chat mode (JSON schema structured for reliable text + detectedLocation + detectedDates)
      systemInstruction += `
Gib deine Antwort AUSSCHLIESSLICH als valides JSON-Objekt zurück mit dem folgenden Schema:
{
  "message": "Vollständige, ausführliche Antwort auf Deutsch mit Wetter- und Lagebezug (Markdown erlaubt)",
  "detectedLocation": {
    "cityName": "Erkannter Stadtname (z.B. Paris, Rom, Berlin) oder leer",
    "countryCode": "ISO-3166-1 alpha-2 Ländercode (z.B. FR, IT, DE) oder leer"
  },
  "detectedDates": {
    "checkin": "Erkanntes Check-in Datum (z.B. 2026-10-12) oder leer",
    "checkout": "Erkanntes Check-out Datum (z.B. 2026-10-18) oder leer"
  }
}`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.35,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              message: { type: Type.STRING },
              detectedLocation: {
                type: Type.OBJECT,
                properties: {
                  cityName: { type: Type.STRING },
                  countryCode: { type: Type.STRING },
                },
              },
              detectedDates: {
                type: Type.OBJECT,
                properties: {
                  checkin: { type: Type.STRING },
                  checkout: { type: Type.STRING },
                },
              },
            },
            required: ["message"],
          },
        },
      });

      const responseRawText = String(response.text || "").trim();
      if (!responseRawText) {
        return res.status(500).json({
          error: "Die KI hat keine Antwort generiert. Bitte versuche es erneut.",
        });
      }

      let parsedChat: any = {};
      try {
        parsedChat = JSON.parse(responseRawText);
      } catch {
        parsedChat = { message: responseRawText };
      }

      const replyMessage = typeof parsedChat.message === "string" && parsedChat.message.trim()
        ? parsedChat.message.trim()
        : responseRawText;

      // Deterministic validation of AI detectedLocation and detectedDates
      const validatedLocation = validateAndNormalizeLocation(
        parsedChat?.detectedLocation?.cityName,
        parsedChat?.detectedLocation?.countryCode
      );
      let validatedDates = validateAndNormalizeDateRange(
        parsedChat?.detectedDates?.checkin,
        parsedChat?.detectedDates?.checkout
      );
      if (!validatedDates && latestUserMessage) {
        validatedDates = extractDatesFromPromptText(latestUserMessage, new Date());
      }

      return res.json({
        message: replyMessage,
        detectedLocation: validatedLocation,
        detectedDates: validatedDates,
        weatherSnapshot: primaryTripWeather ? {
          temperature: primaryTripWeather.temperatureText,
          conditions: primaryTripWeather.conditionsText,
          precipitation: primaryTripWeather.precipitationText,
          uvIndex: primaryTripWeather.uvIndexText,
          isLiveForecast: primaryTripWeather.isLiveForecast,
          hotelName: primaryTrip?.hotelName,
          destination: primaryTripWeather.destination,
          periodText: primaryTripWeather.periodText,
        } : null,
      });
    } catch (err: any) {
      console.error("Booked Travel Chat error:", err);
      const isQuota = isQuotaExceededError(err);
      const correlationId = crypto.randomBytes(8).toString("hex");
      const retryAfterMs = getGeminiRetryDelayMs(err);
      console.error(`[BookedChat ${correlationId}] failed quota=${isQuota} status=${getGeminiErrorStatus(err) ?? "unknown"}`, err);

      return res.status(isQuota ? 429 : 502).json({
        error: isQuota
          ? "Der Gemini Anbieter hat das aktuelle Kontingent für diese Anfrage vorübergehend erreicht."
          : "Die Reiseberatung konnte nicht abgeschlossen werden.",
        code: isQuota ? "GEMINI_QUOTA_EXCEEDED" : "GEMINI_REQUEST_FAILED",
        retryAfterMs: retryAfterMs ?? undefined,
        correlationId,
      });
    }
  });

  // ─── Autonomous AI Route Planner Generator ───
  app.post("/api/route-planner/ai-generate", async (req, res) => {
    try {
      const { prompt, currentRoute, userProfile, nextTrip } = req.body || {};
      const userPrompt = typeof prompt === "string" ? prompt.trim() : "";
      if (!userPrompt) {
        return res.status(400).json({ error: "Bitte gib eine Routen-Anfrage oder ein Reiseziel ein." });
      }

      const profileContext = formatUserProfileContext(userProfile);
      let tripContext = "";
      if (nextTrip) {
        tripContext = `\nAktuelle/Gebuchte Reise des Nutzers: Hotel "${nextTrip.hotelName || ""}" in ${nextTrip.destinationCity || ""}${nextTrip.destinationCountry ? `, ${nextTrip.destinationCountry}` : ""}`;
      }

      const systemInstruction = `Du bist der hochkompetente autonome KI-Routenplaner für Reisekarten.
Deine Aufgabe ist es, für die Anfrage des Nutzers eine vollständige, reale Route mit allen Zwischenstopps, exakten Koordinaten und passenden Verkehrsmitteln (driving, cycling, walking, flight) zu erstellen.
${tripContext}
${profileContext}

Regeln:
1. Erstelle eine logische Abfolge von 2 bis 8 Wegpunkten.
2. Jeder Wegpunkt MUSS genaue GPS-Koordinaten (lat/lng) und eine aussagekräftige Bezeichnung haben.
3. Wähle für jeden Streckenabschnitt das optimale Verkehrsmittel (legModes):
   - "driving": PKW / Mietwagen / Roadtrip / Überlandfahrt
   - "walking": Kurze Stadterkundungen, Spaziergänge, Sehenswürdigkeiten in Gehdistanz (< 3 km)
   - "cycling": Fahrradtouren, Panoramarouten
   - "flight": Große Distanzen (> 450 km), Übersee oder explizite Flugverbindungen
4. Wenn Flüge genutzt werden, setze den entsprechenden Wegpunkt auf "airport" (und gib iata Code an falls bekannt).
5. Antworte AUSSCHLIESSLICH im geforderten JSON-Schema.`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: [
          {
            role: "user",
            parts: [{ text: `Erstelle eine detaillierte Reiseroute für folgende Anfrage: "${userPrompt}"` }],
          },
        ],
        config: {
          systemInstruction,
          temperature: 0.3,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              waypoints: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    lat: { type: Type.NUMBER },
                    lng: { type: Type.NUMBER },
                    kind: { type: Type.STRING },
                    address: { type: Type.STRING },
                    iata: { type: Type.STRING },
                    icao: { type: Type.STRING },
                  },
                  required: ["name", "lat", "lng"],
                },
              },
              legModes: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              autoAirports: { type: Type.BOOLEAN },
              mapStyle: { type: Type.STRING },
            },
            required: ["title", "waypoints"],
          },
        },
      });

      let parsed: any = {};
      try {
        parsed = JSON.parse((response.text || "").trim() || "{}");
      } catch {
        parsed = {};
      }

      if (!parsed || !Array.isArray(parsed.waypoints) || parsed.waypoints.length < 2) {
        return res.status(500).json({ error: "Konnte keine vollständige Route mit mindestens 2 Stopps generieren." });
      }

      const plan = {
        title: String(parsed.title || "KI-generierte Reiseroute").slice(0, 120),
        description: String(parsed.description || "").slice(0, 300),
        waypoints: parsed.waypoints.map((wp: any) => ({
          name: String(wp.name || "Stopp").slice(0, 100),
          lat: Number(wp.lat),
          lng: Number(wp.lng),
          kind: ["hotel", "airport", "place", "address"].includes(wp.kind) ? wp.kind : "place",
          address: wp.address ? String(wp.address).slice(0, 160) : undefined,
          iata: wp.iata ? String(wp.iata).slice(0, 10) : undefined,
          icao: wp.icao ? String(wp.icao).slice(0, 10) : undefined,
        })),
        legModes: Array.isArray(parsed.legModes)
          ? parsed.legModes.map((m: any) =>
              ["driving", "walking", "cycling", "flight"].includes(m) ? m : "driving"
            )
          : undefined,
        autoAirports: parsed.autoAirports !== false,
        mapStyle: parsed.mapStyle || "standard",
        autoCalculate: true,
        source: "direct-ai",
        timestamp: Date.now(),
      };

      return res.json({ plan });
    } catch (err: any) {
      console.error("AI Route Generator Error:", err);
      const isQuota = isQuotaExceededError(err);
      return res.status(500).json({
        error: isQuota
          ? "Das KI-Limit wurde kurzzeitig erreicht. Bitte kurz warten."
          : "Fehler bei der KI-Routenplanung.",
      });
    }
  });

  app.post("/api/travel-shopping/chat", async (req, res) => {
    try {
      const { destination, messages, context, userProfile, nextTrip, upcomingTrips } = req.body || {};
      const profileContext = formatUserProfileContext(userProfile);

      if (!Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({
          error: "Mindestens eine Nachricht ist erforderlich.",
        });
      }

      const formattedContents = messages
        .filter((m: any) => m && typeof m.content === "string" && m.content.trim())
        .map((m: any) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content.trim() }],
        }));

      if (formattedContents.length === 0) {
        return res.status(400).json({
          error: "Keine gültigen Textnachrichten übermittelt.",
        });
      }

      if (formattedContents[0].role !== "user") {
        formattedContents.unshift({
          role: "user",
          parts: [{ text: "Ich starte die Reisebedarf-Beratung." }],
        });
      }

      // Collect trip & weather if available
      let tripWeatherInfo = "";
      const primaryTrip = nextTrip || (Array.isArray(upcomingTrips) && upcomingTrips.length > 0 ? upcomingTrips[0] : null);
      if (primaryTrip) {
        const tw = await resolveDestinationWeather(primaryTrip);
        if (tw) {
          tripWeatherInfo = `\nGebuchte Reise: Hotel "${primaryTrip.hotelName || ""}" in ${tw.destination} (${tw.periodText})\nStandort: ${tw.locationDetails}\nWetter am Hotel: ${tw.temperatureText} | ${tw.conditionsText} | ${tw.precipitationText} | ${tw.uvIndexText}\n`;
        }
      }

      const dest =
        typeof destination === "string" && destination.trim()
          ? destination.trim()
          : (primaryTrip?.hotelName ? `${primaryTrip.hotelName}, ${primaryTrip.destinationCity || ""}` : "gebuchte Reise");
      const extraContext =
        typeof context === "string" && context.trim()
          ? context.trim()
          : "";

      const associateTag =
        process.env.AMAZON_ASSOCIATE_TAG ||
        process.env.AMAZON_TAG ||
        "";

      const systemInstruction = `Du bist der KI-Reisebedarf-Berater mit direktem Zugriff auf den exakten Hotelstandort und das Live-Wetter der gebuchten Reise.
Reiseziel-Hinweis: "${dest}"
${tripWeatherInfo}
${extraContext ? `Zusätzlicher Kontext: ${extraContext}` : ""}
${profileContext}

Deine Aufgabe:
1. Beantworte die Frage des Nutzers hilfreich auf Deutsch mit direktem Bezug zum exakten Reiseziel, Hotel und Wetter (Markdown erlaubt).
2. Empfiehl 3–6 konkrete Produkte, die für dieses Wetter und diesen Hotelstandort perfekt sinnvoll sind (z. B. Sonnenschutz mit passendem LSF, Adapter, Koffer, Reiseapotheke, UV-Shirt, Mückenschutz, Wanderausrüstung usw.).
3. Jedes Produkt braucht: kurzen Namen, Begründung, Priorität (essential | recommended | optional) und einen präzisen Suchbegriff für Amazon DE.

Antworte AUSSCHLIESSLICH als JSON-Objekt mit diesem Schema:
{
  "message": "Beratungstext auf Deutsch",
  "recommendations": [
    {
      "key": "eindeutige-id",
      "name": "Produktname",
      "reason": "Warum sinnvoll für dieses Wetter und dieses Hotel",
      "priority": "essential",
      "searchQuery": "Amazon Suchbegriff auf Deutsch"
    }
  ]
}

Regeln:
- Keine erfundenen Preise.
- searchQuery soll präzise und kauffreundlich sein.
- Wenn der Nutzer keine Produktfrage stellt, trotzdem 2–4 optionale Basics vorschlagen, falls passend – sonst leeres recommendations-Array.
- Keine Markdown-Codeblöcke um das JSON.`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.35,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              message: { type: Type.STRING },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    key: { type: Type.STRING },
                    name: { type: Type.STRING },
                    reason: { type: Type.STRING },
                    priority: { type: Type.STRING },
                    searchQuery: { type: Type.STRING },
                  },
                  required: ["key", "name", "reason", "priority", "searchQuery"],
                },
              },
            },
            required: ["message", "recommendations"],
          },
        },
      });

      let parsed: any = {};
      try {
        parsed = JSON.parse((response.text || "").trim() || "{}");
      } catch {
        parsed = { message: (response.text || "").trim(), recommendations: [] };
      }

      const message =
        typeof parsed.message === "string" && parsed.message.trim()
          ? parsed.message.trim()
          : "Hier sind passende Hinweise zu deiner Reise.";

      const rawRecs = Array.isArray(parsed.recommendations)
        ? parsed.recommendations
        : [];

      const recommendations = rawRecs
        .slice(0, 8)
        .map((r: any, i: number) => {
          const searchQuery = String(
            r.searchQuery || r.name || "Reise Zubehör"
          ).trim();
          const params = new URLSearchParams({
            k: searchQuery,
          });
          if (associateTag) params.set("tag", associateTag);
          const affiliateUrl = `https://www.amazon.de/s?${params.toString()}`;
          const priorityRaw = String(r.priority || "recommended").toLowerCase();
          const priority =
            priorityRaw === "essential" || priorityRaw === "optional"
              ? priorityRaw
              : "recommended";
          return {
            key: String(r.key || `rec-${i}-${Date.now()}`),
            name: String(r.name || searchQuery).slice(0, 120),
            reason: String(r.reason || "").slice(0, 400),
            priority,
            affiliateUrl,
          };
        })
        .filter((r: any) => r.name && r.affiliateUrl);

      return res.json({ message, recommendations });
    } catch (err: any) {
      console.error("Travel shopping chat error:", err);
      return res.status(500).json({
        error: isQuotaExceededError(err)
          ? "Das Anfrage-Limit für die KI wurde kurzzeitig erreicht. Bitte warte kurz und versuche es erneut."
          : "Beim Laden der Amazon-Empfehlungen ist ein Fehler aufgetreten.",
      });
    }
  });

  app.post("/api/diary/polish", async (req, res) => {
    try {
      const { text, field } = req.body || {};
      const source = typeof text === "string" ? text.trim() : "";
      if (!source) {
        return res.status(400).json({
          error: "Kein Text zum Strukturieren übermittelt.",
        });
      }
      if (source.length > 20000) {
        return res.status(400).json({
          error: "Text ist zu lang (max. ca. 20.000 Zeichen).",
        });
      }

      const isLearnings = field === "learnings";
      const systemInstruction = isLearnings
        ? `Du bist ein sorgfältiger Lektor für Reise-Learnings.
Deine einzige Aufgabe: Den Text des Nutzers in klarer, gut lesbarer deutscher Sprache strukturieren.

STRIKTE REGELN:
1. Inhalt NICHT verändern, erweitern, kürzen oder umdeuten – keine neuen Fakten, Tipps oder Bewertungen hinzufügen.
2. Nur Grammatik, Rechtschreibung, Zeichensetzung und Verständlichkeit verbessern.
3. Du darfst Absätze, Aufzählungen und leichte Markdown-Struktur (Überschriften, Bullet-Points) einsetzen, wenn das die Lesbarkeit erhöht – ohne den Inhalt zu ändern.
4. Ton und Perspektive des Originals beibehalten (z. B. Ich-Form).
5. Antworte NUR mit dem überarbeiteten Text, ohne Einleitung, Kommentar oder Erklärung.`
        : `Du bist ein sorgfältiger Lektor für Urlaubstagebücher.
Deine einzige Aufgabe: Den Tagebuchtext des Nutzers in klarer, gut lesbarer deutscher Sprache strukturieren.

STRIKTE REGELN:
1. Inhalt NICHT verändern, erweitern, kürzen oder umdeuten – keine neuen Ereignisse oder Bewertungen hinzufügen.
2. Nur Grammatik, Rechtschreibung, Zeichensetzung und Verständlichkeit verbessern.
3. Du darfst Absätze und leichte Markdown-Struktur einsetzen, wenn das die Lesbarkeit erhöht – ohne den Inhalt zu ändern.
4. Ton und Perspektive des Originals beibehalten (z. B. Ich-Form, emotionale Nuancen).
5. Antworte NUR mit dem überarbeiteten Text, ohne Einleitung, Kommentar oder Erklärung.`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: [
          {
            role: "user",
            parts: [
              {
                text: `Bitte strukturiere und korrigiere ausschließlich Grammatik/Verständlichkeit des folgenden Textes. Inhalt unverändert lassen.\n\n---\n${source}\n---`,
              },
            ],
          },
        ],
        config: {
          systemInstruction,
          temperature: 0.2,
        },
      });

      const out = (response.text || "").trim();
      if (!out) {
        return res.status(500).json({
          error: "Die KI hat keinen Text zurückgegeben. Bitte erneut versuchen.",
        });
      }

      return res.json({ text: out });
    } catch (err: any) {
      console.error("Diary polish error:", err);
      return res.status(500).json({
        error: isQuotaExceededError(err)
          ? "Das Anfrage-Limit für die KI wurde kurzzeitig erreicht. Bitte warte kurz und versuche es erneut."
          : "Beim Strukturieren ist ein Fehler aufgetreten. Bitte versuche es erneut.",
      });
    }
  });

  // 1-minütiges Automatisches Speichern für das Urlaubstagebuch (Backend-Protokollierung)
  app.post("/api/diary/autosave", async (req, res) => {
    try {
      const {
        entryId,
        title,
        destination,
        userId,
        textLength,
        expensesCount,
        photosCount,
        timestamp,
      } = req.body || {};

      const cleanTitle = (title && typeof title === "string") ? title.trim() : "Unbenannter Eintrag";
      const cleanDest = (destination && typeof destination === "string") ? destination.trim() : "-";
      const userStr = userId ? `User ${userId}` : "Gast/Anonym";
      const timeStr = timestamp || new Date().toISOString();

      console.log(
        `[Urlaubstagebuch Backend Autosave] (${timeStr}) Eintrag "${cleanTitle}" (ID: ${entryId || "neu"}, Ort: "${cleanDest}", ${userStr}, Textlänge: ${textLength || 0} Zeichen, Ausgaben: ${expensesCount || 0}, Fotos: ${photosCount || 0}) automatisch im Backend registriert & gesichert.`
      );

      return res.json({
        success: true,
        loggedAt: timeStr,
        entryId,
      });
    } catch (err: any) {
      console.error("[Urlaubstagebuch Backend Autosave Fehler]:", err);
      return res.status(500).json({ error: "Backend autosave logging error" });
    }
  });

  app.post("/api/trips/consensus", async (req, res) => {
    try {
      const { tripName, members = [], suggestions = [] } = req.body || {};
      if (!Array.isArray(suggestions) || suggestions.length === 0) {
        return res.status(400).json({ error: "Keine Vorschläge im Topf." });
      }

      const weightSum =
        (members as any[]).reduce(
          (a: number, m: any) => a + (Number(m.weightPercent) || 0),
          0
        ) || 1;

      const memberLines = (members as any[])
        .map((m: any) => {
          const w = Number(m.weightPercent) || 0;
          const rel = Math.round((w / weightSum) * 100);
          return `- ${m.name || m.email} (${m.email}): Gewicht ${w}% (relativ ${rel}%)`;
        })
        .join("\n");

      const sugLines = (suggestions as any[])
        .map((s: any, i: number) => {
          return `${i + 1}. Hotel: ${s.hotelName} (ID: ${s.hotelId || "?"})
   Vorgeschlagen von: ${s.proposedByName || s.proposedByEmail}
   Sterne: ${s.starRating ?? "?"} | Bewertung: ${s.rating ?? "?"}
   Notiz: ${s.note || "–"}`;
        })
        .join("\n\n");

      const prompt = `Du bist ein neutraler Reiseberater für Gruppenreisen.
Reise-Name: "${tripName || "Gruppenreise"}"

Mitreisende und Gewichtung ihrer Meinung (höheres Gewicht = stärker berücksichtigen):
${memberLines || "(keine Mitglieder angegeben)"}

Hotel-Vorschläge im gemeinsamen Topf:
${sugLines}

Aufgabe:
1. Gewichte die Vorschläge nach dem prozentualen Einfluss der vorschlagenden Person.
2. Finde den besten gemeinsamen Nenner: was ist miteinander vereinbar und macht der Gruppe insgesamt am ehesten Freude.
3. Wenn Vorschläge konkurrieren, erkläre den Kompromiss klar.
4. Nenne 1–3 bevorzugte Hotels (mit Begründung) und ggf. was man noch klären sollte (Daten, Budget, Lage).

Antworte auf Deutsch, klar strukturiert, freundlich und konkret.
Am Anfang eine kurze Zusammenfassung in 1–2 Sätzen.`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: { temperature: 0.4 },
      });

      const text = (response.text || "").trim();
      if (!text) {
        return res.status(500).json({ error: "KI hat keine Antwort geliefert." });
      }

      // Extract a short summary: first non-empty paragraph
      const summary =
        text.split(/\n\n+/).map((p: string) => p.trim()).find(Boolean)?.slice(0, 280) ||
        undefined;

      const recommendedHotelIds = (suggestions as any[])
        .filter((s: any) => s.hotelId && text.toLowerCase().includes(String(s.hotelName || "").toLowerCase()))
        .map((s: any) => String(s.hotelId));

      return res.json({ text, summary, recommendedHotelIds });
    } catch (err: any) {
      console.error("Trip consensus error:", err);
      return res.status(500).json({
        error: isQuotaExceededError(err)
          ? "KI-Limit erreicht. Bitte kurz warten."
          : "Konsens konnte nicht berechnet werden.",
      });
    }
  });

  // ─── Destination Photo API (Unsplash / Pexels / Pixabay / Wikimedia Commons - NOT LiteAPI) ───
  const destinationPhotoCache = new Map<string, { data: any; timestamp: number }>();

  app.get("/api/destination-photo", async (req, res) => {
    try {
      const q = String(req.query.q || req.query.query || "").trim();
      const city = String(req.query.city || "").trim();
      const country = String(req.query.country || "").trim();
      const hotelName = String(req.query.hotelName || "").trim();
      const address = String(req.query.address || "").trim();
      const latStr = req.query.lat ? String(req.query.lat) : undefined;
      const lngStr = req.query.lng ? String(req.query.lng) : undefined;
      const lat = latStr ? parseFloat(latStr) : undefined;
      const lng = lngStr ? parseFloat(lngStr) : undefined;

      const primaryQuery = city || q || hotelName || address;
      if (!primaryQuery) {
        return res.status(400).json({ error: "Reiseziel oder Ort erforderlich." });
      }

      const cacheKey = `${primaryQuery}|${country}|${lat ?? ""}|${lng ?? ""}`.toLowerCase();
      const cached = destinationPhotoCache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < 30 * 60 * 1000) {
        return res.json(cached.data);
      }

      const unsplashKey = process.env.UNSPLASH_ACCESS_KEY?.trim();
      const pexelsKey = process.env.PEXELS_API_KEY?.trim();
      const pixabayKey = process.env.PIXABAY_API_KEY?.trim();

      const searchTermsToTry: string[] = [];
      if (city && country) searchTermsToTry.push(`${city} ${country}`);
      if (city) searchTermsToTry.push(`${city} city`);
      if (hotelName && city) searchTermsToTry.push(`${city} ${hotelName}`);
      if (q) searchTermsToTry.push(q);
      if (city) searchTermsToTry.push(city);

      // 1) Try Unsplash API if key is provided
      if (unsplashKey) {
        for (const term of searchTermsToTry) {
          try {
            const unsplashUrl = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(
              term
            )}&orientation=landscape&per_page=6&content_filter=high`;
            const uRes = await fetch(unsplashUrl, {
              headers: {
                Authorization: `Client-ID ${unsplashKey}`,
                "Accept-Version": "v1",
              },
            });
            if (uRes.ok) {
              const uData = (await uRes.json()) as any;
              if (uData.results && uData.results.length > 0) {
                const first = uData.results[0];
                const resultData = {
                  url: first.urls?.regular || first.urls?.full,
                  thumbUrl: first.urls?.small || first.urls?.thumb,
                  title: first.description || first.alt_description || `${city || primaryQuery}`,
                  locationName: [city, country].filter(Boolean).join(", ") || primaryQuery,
                  source: "Unsplash",
                  photographer: first.user?.name || "Unsplash Creator",
                  photographerUrl: first.user?.links?.html ? `${first.user.links.html}?utm_source=NuiteeStays&utm_medium=referral` : undefined,
                  sourceUrl: first.links?.html ? `${first.links.html}?utm_source=NuiteeStays&utm_medium=referral` : "https://unsplash.com",
                  allPhotos: uData.results.slice(0, 5).map((p: any) => ({
                    url: p.urls?.regular,
                    thumbUrl: p.urls?.small,
                    title: p.description || p.alt_description || city,
                    photographer: p.user?.name,
                    photographerUrl: p.user?.links?.html,
                  })),
                };
                destinationPhotoCache.set(cacheKey, { data: resultData, timestamp: Date.now() });
                return res.json(resultData);
              }
            }
          } catch (err) {
            console.warn("[DestinationPhoto] Unsplash fetch error:", err);
          }
        }
      }

      // 2) Try Pexels API if key is provided
      if (pexelsKey) {
        for (const term of searchTermsToTry) {
          try {
            const pexelsUrl = `https://api.pexels.com/v1/search?query=${encodeURIComponent(
              term
            )}&orientation=landscape&per_page=6`;
            const pRes = await fetch(pexelsUrl, {
              headers: {
                Authorization: pexelsKey,
              },
            });
            if (pRes.ok) {
              const pData = (await pRes.json()) as any;
              if (pData.photos && pData.photos.length > 0) {
                const first = pData.photos[0];
                const resultData = {
                  url: first.src?.large2x || first.src?.large || first.src?.original,
                  thumbUrl: first.src?.medium || first.src?.small,
                  title: first.alt || `${city || primaryQuery}`,
                  locationName: [city, country].filter(Boolean).join(", ") || primaryQuery,
                  source: "Pexels",
                  photographer: first.photographer || "Pexels Creator",
                  photographerUrl: first.photographer_url || "https://www.pexels.com",
                  sourceUrl: first.url || "https://www.pexels.com",
                  allPhotos: pData.photos.slice(0, 5).map((p: any) => ({
                    url: p.src?.large2x || p.src?.large,
                    thumbUrl: p.src?.medium,
                    title: p.alt || city,
                    photographer: p.photographer,
                    photographerUrl: p.photographer_url,
                  })),
                };
                destinationPhotoCache.set(cacheKey, { data: resultData, timestamp: Date.now() });
                return res.json(resultData);
              }
            }
          } catch (err) {
            console.warn("[DestinationPhoto] Pexels fetch error:", err);
          }
        }
      }

      // 3) Try Pixabay API if key is provided
      if (pixabayKey) {
        for (const term of searchTermsToTry) {
          try {
            const pixUrl = `https://pixabay.com/api/?key=${encodeURIComponent(
              pixabayKey
            )}&q=${encodeURIComponent(term)}&image_type=photo&orientation=horizontal&safesearch=true&per_page=6`;
            const pxRes = await fetch(pixUrl);
            if (pxRes.ok) {
              const pxData = (await pxRes.json()) as any;
              if (pxData.hits && pxData.hits.length > 0) {
                const first = pxData.hits[0];
                const resultData = {
                  url: first.largeImageURL || first.webformatURL,
                  thumbUrl: first.webformatURL || first.previewURL,
                  title: first.tags || `${city || primaryQuery}`,
                  locationName: [city, country].filter(Boolean).join(", ") || primaryQuery,
                  source: "Pixabay",
                  photographer: first.user || "Pixabay Creator",
                  photographerUrl: first.pageURL || "https://pixabay.com",
                  sourceUrl: first.pageURL || "https://pixabay.com",
                  allPhotos: pxData.hits.slice(0, 5).map((p: any) => ({
                    url: p.largeImageURL || p.webformatURL,
                    thumbUrl: p.webformatURL,
                    title: p.tags,
                    photographer: p.user,
                  })),
                };
                destinationPhotoCache.set(cacheKey, { data: resultData, timestamp: Date.now() });
                return res.json(resultData);
              }
            }
          } catch (err) {
            console.warn("[DestinationPhoto] Pixabay fetch error:", err);
          }
        }
      }

      // 4) Free Wikipedia & Wikimedia Commons API (100% Free - NO API KEY required!)
      // A) Try Wikipedia city page images
      const wikiTerms = [city, primaryQuery.split(",")[0].trim()].filter(Boolean);
      for (const wTerm of wikiTerms) {
        try {
          const wikiUrl = `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(
            wTerm
          )}&prop=pageimages|extracts&piprop=original|thumbnail&pithumbsize=1600&exintro=1&explaintext=1&format=json&origin=*`;
          const wRes = await fetch(wikiUrl, {
            headers: {
              "User-Agent": "NuiteeStaysApp/1.0 (travel-city-preview; contact@nuitee.local)",
            },
          });
          if (wRes.ok) {
            const wData = (await wRes.json()) as any;
            const pages = wData.query?.pages;
            if (pages) {
              const pageId = Object.keys(pages)[0];
              const page = pages[pageId];
              const imgUrl = page?.original?.source || page?.thumbnail?.source;
              if (imgUrl && !imgUrl.endsWith(".svg") && !imgUrl.endsWith(".svg.png")) {
                const resultData = {
                  url: imgUrl,
                  thumbUrl: page.thumbnail?.source || imgUrl,
                  title: page.title || city || primaryQuery,
                  locationName: [city, country].filter(Boolean).join(", ") || page.title,
                  source: "Wikipedia",
                  photographer: "Wikimedia Commons Contributor",
                  photographerUrl: `https://en.wikipedia.org/wiki/${encodeURIComponent(page.title || wTerm)}`,
                  sourceUrl: `https://en.wikipedia.org/wiki/${encodeURIComponent(page.title || wTerm)}`,
                  description: page.extract ? page.extract.slice(0, 180) + "…" : undefined,
                };
                destinationPhotoCache.set(cacheKey, { data: resultData, timestamp: Date.now() });
                return res.json(resultData);
              }
            }
          }
        } catch (err) {
          console.warn("[DestinationPhoto] Wikipedia fetch error:", err);
        }
      }

      // B) Try Wikimedia Commons GeoSearch if lat/lng available
      if (typeof lat === "number" && typeof lng === "number" && Number.isFinite(lat) && Number.isFinite(lng)) {
        try {
          const geoWikiUrl = `https://commons.wikimedia.org/w/api.php?action=query&generator=geosearch&ggscoord=${lat}|${lng}&ggsradius=10000&ggslimit=10&prop=imageinfo&iiprop=url|size|extmetadata&format=json&origin=*`;
          const gwRes = await fetch(geoWikiUrl, {
            headers: {
              "User-Agent": "NuiteeStaysApp/1.0 (travel-geo-preview; contact@nuitee.local)",
            },
          });
          if (gwRes.ok) {
            const gwData = (await gwRes.json()) as any;
            const pages = gwData.query?.pages;
            if (pages) {
              const validImages = Object.values(pages)
                .map((p: any) => p.imageinfo?.[0])
                .filter((info: any) => info?.url && (info.url.endsWith(".jpg") || info.url.endsWith(".jpeg") || info.url.endsWith(".png")));
              if (validImages.length > 0) {
                const best = validImages[0];
                const meta = best.extmetadata;
                const author = meta?.Artist?.value?.replace(/<[^>]*>?/gm, "") || "Wikimedia Commons";
                const resultData = {
                  url: best.url,
                  thumbUrl: best.thumburl || best.url,
                  title: meta?.ObjectName?.value || `${city || primaryQuery}`,
                  locationName: [city, country].filter(Boolean).join(", ") || primaryQuery,
                  source: "Wikimedia Commons",
                  photographer: author,
                  photographerUrl: best.descriptionurl || "https://commons.wikimedia.org",
                  sourceUrl: best.descriptionurl || "https://commons.wikimedia.org",
                };
                destinationPhotoCache.set(cacheKey, { data: resultData, timestamp: Date.now() });
                return res.json(resultData);
              }
            }
          }
        } catch (err) {
          console.warn("[DestinationPhoto] Wikimedia geosearch error:", err);
        }
      }

      // 5) High-quality curated destination image fallback
      const cleanKeyword = (city || primaryQuery.split(",")[0]).trim().toLowerCase();
      const fallbackPhotoUrl = `https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1600&q=80`;
      const resultData = {
        url: fallbackPhotoUrl,
        thumbUrl: fallbackPhotoUrl,
        title: `Reiseziel ${city || primaryQuery}`,
        locationName: [city, country].filter(Boolean).join(", ") || primaryQuery,
        source: "Unsplash Collection",
        photographer: "Travel Community",
        photographerUrl: "https://unsplash.com",
        sourceUrl: "https://unsplash.com",
      };

      destinationPhotoCache.set(cacheKey, { data: resultData, timestamp: Date.now() });
      return res.json(resultData);
    } catch (err: any) {
      console.error("[DestinationPhoto] General error:", err);
      return res.status(500).json({ error: "Foto für Reiseziel konnte nicht geladen werden." });
    }
  });

  // ==========================================
  // GEMINI AI TRANSLATOR (Bidirectional + Travel Nuances)
  // ==========================================
  app.post("/api/translator/translate", async (req, res) => {
    try {
      const { text, sourceLang = "auto", targetLang = "es", tone = "standard", context = "" } = req.body || {};
      const trimmedText = String(text || "").trim();
      if (!trimmedText) {
        return res.status(400).json({ error: "Kein Text zum Übersetzen angegeben." });
      }

      const prompt = `Du bist ein hochpräziser, weltgewandter KI-Übersetzer und Sprachexperte für Reisende und den internationalen Alltag.

Übersetze den folgenden Text präzise und idiomatisch.

Ausgangssprache: ${sourceLang === "auto" ? "Automatisch erkennen" : sourceLang}
Zielsprache: ${targetLang}
Gewünschter Tonfall/Modus: ${tone} (standard, höflich/formell, locker/informell oder reisebezogen)
Zusatzkontext/Reiseziel: ${context || "Allgemein / Reisen"}

Zu übersetzender Text:
"""
${trimmedText}
"""

ANFORDERUNGEN:
1. Übersetze den Text akkurat und natürlich in die Zielsprache (${targetLang}).
2. Erfasse Idiome, Redewendungen, Umgangssprache, Höflichkeitsfloskeln oder Fachausdrücke perfekt.
3. Gib eine leicht verständliche Lautschrift / Aussprachehilfe an (phonetic), besonders bei Sprachen mit anderer Schrift (z.B. Japanisch, Thai, Griechisch, Arabisch, Russisch, Chinesisch, Koreanisch) oder schwieriger Aussprache.
4. Falls relevant, gib eine formelle ("formal") und eine informelle ("informal") Variante an.
5. Falls nützlich, gib alternative Übersetzungen oder einen kurzen Kultur-/Reisetipp zur Verwendung im Zielland an.

Antworte IMMER im folgenden JSON-Format:
{
  "translation": "Die exakte und beste Übersetzung",
  "sourceLanguageDetected": "Sprachcode der erkannten Ausgangssprache, z. B. de, en, es",
  "sourceLanguageName": "Name der Ausgangssprache auf Deutsch, z. B. Deutsch, Spanisch",
  "targetLanguageName": "Name der Zielsprache auf Deutsch, z. B. Englisch, Spanisch, Thai",
  "phonetic": "Aussprachehilfe / Lautschrift in lateinischen Buchstaben",
  "notes": "Kurze Anmerkung zu Wortwahl, Grammatik oder Nuancen (optional)",
  "formal": "Höflichere Version (optional)",
  "informal": "Lockerere Version (optional)",
  "alternatives": ["Alternative Formulierung 1", "Alternative Formulierung 2"],
  "culturalTip": "Praxistipp für Reisende zur Verwendung dieser Phrase (optional)"
}`;

      const response = await generateGeminiContentWithRetry({
        model: "gemini-3.1-flash-lite",
        contents: prompt,
        config: {
          temperature: 0.1,
          responseMimeType: "application/json",
        },
      });

      const responseText = (response.text || "").trim();
      let parsed: any = null;
      try {
        parsed = JSON.parse(responseText);
      } catch {
        const match = responseText.match(/\{[\s\S]*\}/);
        if (match) {
          parsed = JSON.parse(match[0]);
        }
      }

      if (!parsed || !parsed.translation) {
        return res.json({
          translation: responseText || trimmedText,
          sourceLanguageDetected: sourceLang === "auto" ? "auto" : sourceLang,
          sourceLanguageName: sourceLang,
          targetLanguageName: targetLang,
          phonetic: "",
          notes: "",
          alternatives: [],
        });
      }

      return res.json({
        translation: parsed.translation,
        sourceLanguageDetected: parsed.sourceLanguageDetected || sourceLang,
        sourceLanguageName: parsed.sourceLanguageName || "",
        targetLanguageName: parsed.targetLanguageName || "",
        phonetic: parsed.phonetic || "",
        notes: parsed.notes || "",
        formal: parsed.formal || "",
        informal: parsed.informal || "",
        alternatives: Array.isArray(parsed.alternatives) ? parsed.alternatives : [],
        culturalTip: parsed.culturalTip || "",
      });
    } catch (err: any) {
      console.error("[Translator API] Error:", err);
      return res.status(500).json({
        error: "Übersetzung mit KI fehlgeschlagen. Bitte versuche es erneut.",
        details: err?.message || String(err),
      });
    }
  });

if(process.env.NODE_ENV!=="production"){const vite=await createViteServer({server:{middlewareMode:true},appType:"spa"});app.use(vite.middlewares)}else{const dist=path.join(process.cwd(),"dist");app.use(express.static(dist));app.get("*",(_,res)=>res.sendFile(path.join(dist,"index.html")))}app.listen(3000,"0.0.0.0",()=>console.log("Server listening on http://0.0.0.0:3000"))}
startServer();
