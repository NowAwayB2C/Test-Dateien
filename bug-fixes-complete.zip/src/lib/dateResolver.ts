/**
 * Deterministic date normalization, parsing, and formatting utilities
 * Supports German (DD.MM.YYYY) and ISO (YYYY-MM-DD) formats.
 */

/** Check if a string is a valid ISO date YYYY-MM-DD */
export function isValidIsoDate(str: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const [y, m, d] = str.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  return (
    date.getUTCFullYear() === y &&
    date.getUTCMonth() === m - 1 &&
    date.getUTCDate() === d
  );
}

/** Check if a string is a valid German date DD.MM.YYYY */
export function isValidGermanDate(str: string): boolean {
  const clean = String(str || "").trim().replace(/\s+/g, "");
  if (!/^\d{1,2}[./-]\d{1,2}[./-]\d{2,4}$/.test(clean)) return false;
  const parts = clean.split(/[./-]/).map(Number);
  const d = parts[0];
  const m = parts[1];
  let y = parts[2];
  if (y < 100) y += 2000;
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const date = new Date(Date.UTC(y, m - 1, d));
  return (
    date.getUTCFullYear() === y &&
    date.getUTCMonth() === m - 1 &&
    date.getUTCDate() === d
  );
}

/** Convert a validated ISO/German date to German DD.MM.YYYY. Invalid input fails closed. */
export function formatToGermanDate(dateStr: string): string {
  const trimmed = String(dateStr || "").trim();
  if (isValidIsoDate(trimmed)) {
    const [year, month, day] = trimmed.split("-");
    return `${day}.${month}.${year}`;
  }
  if (!isValidGermanDate(trimmed)) return "";

  const [day, month, rawYear] = trimmed.replace(/\s+/g, "").split(/[./-]/);
  const year = Number(rawYear) < 100 ? String(2000 + Number(rawYear)) : rawYear;
  return `${day.padStart(2, "0")}.${month.padStart(2, "0")}.${year}`;
}

/** Convert a validated German/ISO date to canonical ISO YYYY-MM-DD. Invalid input fails closed. */
export function formatToIsoDate(dateStr: string): string {
  const trimmed = String(dateStr || "").trim();
  if (isValidIsoDate(trimmed)) return trimmed;
  if (!isValidGermanDate(trimmed)) return "";

  const [day, month, rawYear] = trimmed.replace(/\s+/g, "").split(/[./-]/);
  const year = Number(rawYear) < 100 ? String(2000 + Number(rawYear)) : rawYear;
  return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
}

/** German month name to 1-indexed month number */
const GERMAN_MONTHS: Record<string, number> = {
  januar: 1,
  jan: 1,
  january: 1,
  februar: 2,
  feb: 2,
  february: 2,
  märz: 3,
  maerz: 3,
  mär: 3,
  mar: 3,
  march: 3,
  april: 4,
  apr: 4,
  mai: 5,
  may: 5,
  juni: 6,
  jun: 6,
  june: 6,
  juli: 7,
  jul: 7,
  july: 7,
  august: 8,
  aug: 8,
  september: 9,
  sep: 9,
  sept: 9,
  oktober: 10,
  okt: 10,
  october: 10,
  oct: 10,
  november: 11,
  nov: 11,
  dezember: 12,
  dez: 12,
  december: 12,
  dec: 12,
};

/**
 * Deterministically extracts travel dates (Check-in & Check-out) from a natural language user prompt.
 * Supports German & English date formats, month names, relative periods, and durations.
 */
export function extractDatesFromPromptText(
  text: string,
  referenceDate?: Date
): {
  checkinIso: string;
  checkoutIso: string;
  checkinGerman: string;
  checkoutGerman: string;
} | null {
  if (!text || typeof text !== "string") return null;
  const raw = text.trim();
  const lower = raw.toLowerCase();
  const now = referenceDate ? new Date(referenceDate) : new Date();
  const currentYear = now.getFullYear();

  // Helper to construct ISO YYYY-MM-DD
  const makeIso = (d: number, m: number, y: number): string => {
    let finalYear = y;
    if (!finalYear) {
      finalYear = currentYear;
      // If date is in the past this year, roll over to next year
      const candidate = new Date(Date.UTC(finalYear, m - 1, d));
      if (candidate.getTime() < now.getTime() - 86400000) {
        finalYear += 1;
      }
    }
    return `${finalYear}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  };

  // 1. Two German dates with delimiters (. or / or -): "15.10.2026 bis 20.10.2026" or "15.10.2026 - 20.10.2026" or "15/10/2026 bis 20/10/2026"
  const twoFullGermanMatch = raw.match(
    /\b(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})\b.*?(?:bis|to|-|–|—|und|bis zum|bis zum:?|bis:|bis am|\/)\s*.*?\b(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})\b/i
  );
  if (twoFullGermanMatch) {
    const [, d1, m1, y1, d2, m2, y2] = twoFullGermanMatch;
    let yr1 = Number(y1);
    let yr2 = Number(y2);
    if (yr1 < 100) yr1 += 2000;
    if (yr2 < 100) yr2 += 2000;
    const cin = makeIso(Number(d1), Number(m1), yr1);
    const cout = makeIso(Number(d2), Number(m2), yr2);
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  // 1b. Labeled Anreise / Abreise or Check-in / Check-out: "Check-in: 15.10.2026, Check-out: 22.10.2026" or "Anreise 15.10. Abreise 22.10."
  const labeledDatesMatch = raw.match(
    /(?:check-?in|anreise|anreisedatum|von|start|ab)\s*:?\s*(\d{1,2})[./-](\d{1,2})(?:[./-](\d{2,4}))?.*?(?:check-?out|abreise|abreisedatum|bis|ende|rückreise)\s*:?\s*(\d{1,2})[./-](\d{1,2})(?:[./-](\d{2,4}))?/i
  );
  if (labeledDatesMatch) {
    const [, d1, m1, y1, d2, m2, y2] = labeledDatesMatch;
    let yr1 = y1 ? Number(y1) : y2 ? Number(y2) : 0;
    let yr2 = y2 ? Number(y2) : yr1;
    if (yr1 > 0 && yr1 < 100) yr1 += 2000;
    if (yr2 > 0 && yr2 < 100) yr2 += 2000;
    const cin = makeIso(Number(d1), Number(m1), yr1);
    const cinYear = Number(cin.split("-")[0]);
    const cout = makeIso(Number(d2), Number(m2), yr2 || cinYear);
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  // 2. German date with shared year: "15.10. bis 20.10.2026" or "15.10. - 20.10.2026"
  const sharedYearGermanMatch = raw.match(
    /\b(\d{1,2})[./-](\d{1,2})\.?\s*(?:bis|to|-|–|—|und|bis zum)\s*.*?\b(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})\b/i
  );
  if (sharedYearGermanMatch) {
    const [, d1, m1, d2, m2, y2] = sharedYearGermanMatch;
    let yr2 = Number(y2);
    if (yr2 < 100) yr2 += 2000;
    const cin = makeIso(Number(d1), Number(m1), yr2);
    const cout = makeIso(Number(d2), Number(m2), yr2);
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  // 3. Two German dates without year: "vom 15.10. bis 20.10." or "15.10. - 20.10."
  const noYearTwoGermanMatch = raw.match(
    /\b(\d{1,2})[./-](\d{1,2})\.?\s*(?:bis|to|-|–|—|und)\s*.*?\b(\d{1,2})[./-](\d{1,2})\.?\b/i
  );
  if (noYearTwoGermanMatch) {
    const [, d1, m1, d2, m2] = noYearTwoGermanMatch;
    const cin = makeIso(Number(d1), Number(m1), 0);
    const cinYear = Number(cin.split("-")[0]);
    const cout = makeIso(Number(d2), Number(m2), cinYear);
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  // 4. Two ISO dates: "2026-10-15 bis 2026-10-20" or "2026-10-15 - 2026-10-20"
  const twoIsoMatch = raw.match(
    /\b(\d{4}-\d{2}-\d{2})\b.*?(?:bis|to|-|–|—)\s*.*?\b(\d{4}-\d{2}-\d{2})\b/i
  );
  if (twoIsoMatch) {
    return validateAndNormalizeDateRange(twoIsoMatch[1], twoIsoMatch[2], now.toISOString());
  }

  // 5. Month name span: "vom 12. bis 18. Oktober 2026" or "12. bis 18. Oktober" or "12. - 18. Okt"
  const monthNameSpanMatch = raw.match(
    /\b(\d{1,2})\.?\s*(?:bis|to|-|–|—)\s*(\d{1,2})\.?\s+(januar|jan|februar|feb|märz|maerz|mär|mar|april|apr|mai|may|juni|jun|juli|jul|august|aug|september|sep|sept|oktober|okt|october|oct|november|nov|dezember|dez|december|dec)(?:\s+(\d{4}))?\b/i
  );
  if (monthNameSpanMatch) {
    const [, d1, d2, monthName, y] = monthNameSpanMatch;
    const monthNum = GERMAN_MONTHS[monthName.toLowerCase()];
    if (monthNum) {
      const yearNum = y ? Number(y) : 0;
      const cin = makeIso(Number(d1), monthNum, yearNum);
      const cinYear = Number(cin.split("-")[0]);
      const cout = makeIso(Number(d2), monthNum, cinYear);
      return validateAndNormalizeDateRange(cin, cout, now.toISOString());
    }
  }

  // 6. Two different month names: "vom 28. Oktober bis 4. November 2026"
  const twoMonthSpanMatch = raw.match(
    /\b(\d{1,2})\.?\s+(januar|jan|februar|feb|märz|maerz|mär|mar|april|apr|mai|may|juni|jun|juli|jul|august|aug|september|sep|sept|oktober|okt|october|oct|november|nov|dezember|dez|december|dec)(?:\s+(\d{4}))?\s*(?:bis|to|-|–|—)\s*(\d{1,2})\.?\s+(januar|jan|februar|feb|märz|maerz|mär|mar|april|apr|mai|may|juni|jun|juli|jul|august|aug|september|sep|sept|oktober|okt|october|oct|november|nov|dezember|dez|december|dec)(?:\s+(\d{4}))?\b/i
  );
  if (twoMonthSpanMatch) {
    const [, d1, mName1, y1, d2, mName2, y2] = twoMonthSpanMatch;
    const m1 = GERMAN_MONTHS[mName1.toLowerCase()];
    const m2 = GERMAN_MONTHS[mName2.toLowerCase()];
    if (m1 && m2) {
      const yr1 = y1 ? Number(y1) : y2 ? Number(y2) : 0;
      const yr2 = y2 ? Number(y2) : yr1;
      const cin = makeIso(Number(d1), m1, yr1);
      const cout = makeIso(Number(d2), m2, yr2);
      return validateAndNormalizeDateRange(cin, cout, now.toISOString());
    }
  }

  // 7. Single German date with duration: "ab 15.10.2026 für 5 Nächte/Tage" or "am 15.10. für 1 Woche"
  const singleDateWithDurationMatch = raw.match(
    /\b(?:am|ab|vom)?\s*(\d{1,2})\.(\d{1,2})\.(?:(\d{4})\b)?.*?(?:für|for)\s+(\d+)\s*(tage|tag|nächte|naechte|nacht|wochen|woche|days|day|nights|night|weeks|week)/i
  );
  if (singleDateWithDurationMatch) {
    const [, d, m, y, countStr, unit] = singleDateWithDurationMatch;
    let days = Number(countStr) || 3;
    if (/woche|week/.test(unit.toLowerCase())) {
      days *= 7;
    }
    const cin = makeIso(Number(d), Number(m), y ? Number(y) : 0);
    const cinDate = new Date(cin);
    cinDate.setDate(cinDate.getDate() + days);
    const cout = cinDate.toISOString().split("T")[0];
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  // 8. Single German date: "15.10.2026" or "am 15. Oktober 2026"
  const singleFullGermanMatch = raw.match(/\b(\d{1,2})\.(\d{1,2})\.(\d{4})\b/);
  if (singleFullGermanMatch) {
    const [, d, m, y] = singleFullGermanMatch;
    const cin = makeIso(Number(d), Number(m), Number(y));
    return validateAndNormalizeDateRange(cin, undefined, now.toISOString());
  }

  const singleMonthNameMatch = raw.match(
    /\b(\d{1,2})\.?\s+(januar|jan|februar|feb|märz|maerz|mär|mar|april|apr|mai|may|juni|jun|juli|jul|august|aug|september|sep|sept|oktober|okt|october|oct|november|nov|dezember|dez|december|dec)(?:\s+(\d{4}))?\b/i
  );
  if (singleMonthNameMatch) {
    const [, d, mName, y] = singleMonthNameMatch;
    const m = GERMAN_MONTHS[mName.toLowerCase()];
    if (m) {
      const cin = makeIso(Number(d), m, y ? Number(y) : 0);
      return validateAndNormalizeDateRange(cin, undefined, now.toISOString());
    }
  }

  // 9. Single ISO date: "2026-10-15"
  const singleIsoMatch = raw.match(/\b(\d{4}-\d{2}-\d{2})\b/);
  if (singleIsoMatch) {
    return validateAndNormalizeDateRange(singleIsoMatch[1], undefined, now.toISOString());
  }

  // 10. Special seasonal & relative terms in German
  if (lower.includes("silvester") || lower.includes("neujahr")) {
    const yr = now.getMonth() >= 10 ? currentYear : currentYear;
    const cin = `${yr}-12-30`;
    const cout = `${yr + 1}-01-02`;
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  if (lower.includes("weihnachten")) {
    const yr = currentYear;
    const cin = `${yr}-12-24`;
    const cout = `${yr}-12-27`;
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  if (lower.includes("nächstes wochenende") || lower.includes("naechstes wochenende") || lower.includes("kommendes wochenende")) {
    const dayOfWeek = now.getDay(); // 0 = Sun, 5 = Fri
    const daysUntilFriday = (5 - dayOfWeek + 7) % 7 || 7;
    const fri = new Date(now);
    fri.setDate(fri.getDate() + daysUntilFriday);
    const sun = new Date(fri);
    sun.setDate(sun.getDate() + 2);
    const cin = fri.toISOString().split("T")[0];
    const cout = sun.toISOString().split("T")[0];
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  if (lower.includes("dieses wochenende")) {
    const dayOfWeek = now.getDay();
    let daysUntilFriday = 5 - dayOfWeek;
    if (daysUntilFriday < 0) daysUntilFriday = 0;
    const fri = new Date(now);
    fri.setDate(fri.getDate() + daysUntilFriday);
    const sun = new Date(fri);
    sun.setDate(sun.getDate() + 2);
    const cin = fri.toISOString().split("T")[0];
    const cout = sun.toISOString().split("T")[0];
    return validateAndNormalizeDateRange(cin, cout, now.toISOString());
  }

  return null;
}

export function validateAndNormalizeDateRange(
  rawCheckin?: string,
  rawCheckout?: string,
  referenceDateIso?: string
): {
  checkinIso: string;
  checkoutIso: string;
  checkinGerman: string;
  checkoutGerman: string;
} | null {
  const checkin = formatToIsoDate(String(rawCheckin || ""));
  const checkout = formatToIsoDate(String(rawCheckout || ""));

  // A date proposal is atomic: never invent or partially apply an endpoint.
  if (!isValidIsoDate(checkin) || !isValidIsoDate(checkout)) return null;

  const checkinTime = Date.parse(`${checkin}T00:00:00.000Z`);
  const checkoutTime = Date.parse(`${checkout}T00:00:00.000Z`);
  const reference = referenceDateIso ? new Date(referenceDateIso) : new Date();
  const todayTime = Date.UTC(
    reference.getUTCFullYear(),
    reference.getUTCMonth(),
    reference.getUTCDate(),
  );
  if (checkinTime < todayTime || checkoutTime <= checkinTime) return null;

  return {
    checkinIso: checkin,
    checkoutIso: checkout,
    checkinGerman: formatToGermanDate(checkin),
    checkoutGerman: formatToGermanDate(checkout),
  };
}
