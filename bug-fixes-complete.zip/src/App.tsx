import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { Header } from "./components/Header";
import { HotelCard } from "./components/HotelCard";
import { HotelDetailView } from "./components/HotelDetailView";
import { HotelMapView } from "./components/HotelMapView";
import { BookedAIChatView } from "./components/BookedAIChatView";
import { PersonalProfileView } from "./components/PersonalProfileView";
import PreBookingWeatherView from "./components/PreBookingWeatherView";
import { DestinationPhotoBanner } from "./components/DestinationPhotoBanner";
import {
  Placeholder2,
  Placeholder8,
  shouldHidePlaceholder8,
} from "./components/placeholders";
import { getUserSourceCurrency } from "./lib/countryLocale";
import { validateAndNormalizeDateRange } from "./lib/dateResolver";
import {
  testFirestoreConnection,
  saveUserBooking,
  auth,
  useBookedTravelContext,
} from "./firebase";
import {
  AIHotel,
  HotelDetails,
  Rate,
  RateHotelData,
  SearchParams,
} from "./types";
import type { SaveTripPayload } from "./components/HotelDetailView";
import { searchRates, getHotelFacilities, getHotelTypes, getHotelChains, getCurrencies } from "./api/nuitee";
import {
  Hotel,
  SlidersHorizontal,
  AlertCircle,
  X,
  ShieldCheck,
  Sparkles,
  Map as MapIcon,
  List as ListIcon,
  Eye,
  EyeOff,
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  DollarSign,
  Star,
  Award,
  MessageSquare,
  Type,
  Layers,
  Search,
  PanelLeftClose,
  PanelLeftOpen,
  Menu,
  ArrowLeft,
  Check,
} from "lucide-react";

export type SortCriterion =
  | "price"
  | "rating"
  | "stars"
  | "reviews"
  | "name"
  | "facilities"
  | "relevance";

export type SortDirection = "asc" | "desc";

export const SORT_OPTIONS: Array<{
  id: SortCriterion;
  label: string;
  shortLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  ascSubtitle: string;
  descSubtitle: string;
}> = [
  {
    id: "price",
    label: "Preis",
    shortLabel: "Preis",
    icon: DollarSign,
    ascSubtitle: "Günstigste Angebote zuerst",
    descSubtitle: "Höchste Preise zuerst",
  },
  {
    id: "rating",
    label: "Gästebewertung",
    shortLabel: "Bewertung",
    icon: Award,
    ascSubtitle: "Niedrigste Bewertung zuerst",
    descSubtitle: "Beste Bewertung zuerst",
  },
  {
    id: "stars",
    label: "Hotelsterne",
    shortLabel: "Sterne",
    icon: Star,
    ascSubtitle: "1 Stern → 5 Sterne",
    descSubtitle: "5 Sterne → 1 Stern",
  },
  {
    id: "reviews",
    label: "Bewertungsanzahl",
    shortLabel: "Erfahrungen",
    icon: MessageSquare,
    ascSubtitle: "Wenigste Bewertungen",
    descSubtitle: "Meiste Bewertungen zuerst",
  },
  {
    id: "facilities",
    label: "Ausstattung",
    shortLabel: "Ausstattung",
    icon: Layers,
    ascSubtitle: "Wenigste Ausstattung",
    descSubtitle: "Umfangreichste Ausstattung",
  },
  {
    id: "relevance",
    label: "Empfehlung & Relevanz",
    shortLabel: "Relevanz",
    icon: Sparkles,
    ascSubtitle: "Standard-Reihenfolge",
    descSubtitle: "Umgekehrte Relevanz",
  },
];

export default function App() {
  const [view, setView] = useState<"search" | "hotel_details">("search");

  const [searchParams, setSearchParams] = useState<SearchParams>(() => {
    try {
      const saved = sessionStorage.getItem("booked_search_params");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === "object" && parsed.mode) return parsed as SearchParams;
      }
    } catch {
      // Corrupted session state is ignored; a clean search state is safer.
    }
    return {
      mode: "destination",
      placeName: "",
      checkin: "",
      checkout: "",
      adults: 2,
      currency: "EUR",
    };
  });

  useEffect(() => {
    try {
      sessionStorage.setItem("booked_search_params", JSON.stringify(searchParams));
    } catch (error) {
      console.warn("[SearchState] Session-Persistenz fehlgeschlagen:", error);
    }
  }, [searchParams]);

  const [rateHotels, setRateHotels] = useState<RateHotelData[]>([]);
  const [aiHotels, setAiHotels] = useState<AIHotel[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [sortCriterion, setSortCriterion] = useState<SortCriterion>("price");
  const [sortDirection, setSortDirection] = useState<SortDirection>("asc");
  const [bookedSortCriterion, setBookedSortCriterion] = useState<SortCriterion>("price");
  const [bookedSortDirection, setBookedSortDirection] = useState<SortDirection>("asc");
  const [currentPage, setCurrentPage] = useState(1);
  /** Server page size – matches UI requirement of 50 per page. */
  const ITEMS_PER_PAGE = 50;
  const [hasMoreResults, setHasMoreResults] = useState(false);
  const [searchOffset, setSearchOffset] = useState(0);
  const [lastRequestId, setLastRequestId] = useState<string | null>(null);

  const [hoveredHotelId, setHoveredHotelId] = useState<string | null>(null);
  const [isMapExpanded, setIsMapExpanded] = useState(false);
  const [isMapMinimized, setIsMapMinimized] = useState(false);
  const [mobilePane, setMobilePane] = useState<"search_advisor" | "hotels">("hotels");
  const [isDesktopSidebarCollapsed, setIsDesktopSidebarCollapsed] = useState(false);

  // Hamburger Menu & Platzhalter state
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedPlaceholder, setSelectedPlaceholder] = useState<number | null>(null);
  /** When true: left = Gemini booked chat, right = placeholder app grid */
  const [isBookedMode, setIsBookedMode] = useState(true);

  // User travel context, trips, profile and next trip available for all placeholders and modules
  const {
    profile: userProfile,
    nextTrip,
    upcomingTrips,
    pastTrips,
    allTrips,
    packingLists,
    diaryEntries,
    favorites,
    formattedContextForAI,
  } = useBookedTravelContext();

  /** Anzeigenamen der aktiven Platzhalter-Apps */
  const PLACEHOLDER_NAMES: Record<number, string> = {
    2: "Inspiration & Hotels",
    8: "Routenplaner & Navigation",
  };

  /** Automatische Ausgangswährung aus dem Nutzerprofil */
  const userSourceCurrency = useMemo(
    () => getUserSourceCurrency(userProfile),
    [userProfile],
  );

  useEffect(() => {
    if (userSourceCurrency) {
      setSearchParams((prev) => {
        if (prev.currency !== userSourceCurrency) {
          return { ...prev, currency: userSourceCurrency };
        }
        return prev;
      });
    }
  }, [userSourceCurrency]);

  useEffect(() => {
    if (!searchParams.placeName && !searchParams.cityName && nextTrip?.destinationCity) {
      setSearchParams((prev) => ({
        ...prev,
        placeName: prev.placeName || nextTrip.destinationCity || "",
      }));
    }
  }, [nextTrip, searchParams.placeName, searchParams.cityName]);

  /** Automatische Übernahme des im KI-Chat erkannten Reiseziels in die Such- und Filtermaske */
  const handleLocationDetected = React.useCallback(
    (loc: { cityName: string; countryCode: string }) => {
      if (!loc?.cityName || !loc?.countryCode) return;
      setSearchParams((prev) => {
        if (
          prev.cityName === loc.cityName &&
          prev.countryCode === loc.countryCode &&
          prev.placeName === `${loc.cityName}, ${loc.countryCode}`
        ) {
          return prev;
        }
        return {
          ...prev,
          cityName: loc.cityName,
          countryCode: loc.countryCode,
          placeName: `${loc.cityName}, ${loc.countryCode}`,
        };
      });
    },
    [],
  );

  /** Automatische Übernahme der im KI-Chat erkannten Reisedaten (Check-in / Check-out) in die Such- und Filtermaske */
  const handleDatesDetected = React.useCallback(
    (dates: {
      checkinIso: string;
      checkoutIso: string;
      checkinGerman: string;
      checkoutGerman: string;
    }) => {
      const validatedDates = validateAndNormalizeDateRange(
        dates?.checkinIso,
        dates?.checkoutIso,
      );
      if (!validatedDates) return;
      setSearchParams((prev) => {
        if (
          prev.checkin === validatedDates.checkinIso &&
          prev.checkout === validatedDates.checkoutIso
        ) {
          return prev;
        }
        return {
          ...prev,
          checkin: validatedDates.checkinIso,
          checkout: validatedDates.checkoutIso,
        };
      });
    },
    [],
  );

  /** Platzhalter 8 wird komplett ausgeblendet, wenn Ausgangsland == Reiseland */
  const isNavigationHidden = useMemo(() => {
    return shouldHidePlaceholder8(nextTrip, userProfile, searchParams.placeName);
  }, [nextTrip, userProfile, searchParams.placeName]);

  useEffect(() => {
    if (isNavigationHidden && selectedPlaceholder === 8) {
      setSelectedPlaceholder(null);
    }
  }, [isNavigationHidden, selectedPlaceholder]);

  const activePlaceholderList = useMemo(() => {
    const all = [2, 8];
    return all.filter((num) => {
      if (num === 8 && isNavigationHidden) return false;
      return true;
    });
  }, [isNavigationHidden]);

  const [selectedHotelId, setSelectedHotelId] = useState<string | null>(null);
  const [selectedHotelName, setSelectedHotelName] = useState<string | undefined>();
  const [selectedHotelPhoto, setSelectedHotelPhoto] = useState<string | undefined>();

  const [openedHotelDetails, setOpenedHotelDetails] = useState<HotelDetails | null>(null);
  const [hotelReturnView, setHotelReturnView] = useState<"search" | "ai_chat">("search");

  const [profileRefreshKey, setProfileRefreshKey] = useState(0);
  /** Persönliches Reiseprofil (rechts) – KI-Chat links bleibt sichtbar */
  const [showPersonalProfile, setShowPersonalProfile] = useState(false);
  /** Wetter statt Hotels (nur vor Buchung / Neue Suche) */
  const [showWeather, setShowWeather] = useState(false);

  const searchRequestIdRef = useRef<number>(0);

  const handlePerformSearch = async (
    params: SearchParams,
    options?: { append?: boolean; offset?: number }
  ) => {
    const append = Boolean(options?.append);
    const offset = options?.offset ?? 0;
    const validDates = validateAndNormalizeDateRange(params.checkin, params.checkout);

    if (!validDates) {
      setIsSearching(false);
      setIsLoadingMore(false);
      setSearchError("Bitte gültige zukünftige Reisedaten eingeben; der Check-out muss nach dem Check-in liegen.");
      return;
    }

    params = {
      ...params,
      checkin: validDates.checkinIso,
      checkout: validDates.checkoutIso,
    };
    setSearchParams(params);
    if (!append) {
      setCurrentPage(1);
      setSearchOffset(0);
    }

    const hasLoc = Boolean(
      params.placeId ||
        params.placeName?.trim() ||
        params.cityName?.trim() ||
        (params.hotelIds && params.hotelIds.length > 0) ||
        (params.latitude != null && params.longitude != null) ||
        params.iataCode?.trim() ||
        params.aiSearch?.trim() ||
        params.semanticQuery?.trim() ||
        params.visualQuery?.trim()
    );

    if (!hasLoc) {
      setIsSearching(false);
      setIsLoadingMore(false);
      setSearchError(null);
      setRateHotels([]);
      setAiHotels([]);
      setHasMoreResults(false);
      return;
    }

    const currentRequestId = ++searchRequestIdRef.current;
    if (append) {
      setIsLoadingMore(true);
    } else {
      setIsSearching(true);
    }
    setSearchError(null);
    setView("search");

    try {
      const response = await searchRates({
        ...params,
        limit: params.limit ?? ITEMS_PER_PAGE,
        offset,
      });

      // Ignore stale responses if a newer search was launched
      if (currentRequestId !== searchRequestIdRef.current) {
        return;
      }

      if (response.error) {
        throw new Error(
          response.error.message ||
            response.error.description ||
            "Suche fehlgeschlagen"
        );
      }

      const newRates = response.data || [];
      const newHotels = response.hotels || [];

      if (append) {
        setRateHotels((prev) => {
          const seen = new Set(prev.map((r) => r.hotelId));
          const merged = [...prev];
          for (const r of newRates) {
            if (!seen.has(r.hotelId)) {
              seen.add(r.hotelId);
              merged.push(r);
            }
          }
          return merged;
        });
        setAiHotels((prev) => {
          const seen = new Set(prev.map((h) => h.id));
          const merged = [...prev];
          for (const h of newHotels) {
            if (!seen.has(h.id)) {
              seen.add(h.id);
              merged.push(h);
            }
          }
          return merged;
        });
      } else {
        setRateHotels(newRates);
        setAiHotels(newHotels);
      }

      setHasMoreResults(Boolean(response.hasMore));
      setSearchOffset(offset + (response.limit || ITEMS_PER_PAGE));
      if (response.requestId) setLastRequestId(response.requestId);
    } catch (err: any) {
      if (currentRequestId !== searchRequestIdRef.current) return;
      console.error("Search error:", err);
      const raw = String(err?.message || err || "");
      const lower = raw.toLowerCase();
      let userMsg: string;
      if (
        lower.includes("location required") ||
        lower.includes("location erforderlich")
      ) {
        userMsg =
          "Bitte ein gültiges Ziel angeben (Stadt+Land, IATA, Koordinaten oder Hotel-IDs).";
      } else if (
        lower.includes("429") ||
        lower.includes("rate limit") ||
        lower.includes("too many")
      ) {
        userMsg =
          "API-Limit erreicht. Bitte kurz warten und erneut suchen.";
      } else if (
        lower.includes("timeout") ||
        lower.includes("timed out") ||
        lower.includes("network")
      ) {
        userMsg =
          "Zeitüberschreitung oder Netzwerkproblem. Bitte erneut versuchen.";
      } else if (
        lower.includes("401") ||
        lower.includes("403") ||
        lower.includes("unauthorized") ||
        lower.includes("api key")
      ) {
        userMsg =
          "API-Berechtigung fehlt oder ist ungültig. Bitte API-Key prüfen.";
      } else if (raw.trim()) {
        userMsg = raw;
      } else {
        userMsg =
          "Hotels konnten nicht gesucht werden. Bitte anderes Ziel oder Filter versuchen.";
      }
      setSearchError(userMsg);
      if (!append) {
        setRateHotels([]);
        setAiHotels([]);
        setHasMoreResults(false);
      }
    } finally {
      if (currentRequestId === searchRequestIdRef.current) {
        setIsSearching(false);
        setIsLoadingMore(false);
      }
    }
  };

  const handleLoadMore = () => {
    if (!hasMoreResults || isLoadingMore || isSearching) return;
    handlePerformSearch(searchParams, { append: true, offset: searchOffset });
  };

  useEffect(() => {
    testFirestoreConnection();
    const hasLoc = Boolean(
      searchParams.placeId ||
        searchParams.placeName?.trim() ||
        searchParams.cityName?.trim() ||
        (searchParams.hotelIds && searchParams.hotelIds.length > 0) ||
        (searchParams.latitude != null && searchParams.longitude != null) ||
        searchParams.iataCode?.trim() ||
        searchParams.aiSearch?.trim()
    );
    if (hasLoc) {
      handlePerformSearch(searchParams);
    }
  }, []);

  const handleSelectHotel = (hotelId: string, name?: string, photo?: string) => {
    setShowWeather(false);
    setHotelReturnView("search");
    setSelectedHotelId(hotelId);
    setSelectedHotelName(name);
    setSelectedHotelPhoto(photo);
    setView("hotel_details");
    setTimeout(() => {
      document.getElementById("hotel-content-area")?.scrollIntoView({ behavior: "smooth" });
    }, 50);
  };

  const handleSaveTrip = async (payload: SaveTripPayload) => {
    const bookingId = `trip-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    await saveUserBooking({
      userId: auth.currentUser?.uid || "",
      bookingId,
      hotelId: payload.hotelId,
      hotelName: payload.hotelName,
      hotelAddress: payload.hotelAddress,
      hotelPhoto: payload.hotelPhoto,
      roomName: payload.roomName,
      checkin: payload.checkin,
      checkout: payload.checkout,
      adults: payload.adults,
      totalAmount: payload.totalAmount,
      currency: payload.currency,
      status: "planned",
      webUrl: payload.webUrl,
      starRating: payload.starRating,
      createdAt: new Date().toISOString(),
      destinationCity: payload.destinationCity,
      destinationCountry: payload.destinationCountry,
      destinationCountryCode: payload.destinationCountryCode,
      destinationLat: payload.destinationLat,
      destinationLng: payload.destinationLng,
    });
    setProfileRefreshKey((k) => k + 1);
  };

  const hotelResults = useMemo(() => {
    const list: Array<{
      hotelId: string;
      aiInfo?: AIHotel;
      firstRate?: Rate;
    }> = [];

    if (aiHotels && aiHotels.length > 0) {
      aiHotels.forEach((aiHotel) => {
        const rateEntry = rateHotels.find((r) => r.hotelId === aiHotel.id);
        const firstRate = rateEntry?.roomTypes?.[0]?.rates?.[0];
        list.push({
          hotelId: aiHotel.id,
          aiInfo: aiHotel,
          firstRate,
        });
      });
    } else {
      rateHotels.forEach((rh) => {
        const firstRate = rh.roomTypes?.[0]?.rates?.[0];
        list.push({
          hotelId: rh.hotelId,
          firstRate,
        });
      });
    }

    list.sort((a, b) => {
      let comparison = 0;

      switch (sortCriterion) {
        case "price": {
          const priceA = a.firstRate?.retailRate?.total?.[0]?.amount ?? (sortDirection === "asc" ? 9999999 : -1);
          const priceB = b.firstRate?.retailRate?.total?.[0]?.amount ?? (sortDirection === "asc" ? 9999999 : -1);
          comparison = priceA - priceB;
          break;
        }
        case "rating": {
          const ratingA = a.aiInfo?.rating ?? 0;
          const ratingB = b.aiInfo?.rating ?? 0;
          comparison = ratingA - ratingB;
          break;
        }
        case "stars": {
          const starsA = a.aiInfo?.starRating ?? 0;
          const starsB = b.aiInfo?.starRating ?? 0;
          comparison = starsA - starsB;
          break;
        }
        case "reviews": {
          const reviewsA = a.aiInfo?.reviewsCount ?? 0;
          const reviewsB = b.aiInfo?.reviewsCount ?? 0;
          comparison = reviewsA - reviewsB;
          break;
        }
        case "name": {
          const nameA = (a.aiInfo?.name || "").toLowerCase();
          const nameB = (b.aiInfo?.name || "").toLowerCase();
          comparison = nameA.localeCompare(nameB, "de");
          break;
        }
        case "facilities": {
          const facA = a.aiInfo?.hotelFacilities?.length ?? 0;
          const facB = b.aiInfo?.hotelFacilities?.length ?? 0;
          comparison = facA - facB;
          break;
        }
        case "relevance":
        default: {
          const scoreA = Number((a.aiInfo as any)?.rankScore ?? 0);
          const scoreB = Number((b.aiInfo as any)?.rankScore ?? 0);
          comparison = scoreA - scoreB;
          break;
        }
      }

      if (comparison === 0) {
        // Stable tie-break by hotelId
        return a.hotelId.localeCompare(b.hotelId);
      }
      return sortDirection === "asc" ? comparison : -comparison;
    });

    return list;
  }, [aiHotels, rateHotels, sortCriterion, sortDirection]);

  const totalPages = Math.max(1, Math.ceil(hotelResults.length / ITEMS_PER_PAGE));

  const displayedHotels = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return hotelResults.slice(start, start + ITEMS_PER_PAGE);
  }, [currentPage, hotelResults]);

  const handlePageChange = (p: number) => {
    if (p < 1 || p > totalPages || p === currentPage) return;
    setCurrentPage(p);
    document.getElementById("hotel-content-area")?.scrollIntoView({ behavior: "smooth" });
  };

  const renderPagination = () => {
    if (totalPages <= 1 && !hasMoreResults) return null;

    if (totalPages <= 1 && hasMoreResults) {
      return (
        <div className="pt-4 pb-2 mt-4 flex flex-col items-center gap-3">
          <div className="text-xs text-[#6e6e73]">
            {hotelResults.length} Unterkunft{hotelResults.length === 1 ? "" : "en"} geladen
            {lastRequestId ? (
              <span className="ml-2 opacity-50">· {lastRequestId}</span>
            ) : null}
          </div>
          <button
            type="button"
            onClick={handleLoadMore}
            disabled={isLoadingMore || isSearching}
            id="pagination-btn-load-more"
            className="px-5 py-2.5 text-xs font-normal rounded-[40px] bg-[#454639] text-white hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer"
          >
            {isLoadingMore ? "Lade weitere…" : "Weitere 50 Hotels laden"}
          </button>
        </div>
      );
    }

    const getPageNumbers = () => {
      const pages: (number | string)[] = [];
      const maxVisible = 7;
      if (totalPages <= maxVisible) {
        for (let i = 1; i <= totalPages; i++) pages.push(i);
      } else {
        if (currentPage <= 4) {
          for (let i = 1; i <= 5; i++) pages.push(i);
          pages.push("...");
          pages.push(totalPages);
        } else if (currentPage >= totalPages - 3) {
          pages.push(1);
          pages.push("...");
          for (let i = totalPages - 4; i <= totalPages; i++) pages.push(i);
        } else {
          pages.push(1);
          pages.push("...");
          pages.push(currentPage - 1);
          pages.push(currentPage);
          pages.push(currentPage + 1);
          pages.push("...");
          pages.push(totalPages);
        }
      }
      return pages;
    };

    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE + 1;
    const endIndex = Math.min(currentPage * ITEMS_PER_PAGE, hotelResults.length);

    return (
      <div className="pt-4 pb-2 mt-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-[#6e6e73] font-normal order-2 sm:order-1">
          Zeige <span className="font-normal text-[#454639]">{startIndex}–{endIndex}</span> von{" "}
          <span className="font-normal text-[#454639]">{hotelResults.length}</span> Unterkünften
        </div>

        <div className="flex items-center gap-1.5 order-1 sm:order-2 flex-wrap justify-center">
          {/* Previous Button */}
          <button
            type="button"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            id="pagination-btn-prev"
            className="px-4 py-2 text-xs font-normal rounded-[40px] bg-[#ffffff] text-[#454639] hover:bg-[#f5f5f7] disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center gap-1 cursor-pointer"
            title="Vorherige Seite"
          >
            <ChevronLeft className="w-4 h-4 text-[#dccfb8]" />
            <span className="hidden sm:inline">Zurück</span>
          </button>

          {/* Page Numbers */}
          <div className="flex items-center gap-1">
            {getPageNumbers().map((p, idx) => {
              if (p === "...") {
                return (
                  <span key={`ellipsis-${idx}`} className="px-2 py-1 text-xs text-[#6e6e73] font-normal">
                    ...
                  </span>
                );
              }
              const isCurrent = p === currentPage;
              return (
                <button
                  key={`page-${p}`}
                  type="button"
                  onClick={() => handlePageChange(Number(p))}
                  className={`min-w-[36px] h-9 px-2.5 text-xs font-normal rounded-[40px] transition-all duration-300 ease-out cursor-pointer active:scale-[0.94] flex items-center justify-center ${
                    isCurrent
                      ? "bg-[#454639] text-white"
                      : "bg-[#ffffff] text-[#454639] hover:bg-[#f5f5f7]"
                  }`}
                >
                  {p}
                </button>
              );
            })}
          </div>

          {/* Next Button */}
          <button
            type="button"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            id="pagination-btn-next"
            className="px-4 py-2 text-xs font-normal rounded-[40px] bg-[#ffffff] text-[#454639] hover:bg-[#f5f5f7] disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center gap-1 cursor-pointer"
            title="Nächste Seite"
          >
            <span className="hidden sm:inline">Weiter</span>
            <ChevronRight className="w-4 h-4 text-[#dccfb8]" />
          </button>
        </div>

        {hasMoreResults && (
          <div className="w-full order-3 flex justify-center pt-2">
            <button
              type="button"
              onClick={handleLoadMore}
              disabled={isLoadingMore || isSearching}
              id="pagination-btn-load-more"
              className="px-5 py-2.5 text-xs font-normal rounded-[40px] bg-[#454639] text-white hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer"
              title="Weitere Hotels von der API laden"
            >
              {isLoadingMore ? "Lade weitere…" : "Weitere 50 Hotels laden"}
            </button>
          </div>
        )}
      </div>
    );
  };

  const formatWeatherLabel = (): string | null => {
    const place = (searchParams.placeName || "").trim();
    const fmt = (iso: string) => {
      if (!iso) return "";
      try {
        return new Date(iso + "T12:00:00").toLocaleDateString("de-DE", {
          day: "numeric",
          month: "short",
        });
      } catch {
        return iso;
      }
    };
    const from = fmt(searchParams.checkin);
    const to = fmt(searchParams.checkout);
    const when = from && to ? `${from} – ${to}` : from || to || "";
    if (place && when) return `${place} · ${when}`;
    if (place) return place;
    if (when) return when;
    return null;
  };

  const weatherLabel = !isBookedMode ? formatWeatherLabel() : null;

  return (
    <div style={{ fontFamily: "Arial, sans-serif" }} className="h-screen w-screen bg-[#ffffff] text-[#1d1d1f] flex flex-col antialiased selection:bg-[#dccfb8] selection:text-[#1d1d1f] overflow-hidden">
      {/* Header with View Switcher */}
      <Header
        currentView={view}
        onSelectView={() => {
          setSelectedPlaceholder(null);
          setShowPersonalProfile(false);
          setShowWeather(false);
        }}
        currency={searchParams.currency}
        onCurrencyChange={(curr) => setSearchParams((prev) => ({ ...prev, currency: curr }))}
        onToggleMenu={() => setIsMenuOpen((prev) => !prev)}
        isMenuOpen={isMenuOpen}
        onOpenProfile={() => {
          setShowPersonalProfile(true);
          setShowWeather(false);
          setSelectedPlaceholder(null);
          setMobilePane("hotels");
        }}
        isBookedMode={true}
      />

      {/* Nur Mobile: Pane-Umschalter (kompakt) */}
      <div className="lg:hidden flex items-center justify-center gap-2 shrink-0 px-3 py-1.5 border-b border-[#f0ebe3] bg-white">
        <button
          onClick={() => setMobilePane("search_advisor")}
          className={`flex-1 sm:flex-none py-2 px-3 rounded-[40px] text-xs font-normal flex items-center justify-center gap-1.5 transition-all duration-300 ease-out cursor-pointer active:scale-[0.94] ${
            mobilePane === "search_advisor"
              ? "bg-[#454639] text-white"
              : "bg-[#ffffff] text-[#454639] hover:bg-[#f5f5f7]"
          }`}
        >
          <Search className="w-3.5 h-3.5 text-[#dccfb8]" />
          <span>Gemini Chat</span>
        </button>
        <button
          onClick={() => setMobilePane("hotels")}
          className={`flex-1 sm:flex-none py-2 px-3 rounded-[40px] text-xs font-normal flex items-center justify-center gap-1.5 transition-all duration-300 ease-out cursor-pointer active:scale-[0.94] ${
            mobilePane === "hotels"
              ? "bg-[#454639] text-white"
              : "bg-[#ffffff] text-[#454639] hover:bg-[#f5f5f7]"
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-[#dccfb8]" />
          <span>
            {selectedPlaceholder !== null &&
            !(isNavigationHidden && selectedPlaceholder === 8)
              ? PLACEHOLDER_NAMES[selectedPlaceholder]
              : "Meine Apps"}
          </span>
        </button>
      </div>

      {/* Main 2-Column Split Dashboard (Left for Search & KI Chat / Placeholders, Right for Hotels & Details) */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden min-h-0 relative">
        {/* Left Column (Search + KI Chat OR Placeholders) - On mobile shown conditionally via mobilePane, on desktop collapsible */}
        <aside
          className={`h-full flex flex-col bg-[#ffffff] overflow-hidden shrink-0 z-10 transition-all duration-300 ${
            mobilePane === "search_advisor" ? "flex w-full" : "hidden"
          } lg:flex ${
            isDesktopSidebarCollapsed
              ? "lg:w-16 items-center py-4"
              : "lg:w-[380px] xl:w-[420px] 2xl:w-[460px]"
          }`}
        >
          {isDesktopSidebarCollapsed ? (
            /* Collapsed Desktop Sidebar Mode */
            <div className="hidden lg:flex flex-col items-center justify-between h-full py-2">
              <button
                onClick={() => setIsDesktopSidebarCollapsed(false)}
                title="Seitenleiste aufklappen"
                className="w-10 h-10 rounded-[40px] bg-[#454639] text-white hover:bg-[#2f3028] flex items-center justify-center cursor-pointer transition-all duration-300 ease-out active:scale-[0.94]"
              >
                <PanelLeftOpen className="w-5 h-5 text-[#dccfb8]" />
              </button>
              <div className="writing-mode-vertical text-xs font-normal text-[#454639] tracking-widest uppercase rotate-180">
                Gemini Chat
              </div>
              <div className="w-2 h-2 rounded-[40px] bg-[#dccfb8]" />
            </div>
          ) : (
            /* Expanded Sidebar Mode */
            <div className="h-full flex flex-col overflow-hidden w-full">
              {/* Sidebar Header Bar */}
              <div className="px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2 bg-[#ffffff] shrink-0">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-xs font-normal text-[#454639] truncate">
                    Gemini · Gebuchte Reise
                  </span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => setIsDesktopSidebarCollapsed(true)}
                    title="Seitenleiste einklappen"
                    className="hidden lg:flex text-xs font-normal text-[#6e6e73] hover:text-[#454639] p-1.5 rounded-[40px] bg-[#ffffff] hover:bg-[#f5f5f7] cursor-pointer transition-all duration-300 ease-out active:scale-[0.94]"
                  >
                    <PanelLeftClose className="w-3.5 h-3.5 text-[#dccfb8]" />
                  </button>
                </div>
              </div>

              {/* Left content: Booked Gemini Chat */}
              <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
                <BookedAIChatView
                  className="h-full flex flex-col"
                  userProfile={userProfile}
                  nextTrip={nextTrip}
                  upcomingTrips={upcomingTrips}
                  pastTrips={pastTrips}
                  allTrips={allTrips}
                  onLocationDetected={handleLocationDetected}
                  onDatesDetected={handleDatesDetected}
                  onGoToOverview={() => {
                    setSelectedPlaceholder(null);
                    setShowPersonalProfile(false);
                    setShowWeather(false);
                    setMobilePane("hotels");
                  }}
                />
              </div>
            </div>
          )}
        </aside>

        {/* Right Column - Hotels OR Placeholder App Grid (when booked mode) OR Personal Profile */}
        <section
          className={`flex-1 min-w-0 h-full overflow-y-auto bg-[#ffffff] flex flex-col space-y-6 ${
            isBookedMode && !showPersonalProfile
              ? "p-0"
              : "p-3 sm:p-5 lg:p-6 xl:p-8"
          } ${
            mobilePane === "hotels" ? "flex" : "hidden lg:flex"
          }`}
        >
          {showPersonalProfile ? (
            /* Persönliches Profil – KI-Chat bleibt links sichtbar */
            <div className="flex-1 min-h-0 flex flex-col overflow-hidden" data-ui-view="profile">
              <PersonalProfileView
                className="h-full min-h-0"
                onBack={() => setShowPersonalProfile(false)}
                currentCurrency={searchParams.currency}
                onCurrencyChange={(curr) =>
                  setSearchParams((prev) => ({ ...prev, currency: curr }))
                }
              />
            </div>
          ) : showWeather && !isBookedMode ? (
            /* Wetter statt Hotels (vor Buchung) */
            <div className="flex-1 min-h-0 flex flex-col overflow-hidden">
              <div className="flex items-center justify-between gap-3 pb-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowWeather(false)}
                  className="bg-[#ffffff] hover:bg-[#f5f5f7] text-[#454639] px-4 py-2 rounded-[40px] text-xs font-normal inline-flex items-center gap-2 cursor-pointer transition-all duration-300 ease-out active:scale-[0.94]"
                >
                  <ArrowLeft className="w-4 h-4 text-[#dccfb8]" />
                  <span>Zurück zu den Unterkünften</span>
                </button>
                <span className="text-xs font-normal bg-[#dccfb8] text-[#454639] px-3 py-1 rounded-[40px]">
                  Wetter &amp; Klima
                </span>
              </div>
              <div className="flex-1 min-h-0 overflow-hidden mt-1">
                <PreBookingWeatherView
                  initialLocation={
                    (searchParams.placeName || "").split(",")[0].trim() || undefined
                  }
                  onBackToChat={() => setShowWeather(false)}
                />
              </div>
            </div>
          ) : isBookedMode ? (
            /* ========== BOOKED MODE: Placeholder Apps Grid ========== */
            <div className="flex-1 flex flex-col min-h-0" data-ui-region="booked-apps">
              {selectedPlaceholder === null ? (
                /* Apps oben, darunter Profil mit Reisen & Countdown */
                <div className="space-y-8 p-3 sm:p-5 lg:p-6 xl:p-8" data-ui-view="home-grid">
                  <div>
                    <h2 className="text-xl font-normal text-[#454639] flex items-center gap-2">
                      <Layers className="w-5 h-5 text-[#dccfb8]" />
                      Meine Apps &amp; Tools
                    </h2>
                    <p className="text-xs text-[#6e6e73] mt-1 font-normal">
                      Wähle eine App aus – sie öffnet sich hier rechts.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 sm:gap-5">
                    {activePlaceholderList.map((num) => {
                      return (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setSelectedPlaceholder(num)}
                          id={`app-placeholder-${num}`}
                          className="group flex flex-col items-center gap-2 p-3 rounded-[28px] bg-[#ffffff] transition-colors duration-200 cursor-pointer active:scale-95"
                        >
                          <div
                            className={`w-16 h-16 sm:w-18 sm:h-18 rounded-[22px] bg-[#dccfb8] text-[#454639] flex items-center justify-center text-xl font-normal transition-colors`}
                          >
                            {num}
                          </div>
                          <span className="text-[11px] sm:text-xs font-normal text-[#454639] text-center leading-tight">
                            {PLACEHOLDER_NAMES[num]}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* Selected Placeholder full view – data-placeholder-view ist die Erfolgsprüfung der Automation */
                <div
                  className="flex-1 min-h-0 flex flex-col overflow-hidden"
                  data-placeholder-view={selectedPlaceholder}
                  data-ui-view={`placeholder-${selectedPlaceholder}`}
                >
                    {selectedPlaceholder === 2 && (
                      <Placeholder2
                        nextTrip={nextTrip}
                        userProfile={userProfile}
                        upcomingTrips={upcomingTrips}
                        pastTrips={pastTrips}
                        allTrips={allTrips}
                        searchParams={searchParams}
                        onSearchParamsChange={setSearchParams}
                        sortCriterion={bookedSortCriterion}
                        sortDirection={bookedSortDirection}
                        onSortChange={(criterion, direction) => {
                          setBookedSortCriterion(criterion);
                          setBookedSortDirection(direction);
                        }}
                        onBackToChat={() => setSelectedPlaceholder(null)}
                      />
                    )}
                    {selectedPlaceholder === 8 && !isNavigationHidden && (
                      <Placeholder8
                        nextTrip={nextTrip}
                        upcomingTrips={upcomingTrips}
                        pastTrips={pastTrips}
                        allTrips={allTrips}
                        userProfile={userProfile}
                        onBackToChat={() => setSelectedPlaceholder(null)}
                      />
                    )}
                </div>
              )}
            </div>
          ) : null}
        </section>
      </main>
    </div>
  );
}
